// /src/dallas/events.tsx
import React from "react";
import BlogLayout from "../components/BlogLayout";

const DallasEvents = () => {
  const faqs = [
    {
      question: "What are the biggest annual events in Dallas?",
      answer:
        "Dallas hosts major events including the State Fair of Texas, Dallas Blooms, Deep Ellum Arts Festival, St. Patrick’s Parade, and summer concerts at Klyde Warren Park. These bring together food, music, vendors, and family activities all year.",
    },
    {
      question: "Are most Dallas events family friendly?",
      answer:
        "Many Dallas events are family friendly including the State Fair of Texas, Dallas Blooms, Klyde Warren Park concerts, and Fourth of July celebrations.",
    },
    {
      question: "Do large events affect Dallas traffic?",
      answer:
        "Yes, events like the State Fair and St. Patrick’s Parade can increase traffic near Fair Park, Greenville Avenue, and downtown. Using rideshare or arriving early is recommended.",
    },
    {
      question: "Where do most Dallas events take place?",
      answer:
        "Popular event hubs include Fair Park, Deep Ellum, Klyde Warren Park, the Arts District, and Greenville Avenue.",
    },
    {
      question: "When is the best time to attend events in Dallas?",
      answer:
        "Spring and fall are ideal due to comfortable weather and the city's largest festivals. Summer brings concerts and outdoor events, while winter offers holiday activities.",
    },
  ];

  return (
    <BlogLayout
      title="Dallas Events - Best Events in Dallas, Texas"
      publishDate={new Date().toISOString()}
      keywords={[
        "Dallas events",
        "things to do in Dallas",
        "Dallas festivals",
        "Dallas concerts",
        "Dallas activities",
        "Dallas neighborhoods",
      ]}
      address={{ addressLocality: "Dallas", addressRegion: "Texas" }}
      content={
        <>
          {/* ---- REMOVE DEFAULT INTRO ---- */}
          <p style={{ display: "none" }}></p>

          {/* ---- INTRO ---- */}
          <p style={{ marginBottom: "0.5rem" }}>
            <strong>Looking for the best events happening in Dallas?</strong>
            The city comes alive with festivals, concerts, parades, and cultural
            celebrations all year long.
          </p>

          <p style={{ marginBottom: "2.2rem", color: "#555" }}>
            Below are Dallas’s most popular annual events in the order they
            occur throughout the year.
          </p>

          {/* --- EVENT 1 --- */}
          <div style={{ padding: ".10rem", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Dallas Blooms Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 February to April — Dallas Arboretum</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              The largest floral festival in the Southwest, featuring millions
              of spring blooms, seasonal displays, and family-friendly
              activities.
            </p>
            <a
              href="https://www.dallasarboretum.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 2 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              St. Patrick’s Parade & Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Mid-March — Greenville Avenue</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A massive Dallas tradition featuring a parade, food,
              entertainment, and one of the city’s biggest annual celebrations.
            </p>
            <a
              href="https://www.dallasstpatricksparade.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 3 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Deep Ellum Arts Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Early April — Deep Ellum</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A major celebration of Dallas art, music, and culture with live
              performances, local vendors, and food booths.
            </p>
            <a
              href="https://www.deepellumartsfestival.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 4 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Dallas Arts District Block Party
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Spring & Fall — Dallas Arts District</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A celebration of arts and culture featuring live performances,
              open museum galleries, food trucks, and community activities.
            </p>
            <a
              href="https://www.dallasartsdistrict.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 5 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Klyde Warren Park Concert Series
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 May to September — Klyde Warren Park</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A free summer-long outdoor concert series in the heart of downtown
              Dallas featuring local and touring artists.
            </p>
            <a
              href="https://klydewarrenpark.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 6 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Fourth of July Celebration at Klyde Warren Park
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 July 4 — Klyde Warren Park</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A family-friendly Independence Day celebration with fireworks,
              live music, food vendors, and activities for all ages.
            </p>
            <a
              href="https://klydewarrenpark.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Event Page
            </a>
          </div>

          {/* --- EVENT 7 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              State Fair of Texas
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Late September to Mid-October — Fair Park</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              One of the most iconic events in the United States featuring
              rides, fried foods, parades, livestock shows, and Big Tex.
            </p>
            <a
              href="https://bigtex.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          <h2 style={{ marginTop: "2rem" }}>Where Most Events Happen</h2>
          <p style={{ marginBottom: 0 }}>
            Popular event hubs include Fair Park, Klyde Warren Park, Deep Ellum,
            the Arts District, and Greenville Avenue. These areas host
            festivals, concerts, parades, and community events year-round.
          </p>
        </>
      }
      faqs={faqs}
    />
  );
};

export default DallasEvents;
