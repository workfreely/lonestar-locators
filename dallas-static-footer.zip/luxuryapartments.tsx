import React, { useState } from "react";
import BlogLayout from "../components/BlogLayout";

const DallasLuxuryApartments = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const IMG_8119 = "/images/8119-dallas.jpg";
  const IMG_KESSLER = "/images/kessler-bluffs.jpg";
  const IMG_SINCLAIR = "/images/sinclair-residences.jpg";

  const VIDEO_8119 = "";
  const VIDEO_KESSLER = "";
  const VIDEO_SINCLAIR = "";

  const faqs = [
    {
      question: "What are the best luxury apartments in Dallas for 2025?",
      answer:
        "8119 Luxury Apartments, Kessler Bluffs, and The Sinclair Residences are three of the top luxury apartment communities in Dallas this year.",
    },
    {
      question: "Are there any luxury apartments under $1,300 in Dallas?",
      answer:
        "Yes — some properties in North Dallas and Oak Cliff offer select floorplans under $1,300. Availability changes quickly, so contact us for a current list.",
    },
    {
      question: "Do these apartments offer virtual or online appointments?",
      answer:
        "Absolutely — most luxury communities in Dallas offer virtual tours, FaceTime walk-throughs, and easy online scheduling for your convenience.",
    },
    {
      question: "How do I schedule a tour?",
      answer:
        "Click the link below to request your personalized list — we’ll help you tour, apply, and even unlock free perks like move-in specials or cash back.",
    },
  ];

  return (
    <BlogLayout
      title="Best Luxury Apartments in Dallas (2025)"
      content={
        <>
          <p>
            Looking for the best luxury apartments in Dallas? You're in the
            right place. From Uptown to North Dallas, we’ve handpicked three
            standout properties with gorgeous interiors, skyline views, and
            unbeatable locations.
          </p>

          <h2>Why Rent a Luxury Apartment in Dallas?</h2>
          <p>
            Dallas offers a vibrant mix of culture, career growth, and
            entertainment. Luxury high-rise apartments in Dallas bring together
            the best of style, amenities, and city access — perfect for anyone
            who wants an elevated lifestyle.
          </p>

          <h2>Top Picks for Luxury Apartments in Dallas</h2>

          <h3>1. 8119 Luxury Apartments</h3>
          {IMG_8119 && (
            <img
              src={IMG_8119}
              alt="8119 Luxury Apartments Dallas"
              style={{
                width: "100%",
                borderRadius: "8px",
                marginBottom: "20px",
              }}
            />
          )}
          <p>
            Located at 8119 Douglas Ave, this community offers upscale finishes,
            private balconies, and an incredible location near NorthPark Center
            and Preston Hollow. A prime choice if you're seeking luxury
            apartments in North Dallas under $2,000.
          </p>

          <h3>2. Kessler Bluffs</h3>
          {IMG_KESSLER && (
            <img
              src={IMG_KESSLER}
              alt="Kessler Bluffs Dallas"
              style={{
                width: "100%",
                borderRadius: "8px",
                marginBottom: "20px",
              }}
            />
          )}
          <p>
            Kessler Bluffs blends serene Oak Cliff views with modern interiors,
            dog parks, and on-site yoga studios. One of the top options if
            you're looking for high-rise apartments in Dallas under $2,000.
          </p>

          <h3>3. The Sinclair Residences</h3>
          {IMG_SINCLAIR && (
            <img
              src={IMG_SINCLAIR}
              alt="The Sinclair Residences Dallas"
              style={{
                width: "100%",
                borderRadius: "8px",
                marginBottom: "20px",
              }}
            />
          )}
          <p>
            The Sinclair offers luxury living in the heart of Uptown Dallas.
            Expect rooftop lounges, resort-style pools, and floor-to-ceiling
            windows — all walkable to McKinney Ave nightlife and dining.
          </p>

          <h2>Exclusive Curated Luxury Apartment List (2025)</h2>
          <p>
            Here’s a preview of our exclusive list of the best luxury apartments
            in Dallas:
          </p>
          <img
            src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1749011732/exclusive-second-chance-apartment-list-austin_ipjabc.jpg"
            alt="Exclusive Luxury Apartment List Dallas"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
              border: "1px solid #ddd",
            }}
          />
          <p style={{ fontStyle: "italic", color: "#666" }}>
            (This is just a preview — click below to get your personalized list
            of luxury apartments in Dallas!)
          </p>

          <h2>How We Help</h2>
          <ul style={{ paddingLeft: "20px", lineHeight: "1.8" }}>
            <li>✅ Free personalized apartment list based on your goals</li>
            <li>✅ Access to move-in specials and limited offers</li>
            <li>✅ Online and in-person tour scheduling assistance</li>
            <li>✅ Get up to $200 cash back or free movers after you lease</li>
          </ul>

          <h2>Ready to Tour Your Next Luxury Apartment?</h2>
          <p>
            Our Dallas apartment locating service is completely free — and we’ll
            help you find exactly what you’re looking for. From high-rise
            apartments under $2,000 to luxury units in Uptown Dallas, we’ve got
            you covered.
          </p>

          {/* FAQ Accordion */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default DallasLuxuryApartments;
