import React from "react";
import { Helmet } from "react-helmet";

const DallasFirstTimeRenters = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>First-Time Apartment Renters in Dallas | Lone Star Locators</title>
        <meta
          name="description"
          content="First time renting an apartment in Dallas? Get expert guidance and access to properties that welcome new renters. Free locating and up to $200 cash back."
        />
      </Helmet>

      <h1>Dallas Apartments for First-Time Renters</h1>
      <p>
        New to renting? We make it easy. Whether you're relocating to Dallas or moving out on your own for the first time, our 
        team specializes in helping first-time renters find the perfect place — without the stress.
      </p>

      <h2>What First-Time Renters in Dallas Should Know</h2>
      <ul>
        <li>We'll walk you through the entire process step-by-step</li>
        <li>We'll help you understand credit and income requirements</li>
        <li>We can recommend properties that are flexible with new renters</li>
        <li>You'll still qualify for specials and rebates</li>
      </ul>

      <p>
        Lone Star Locators works with top Dallas apartment communities to match you with the right fit based on your 
        lifestyle, budget, and location preferences. Our services are 100% free to you — and you may even earn up to $200 
        cash back after move-in!
      </p>
    </div>
  );
};

export default DallasFirstTimeRenters;