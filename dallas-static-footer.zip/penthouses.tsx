import React, { useState } from "react";
import BlogLayout from "../components/BlogLayout";

const DallasPenthouses = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Are there affordable penthouses for rent in Dallas?",
      answer:
        "Yes — while many penthouses are ultra-luxury, there are several buildings that offer smaller or more affordable penthouse options under $5,000/month, especially with move-in specials.",
    },
    {
      question: "Where are the best penthouses in Dallas located?",
      answer:
        "Most of Dallas’s luxury penthouses are concentrated in Downtown, Uptown, and the East Quarter, offering skyline views and high-end amenities.",
    },
    {
      question: "Do any Dallas penthouses allow Airbnb or short-term stays?",
      answer:
        "Most luxury high-rises restrict short-term rentals like Airbnb, but some buildings allow 3+ month leases or have corporate housing partners. We can guide you to the right properties.",
    },
    {
      question:
        "What’s the difference between a penthouse and a luxury apartment?",
      answer:
        "Penthouses typically occupy the highest floors and feature larger layouts, high ceilings, premium appliances, and expansive terraces or views — but not all luxury apartments are true penthouses.",
    },
  ];

  return (
    <BlogLayout
      title="Dallas Penthouses for Rent (2025) | Luxury & Affordable High-Rise Options"
      content={
        <>
          <p>
            Searching for the best penthouses in Dallas? Whether you're dreaming
            of floor-to-ceiling windows, skyline views, or a private rooftop
            terrace — this guide spotlights the top penthouse residences in
            Dallas for 2025, including affordable options and new luxury
            listings.
          </p>

          <h2>Why Rent a Penthouse in Dallas?</h2>
          <p>
            Penthouses offer the ultimate in luxury living — more space, higher
            ceilings, and unmatched views. In Dallas, many are located in
            high-rise towers in Downtown, Uptown, and East Quarter, surrounded
            by dining, culture, and nightlife.
          </p>

          <div style={{ lineHeight: "1.8" }}>
            <div>✅ Expansive layouts and top-floor privacy</div>
            <div>✅ Breathtaking views of the Dallas skyline</div>
            <div>✅ High-end finishes and private rooftop access</div>
            <div>✅ VIP amenities like valet, concierge & lounges</div>
          </div>

          <h2>Top Penthouses in Dallas (2025)</h2>

          <h3>1. The National Residences (Downtown Dallas)</h3>
          <p>
            Sitting atop one of the most iconic buildings in Dallas, The
            National offers true high-rise penthouse living. Enjoy soaring
            ceilings, oversized windows, and priority access to the Thompson
            Hotel's services, spa, and rooftop pool.
          </p>

          <h3>2. East Quarter Residences (East Downtown)</h3>
          <p>
            Modern, artistic, and thoughtfully designed — East Quarter's
            penthouses feature industrial-chic interiors, 2- and 3-bedroom
            floorplans, chef-style kitchens, and stunning views of Deep Ellum
            and Downtown Dallas.
          </p>

          <h3>3. Carlisle and Vine (Uptown Dallas)</h3>
          <p>
            For penthouse seekers in Uptown, Carlisle & Vine blends boutique
            elegance with unmatched access to Katy Trail and Turtle Creek.
            Penthouse layouts include large balconies, wine fridges, smart home
            features, and spa-inspired baths.
          </p>

          <h2>Preview of Our Curated Penthouse List</h2>
          <p>
            We maintain a curated list of luxury penthouses in Dallas —
            including off-market units, incentives, and VIP leasing options not
            available on apartment sites.
          </p>

          <img
            src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1749011732/exclusive-second-chance-apartment-list-austin_ipjabc.jpg"
            alt="Dallas Penthouse Preview"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
              border: "1px solid #ddd",
            }}
          />
          <p style={{ fontStyle: "italic", color: "#666" }}>
            This is a preview of our curated list. Contact us below to get your
            personalized penthouse matches.
          </p>

          <h2>What You Get When You Work With Us</h2>
          <div style={{ lineHeight: "1.8" }}>
            <div>✅ Personalized penthouse list based on your preferences</div>
            <div>✅ Access to high-rise incentives and move-in specials</div>
            <div>✅ Help with private showings and leasing terms</div>
            <div>✅ Free service with rebate or movers when you lease</div>
          </div>

          <h2>Ready to Tour Your Next Penthouse in Dallas?</h2>
          <p>
            Whether you're looking for a high-rise in Downtown or a hidden gem
            in Uptown, we’ll help you find your perfect penthouse — fast, free,
            and with VIP-level guidance every step of the way.
          </p>
          <p>
            Get in touch below to start your custom search and unlock Dallas’s
            most exclusive rentals.
          </p>

          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default DallasPenthouses;
