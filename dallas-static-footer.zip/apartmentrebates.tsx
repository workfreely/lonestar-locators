import React from "react";
import { Helmet } from "react-helmet";
import { REBATE_AMOUNT } from "../constants";

const DallasApartmentRebates = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>Apartment Rebates in Dallas | Lone Star Locators</title>
        <meta
          name="description"
          content={`Earn up to ${REBATE_AMOUNT} when leasing your next apartment in Dallas. Our free locating service helps you find the best luxury deals with move-in specials.`}
        />
      </Helmet>

      <h1>Dallas Apartment Rebates</h1>
      <p>
        Lease a new apartment in Dallas and get up to {REBATE_AMOUNT} cash back
        — just for writing our name on your application and guest card!
      </p>

      <h2>How to Qualify</h2>
      <ul>
        <li>Use our free service to find an apartment</li>
        <li>Mention “Lone Star Locators” on your guest card and app</li>
        <li>Submit your rebate form within 90 days of moving in</li>
      </ul>

      <h2>Why Renters Love It</h2>
      <ul>
        <li>Earn cash on something you were already planning to do</li>
        <li>Still qualify for all current specials and promotions</li>
        <li>Free expert guidance — at no cost to you</li>
      </ul>

      <p style={{ marginTop: "2rem" }}>
        Ready to claim your rebate? Let’s find your next Dallas apartment!
      </p>
    </div>
  );
};

export default DallasApartmentRebates;