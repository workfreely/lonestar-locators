import React from "react";
import { Helmet } from "react-helmet";
import { REBATE_AMOUNT } from "../constants";

const HoustonApartmentRebates = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>Apartment Rebates in Houston | Lone Star Locators</title>
        <meta
          name="description"
          content={`Get up to ${REBATE_AMOUNT} cash back on your next Houston apartment. Use Lone Star Locators for expert help and exclusive deals.`}
        />
      </Helmet>

      <h1>Houston Apartment Rebates</h1>
      <p>
        Did you know you can earn up to {REBATE_AMOUNT} just for listing Lone Star
        Locators on your application and guest card?
      </p>

      <p>
        Whether you're moving to Midtown, the Heights, or Downtown Houston, our expert
        team will help you find the best options — and make sure you get rewarded for it.
      </p>

      <h2>How to Qualify</h2>
      <ul>
        <li>Use our free service to find your next apartment</li>
        <li>List “Lone Star Locators” on the application and guest card</li>
        <li>Submit your rebate form after you move in</li>
      </ul>

      <p>
        It's that easy. Save money, reduce stress, and get cash back — only with Lone Star
        Locators.
      </p>
    </div>
  );
};

export default HoustonApartmentRebates;