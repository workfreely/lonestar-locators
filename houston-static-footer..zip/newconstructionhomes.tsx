import React, { useState } from "react";
import BlogLayout from "../components/BlogLayout";
import BuyNewHomeExitIntentPopup from "../components/BuyNewHomeExitIntentPopup";
import NewHomeFooter from "../components/NewHomeFooter";
import { Helmet } from "react-helmet";

const NewConstructionHomesHouston = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const IMG_BLURRED_LIST =
    "https://res.cloudinary.com/dxtiguwzm/image/upload/v1760740971/new-construction-homes-list-san-_antonio-austin-dallas-houston_cvp0yz.png";

  const faqs = [
    {
      question:
        "Can I buy a new construction home in Houston with less than perfect credit?",
      answer:
        "Yes! Many builders offer flexible financing options and programs for buyers with various credit profiles. We’ll match you with the best opportunities.",
    },
    {
      question: "Are there new construction homes in Houston under $400K?",
      answer:
        "Yes — there are new communities with homes starting under $400K depending on location and builder incentives. We know which areas to target.",
    },
    {
      question: "Do I need an agent to buy a new construction home?",
      answer:
        "It’s highly recommended! Builders represent themselves — having your own agent costs you nothing and ensures you’re getting the best deal and protections.",
    },
    {
      question: "Are there first-time homebuyer programs for new construction?",
      answer:
        "Absolutely! Many lenders and builders offer first-time buyer incentives, down payment assistance, and special financing for new builds.",
    },
    {
      question: "How do I get started?",
      answer:
        "Click below to request your personalized list — we’ll review your goals and send curated new construction deals that fit your needs.",
    },
  ];

  return (
    <BlogLayout
      title="New Construction Homes in Houston TX | Best Builder Deals 2025"
      content={
        <>
          <Helmet>
            <title>
              New Construction Homes in Houston TX | Best Builder Deals 2025
            </title>
            <meta
              name="description"
              content="Discover the best new construction homes in Houston, TX! We help buyers find new homes, builder incentives, first-time buyer programs & more — free service!"
            />
            <meta
              name="keywords"
              content="new construction homes Houston, new homes Houston TX, Houston new construction, first-time homebuyer Houston, builder incentives Houston, new communities Houston"
            />
            <script type="application/ld+json">
              {`
              {
                "@context": "https://schema.org",
                "@type": "Article",
                "headline": "New Construction Homes in Houston TX | Best Builder Deals 2025",
                "description": "Discover the best new construction homes in Houston! We help buyers find new homes, builder incentives, first-time buyer programs, and more — all at no cost to you.",
                "author": {
                  "@type": "Organization",
                  "name": "Lone Star Locators"
                },
                "publisher": {
                  "@type": "Organization",
                  "name": "Lone Star Locators",
                  "logo": {
                    "@type": "ImageObject",
                    "url": "https://res.cloudinary.com/dxtiguwzm/image/upload/v1748223464/lone-star-locators-white-logo-footer_dyrwka.png"
                  }
                },
                "datePublished": "2025-06-10",
                "mainEntityOfPage": {
                  "@type": "WebPage",
                  "@id": "https://yourdomain.com/houston/new-construction-homes"
                }
              }
              `}
            </script>
          </Helmet>

          <p>
            Thinking about buying a brand new home in Houston? You’re in the
            right place! We help buyers discover{" "}
            <em>the best new construction deals</em>, builder incentives, and
            first-time homebuyer programs — all at <strong>no cost</strong> to
            you.
          </p>

          <h2>Why Buy a New Construction Home in Houston?</h2>
          <p>
            New construction homes offer modern designs, energy efficiency,
            builder warranties, and the ability to personalize your space — all
            without the hassles of an older home.
          </p>

          <h2>Popular Price Points — New Homes in Houston</h2>
          <p>Here are common search ranges we help clients with:</p>
          <div style={{ paddingLeft: "20px", lineHeight: "1.8" }}>
            <div>✅ New homes in Houston under $300K</div>
            <div>✅ New construction homes Houston under $400K</div>
            <div>✅ New homes Houston under $500K</div>
            <div>✅ First-time homebuyer friendly communities</div>
            <div>✅ Builder incentives & closing cost assistance</div>
          </div>

          <h2>How We Help You Find the Best Deals</h2>
          <div style={{ paddingLeft: "20px", lineHeight: "1.8" }}>
            <div>
              ✅ Personalized list of new construction communities based on your
              budget & goals
            </div>
            <div>✅ Access to exclusive builder promotions & incentives</div>
            <div>✅ Guidance on first-time buyer programs & financing</div>
            <div>✅ Free representation — the builder pays us, not you</div>
            <div>✅ Expert advice throughout the process</div>
          </div>

          <h2>Preview: Our Exclusive New Construction Deals List</h2>
          <p>
            We maintain an updated list of the{" "}
            <em>top new construction communities and builder incentives</em> in
            Houston. Here's a preview:
          </p>

          {IMG_BLURRED_LIST && (
            <img
              src={IMG_BLURRED_LIST}
              alt="Exclusive New Construction Homes List Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
                border: "1px solid #ddd",
              }}
            />
          )}

          <p
            style={{
              backgroundColor: "#e6f4ea",
              padding: "12px",
              borderRadius: "6px",
              fontWeight: "bold",
            }}
          >
            <span style={{ fontWeight: "bold" }}>
              <span>Click </span>
              <span style={{ color: "#007a38", fontWeight: "bold" }}>
                (“Start Your Search”)
              </span>
              <span>
                {" "}
                below to tell us what you’re looking for — we’ll send a
                personalized list of new construction deals in Houston!
              </span>
            </span>
          </p>

          <h2>Next Steps</h2>
          <p>
            Ready to explore the best new construction homes in Houston?{" "}
            <strong>Our service is 100% free for buyers</strong> — and we can
            save you thousands by helping you access builder incentives and
            first-time buyer programs.
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px", fontWeight: "700" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};
// <NewHomeFooter citySlug="austin" /> // TODO: Move into return block later
<BuyNewHomeExitIntentPopup />;
export default NewConstructionHomesHouston;
