import React from "react";
import { Helmet } from "react-helmet";

const HoustonPenthouses = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>Houston Penthouses for Rent | Lone Star Locators</title>
        <meta
          name="description"
          content="Discover luxury penthouses in Houston with stunning views, high-end finishes, and resort-style amenities. Tour top-tier listings with Lone Star Locators."
        />
      </Helmet>

      <h1>Houston Penthouses for Rent</h1>
      <p>
        Experience elevated living in one of Houston’s exclusive penthouse
        residences. From panoramic skyline views to expansive floor plans and private
        rooftop terraces, penthouse living offers the ultimate in luxury and privacy.
      </p>

      <p>
        Our team will connect you with top-tier penthouses across Downtown, River Oaks,
        The Galleria, and beyond — with features like floor-to-ceiling windows,
        concierge service, and premium amenities.
      </p>

      <p>
        Lone Star Locators is your go-to source for high-rise living in Houston.
        Schedule a private tour today and take your lifestyle to the next level.
      </p>
    </div>
  );
};

export default HoustonPenthouses;