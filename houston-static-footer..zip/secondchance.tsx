import React from "react";
import { Helmet } from "react-helmet";

const SecondChanceApartmentsHouston = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>Second Chance Apartments in Houston | Lone Star Locators</title>
        <meta
          name="description"
          content="Find second chance apartments in Houston that work with broken leases, bad credit, or background issues. Lone Star Locators can help you get approved."
        />
      </Helmet>

      <h1>Second Chance Apartments in Houston</h1>

      <p>
        If you’ve had a broken lease, bad credit, or a background issue in the
        past, don’t worry — we specialize in helping renters find second chance
        apartments in Houston.
      </p>

      <h2>Flexible Approval Options</h2>
      <ul>
        <li>Works with prior evictions or broken leases (case-by-case)</li>
        <li>Helps renters with low credit scores or no credit</li>
        <li>Options for co-signers and higher deposits</li>
      </ul>

      <h2>Where We Can Help</h2>
      <p>
        Whether you’re looking in Southwest Houston, Katy, Spring Branch, or
        near the Medical Center, we can match you with apartments that give you
        the best chance at approval.
      </p>

      <p style={{ marginTop: "1.5rem" }}>
        Ready to get a fresh start? Reach out to Lone Star Locators and let us
        help you find a second chance apartment in Houston that fits your needs.
      </p>
    </div>
  );
};

export default SecondChanceApartmentsHouston;
