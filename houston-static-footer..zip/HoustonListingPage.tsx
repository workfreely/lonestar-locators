// /src/houston/HoustonListingPage.tsx
import React from "react";
import { Helmet } from "react-helmet";
import ListingLayout from "../components/ListingLayout";
import { generateListingSchema } from "../utils/generateListingSchema";

const HoustonListingPage = () => {
  const schemaData = generateListingSchema({
    city: "Houston",
    state: "TX",
    pageUrl: "https://www.lonestarlocators.app/houston/apartments",
    description:
      "Explore the best apartments for rent in Houston, TX. Search by neighborhood, amenities, price, and more. Get up to $200 cash back or 2 hours of free movers!",
    title: "Houston Apartments for Rent | Lone Star Locators",
  });

  return (
    <>
      <Helmet>
        <title>Houston Apartments for Rent | Lone Star Locators</title>
        <meta
          name="description"
          content="Search Houston apartments by neighborhood, price, and amenities. Up to $200 cash back or free movers. Start your search today!"
        />
        <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
      </Helmet>

      <ListingLayout
        city="Houston"
        listings={[]} // Replace with Supabase data later
      />
    </>
  );
};

export default HoustonListingPage;
