import React, { useState, useEffect } from "react";
import Papa from "papaparse"; // keep until Supabase replaces CSV
import "../styles/apartmentlistings.css";
import SchemaItemList from "../components/SchemaItemList";
import AISchema from "../components/AISchema";
import ListingCard from "../components/ListingCard";
import { createClient } from "@supabase/supabase-js";

// =======================================================
// 🧩 SUPABASE CONFIG — works in CodeSandbox + Vercel
// =======================================================

// ✅ TEMPORARY for CodeSandbox (use this active version)
const supabaseUrl = "https://ukkxisleiprdpptaaxcs.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVra3hpc2xlaXByZHBwdGFheGNzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4NTA3MTgsImV4cCI6MjA3NDQyNjcxOH0.2toax3wY19COqPtJh64qpRcvYNlnFIndI_27og8jp-4";

// ✅ FUTURE for Vercel / Local (comment out until deployment)
// const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
// const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// =======================================================
// 🏙️ MOCK LISTING (keep until Supabase table connects)
// =======================================================

const defaultImage =
  "https://res.cloudinary.com/dxtiguwzm/image/upload/v1748277676/photos-coming-soon-lone-star-locators_be1dyx.jpg";

const ApartmentListings = () => {
  // ✅ Supabase listings state
  const [listings, setListings] = useState<any[]>([]);

  // ✅ Fetch listings from Supabase
  useEffect(() => {
    const fetchListings = async () => {
      const { data, error } = await supabase
        .from("houston_listings") // 👈 or "san_antonio_listings"
        .select("*");

      if (error) {
        console.error("Error fetching listings:", error);
      } else {
        console.log("✅ Listings fetched:", data);
        setListings(data || []);
      }
    };

    fetchListings();
  }, []);

  const allNeighborhoods = [
    "Downtown Houston",
    "Midtown",
    "Montrose",
    "The Heights",
    "Medical Center",
    "Museum District",
    "River Oaks",
    "Galleria",
    "Washington Ave",
    "East Downtown (EaDo)",
    "Greenway / Upper Kirby", // ✅ new high-end area
  ];

  const [filters, setFilters] = useState({
    beds: "",
    baths: "",
    price: "",
    propertyType: "",
    neighborhoods: [] as string[],
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;

    if (
      type === "checkbox" &&
      e.target instanceof HTMLInputElement &&
      name === "neighborhoods"
    ) {
      const { checked } = e.target; // ✅ now checked exists

      const updated = checked
        ? [...filters.neighborhoods, value]
        : filters.neighborhoods.filter((n) => n !== value);

      setFilters({ ...filters, neighborhoods: updated });
    } else {
      setFilters({ ...filters, [name]: value });
    }
  };

  const priceRanges: { [key: string]: [number, number] } = {
    "under-1000": [0, 999],
    "1000-1100": [1000, 1100],
    "1100-1200": [1100, 1200],
    "1200-1300": [1200, 1300],
    "1300-1400": [1300, 1400],
    "1400-1500": [1400, 1500],
    "1500-1600": [1500, 1600],
    "1600-1700": [1600, 1700],
    "1700-1800": [1700, 1800],
    "1800-1900": [1800, 1900],
    "1900-2000": [1900, 2000],
    "2000+": [2001, Infinity],
  };

  const filteredListings = listings.filter((listing) => {
    const { beds, baths, price, propertyType, neighborhoods } = filters;

    const matchBeds =
      !beds || listing.beds.toLowerCase().includes(beds.toLowerCase());
    const matchBaths =
      !baths || listing.baths.toLowerCase().includes(baths.toLowerCase());
    const matchNeighborhoods =
      neighborhoods.length === 0 ||
      neighborhoods.includes("All of Houston") || // ✅ CORRECT
      neighborhoods.includes(listing.neighborhood);

    const matchPrice =
      !price ||
      (priceRanges[price] &&
        listing.priceValue >= priceRanges[price][0] &&
        listing.priceValue <= priceRanges[price][1]);
    const matchPropertyType =
      !propertyType ||
      (listing.propertyType &&
        listing.propertyType.toLowerCase() === propertyType.toLowerCase());

    return (
      matchBeds &&
      matchBaths &&
      matchNeighborhoods &&
      matchPrice &&
      matchPropertyType
    );
  });

  return (
    <div style={{ padding: "2rem", fontFamily: "'Inter', sans-serif" }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "1.5rem", color: "#222" }}>
        Apartments in Houston, Texas
      </h1>
      {/* ✅ Add AI Schema right after SchemaItemList */}
      <SchemaItemList city="Houston" listings={listings} />
      <AISchema city="Houston" listings={listings} />
      {/* Search Bar */}
      <div
        className="search-bar"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1rem",
          marginBottom: "2.5rem",
          padding: "1.75rem",
          backgroundColor: "#f9f9f9", // ✅ soft gray is back
          border: "1px solid rgba(0,0,0,0.08)", // ✅ clean definition
          borderRadius: "12px",
          boxShadow: "0 6px 18px rgba(0,0,0,0.06)", // ✅ modern depth
        }}
      >
        {/* PROPERTY TYPE */}
        <select
          name="propertyType"
          value={filters.propertyType}
          onChange={(e) => {
            const value = e.target.value;

            let newBeds = filters.beds;
            let newBaths = filters.baths;

            if (value === "Studio") {
              newBeds = "";
              newBaths = "";
            } else if (value === "Rental Home") {
              newBeds = "3"; // hard default to 3 beds
              newBaths = "2"; // hard default to 2 baths
            }

            setFilters((prev) => ({
              ...prev,
              propertyType: value,
              beds: newBeds,
              baths: newBaths,
            }));
          }}
        >
          <option value="">Property Type</option>
          <option value="Studio">Studio</option>
          <option value="Apartment">Apartment</option>
          <option value="Townhome">Townhome</option>
          <option value="Rental Home">Rental Home</option>
          <option value="Penthouse">Penthouse</option>
          <option value="Open to All">Open to All</option>
        </select>
        {/* BEDS */}
        <select
          name="beds"
          value={filters.beds}
          onChange={(e) => {
            const value = e.target.value;
            let newBaths = filters.baths;

            if (filters.propertyType === "Rental Home") {
              // force Rental Home to always stay at 3 beds, ignore user input
              return;
            }

            if (value === "1") {
              newBaths = "1"; // force 1 bath
            } else if (value === "2") {
              newBaths = "2"; // default 2 baths for 2 beds
            } else if (
              value === "3" &&
              [
                "Penthouse",
                "Rental Home",
                "Townhome",
                "Apartment",
                "Open to All",
              ].includes(filters.propertyType)
            ) {
              newBaths = "2"; // default 2 baths for 3 beds
            }

            setFilters((prev) => ({
              ...prev,
              beds: value,
              baths: newBaths,
            }));
          }}
          disabled={filters.propertyType === "Studio"}
        >
          <option value="">Beds</option>
          <option value="1" disabled={filters.propertyType === "Rental Home"}>
            1 Bed
          </option>
          <option value="2" disabled={filters.propertyType === "Rental Home"}>
            2 Beds
          </option>
          <option value="3">3 Beds</option>
        </select>
        {/* BATHS */}
        <select
          name="baths"
          value={filters.baths}
          onChange={handleChange}
          disabled={filters.propertyType === "Studio"}
        >
          <option value="">Baths</option>
          <option
            value="1"
            disabled={
              filters.beds === "1" ||
              filters.beds === "3" ||
              filters.propertyType === "Rental Home"
            }
          >
            1 Bath
          </option>
          <option value="2">2 Baths</option>
          <option
            value="3"
            disabled={filters.beds === "1" || filters.beds === "2"}
          >
            3 Baths
          </option>
        </select>
        <select name="price" value={filters.price} onChange={handleChange}>
          <option value="">Price Range</option>
          {Object.keys(priceRanges).map((key) => (
            <option key={key} value={key}>
              {key === "under-1000"
                ? "Under $1,000"
                : key === "2000+"
                ? "$2,000+"
                : `$${key.replace("-", " - $")}`}
            </option>
          ))}
        </select>
        <button className="search-button">Search</button>
        {/* Neighborhoods */}
        <div style={{ flexBasis: "100%", marginTop: "1rem" }}>
          <label
            style={{
              fontWeight: "bold",
              display: "block",
              marginBottom: "0.5rem",
            }}
          >
            Neighborhoods
          </label>

          <div style={{ display: "flex", gap: "1rem", marginBottom: "0.5rem" }}>
            <button
              type="button"
              onClick={() =>
                setFilters({
                  ...filters,
                  neighborhoods: ["All of Houston", ...allNeighborhoods],
                })
              }
            >
              Select All
            </button>
            <button
              type="button"
              onClick={() => setFilters({ ...filters, neighborhoods: [] })}
            >
              Deselect All
            </button>
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
            {/* ✅ All of Houston */}
            <label>
              <input
                type="checkbox"
                name="neighborhoods"
                value="All of Houston"
                checked={filters.neighborhoods.includes("All of Houston")}
                onChange={(e) => {
                  const { checked } = e.target;
                  if (checked) {
                    setFilters({
                      ...filters,
                      neighborhoods: ["All of Houston", ...allNeighborhoods],
                    });
                  } else {
                    setFilters({ ...filters, neighborhoods: [] });
                  }
                }}
              />
              All of Houston
            </label>

            {/* ✅ Regular neighborhoods */}
            {allNeighborhoods.map((neighborhood) => (
              <label key={neighborhood}>
                <input
                  type="checkbox"
                  name="neighborhoods"
                  value={neighborhood}
                  checked={
                    filters.neighborhoods.includes("All of Houston") ||
                    filters.neighborhoods.includes(neighborhood)
                  }
                  onChange={handleChange}
                />
                {neighborhood}
              </label>
            ))}
          </div>
        </div>{" "}
        {/* ✅ closes Neighborhoods block */}
      </div>{" "}
      {/* ✅ closes Search Bar */}
      {filteredListings.length === 0 && (
        <p
          style={{
            marginTop: "1rem",
            fontSize: "1rem",
            color: "#555",
            textAlign: "center",
          }}
        >
          No listings available right now. Contact me for a free list of the
          latest options!
        </p>
      )}
      {/* Listings */}
      <div className="card-grid">
        {filteredListings.map((listing, index) => (
          <ListingCard
            key={index}
            listing={listing}
            defaultImage={defaultImage}
          />
        ))}
      </div>
    </div>
  );
};

export default ApartmentListings;
