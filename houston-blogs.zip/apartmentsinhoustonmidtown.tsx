import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsInHoustonMidtown = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROPERTY_1 = ""; // e.g. "/images/Property1.jpg"
  const IMG_PROPERTY_2 = ""; // e.g. "/images/Property2.jpg"

  // Conditional video links
  const VIDEO_PROPERTY_1 = ""; // e.g. "https://youtube.com/..."
  const VIDEO_PROPERTY_2 = ""; // e.g. "https://youtube.com/..."

  const faqs = [
    {
      question: "Is Midtown Houston a good place to live?",
      answer:
        "Yes — Midtown is one of the most walkable and vibrant neighborhoods in Houston, popular with young professionals, students, and pet owners.",
    },
    {
      question: "What is the average rent for apartments in Midtown Houston?",
      answer:
        "Studios typically start around $1,300–$1,600, 1-bedrooms $1,600–$2,200+, and 2-bedrooms $2,200–$3,000+, depending on the property.",
    },
    {
      question: "Are Midtown Houston apartments pet-friendly?",
      answer:
        "Yes — most Midtown apartments are very pet-friendly and close to parks, trails, and pet-friendly restaurants.",
    },
    {
      question: "Do Midtown Houston apartments offer move-in specials?",
      answer:
        "Yes — many Midtown properties offer move-in specials such as 4–8 weeks free, waived fees, or discounted parking.",
    },
    {
      question: "Do you offer rebates for Midtown Houston apartments?",
      answer:
        "Yes — lease through us and get up to $200 cash rebate or 2 hours of free movers!",
    },
  ];

  return (
    <BlogLayout
      title="Apartments in Houston Midtown (2025)"
      publishDate="2025-07-06T12:00:00"
    keywords={[
      "luxury apartments midtown Houston",
      "apartments in midtown Houston",
      "Houston apartments in Midtown"
    ]}

      content={
        <>
          <p>
            Looking for apartments in Houston Midtown? Midtown is one of the
            city’s most popular neighborhoods for renters — offering
            walkability, vibrant nightlife, great dining, and easy access to
            Downtown, the Museum District, and the Medical Center. In this
            guide, we’ll show you why Midtown is a top choice and highlight some
            of the best apartment options.
          </p>

          <h2>Why Live in Houston Midtown?</h2>
          <ul>
            <li>Highly walkable — bars, restaurants, cafes, and parks</li>
            <li>Short commute to Downtown, Medical Center, and universities</li>
            <li>Popular with young professionals, students, and creatives</li>
            <li>
              Great pet-friendly community with dog parks and green spaces
            </li>
            <li>Variety of luxury and mid-rise apartment options</li>
            <li>Close to METRORail and bike-friendly streets</li>
          </ul>

          <h2>Average Rents for Apartments in Houston Midtown</h2>
          <ul>
            <li>Studios: $1,300–$1,600+</li>
            <li>1-Bedroom: $1,600–$2,200+</li>
            <li>2-Bedroom: $2,200–$3,000+</li>
            <li>Luxury Penthouses: $3,500+</li>
          </ul>

          <h2>Top Apartment Picks in Houston Midtown</h2>

          {/* Property 1 */}
          <h3>1. Camden McGowen Station</h3>
          {IMG_PROPERTY_1 && (
            <img
              src={IMG_PROPERTY_1}
              alt="Camden McGowen Station Midtown Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located right on the METRORail line, Camden McGowen Station offers
            upscale apartments with luxury finishes, a resort-style pool,
            rooftop lounge, and unbeatable Midtown location walkable to
            nightlife and dining.
          </p>

          {/* Property 2 */}
          <h3>2. Pearl Midtown</h3>
          {IMG_PROPERTY_2 && (
            <img
              src={IMG_PROPERTY_2}
              alt="Pearl Midtown Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Pearl Midtown is a popular luxury apartment community offering
            modern interiors, a resort-style pool, fitness center, and
            pet-friendly amenities — all in the heart of Midtown.
          </p>

          <h2>How We Help You Find Apartments in Houston Midtown</h2>
          <p>
            Our Houston apartment locators specialize in helping renters find
            the perfect Midtown apartment! We provide:
          </p>
          <ul>
            <li>Personalized lists of Midtown apartments</li>
            <li>Access to move-in specials and rebates</li>
            <li>Luxury and second-chance friendly options</li>
            <li>
              Up to $200 cash rebate or 2 hours of free movers when you lease
              through us!
            </li>
          </ul>

          <h2>Ready to Find an Apartment in Houston Midtown?</h2>
          <p>
            Contact us today and we’ll create a free, personalized list of
            Midtown Houston apartments — tailored to your budget, lifestyle, and
            move-in date!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsInHoustonMidtown;
