import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const BestLuxuryApartmentsHouston = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_500CRAWFORD = ""; // e.g. "/images/500-crawford.jpg"
  const IMG_HANOVERMONTROSE = "";
  const IMG_LATITUDEMEDCENTER = "";

  // Conditional video links
  const VIDEO_500CRAWFORD = "";
  const VIDEO_HANOVERMONTROSE = "";
  const VIDEO_LATITUDEMEDCENTER = "";

  const faqs = [
    {
      question:
        "What are the best neighborhoods for luxury apartments in Houston?",
      answer:
        "Popular areas include Downtown Houston, Midtown, Montrose, Museum District, River Oaks, and The Heights.",
    },
    {
      question: "What amenities do luxury apartments in Houston offer?",
      answer:
        "Resort-style pools, rooftop lounges, concierge service, valet parking, fitness centers, high-end finishes, pet spas, and smart home features.",
    },
    {
      question: "Is it expensive to rent a luxury apartment in Houston?",
      answer:
        "Luxury apartments start around $2,000/month and can go well above $5,000/month depending on location and amenities.",
    },
    {
      question: "Can I get move-in specials on luxury apartments?",
      answer:
        "Yes — many luxury apartments offer move-in specials such as 4–8 weeks free, waived fees, or discounted parking.",
    },
    {
      question: "Do you offer rebates for luxury apartments in Houston?",
      answer:
        "Yes — lease through us and get up to $200 cash rebate or 2 hours of free movers!",
    },
  ];

  return (
    <BlogLayout
      title="Best Luxury Apartments in Houston (2025)"
      publishDate="2025-07-06T12:00:00"
    keywords={[
      "luxury apartments Houston",
      "high-end rentals Houston",
      "Houston penthouses for rent"
    ]}

      content={
        <>
          <p>
            Searching for the best luxury apartments in Houston? You're in the
            right place. We've handpicked some of the top luxury apartment
            communities in the city — offering stunning interiors, upscale
            amenities, and unbeatable locations.
          </p>

          <h2>Why Live in a Luxury Apartment in Houston?</h2>
          <p>
            Houston offers a vibrant lifestyle with world-class dining,
            entertainment, and career opportunities. Renting a luxury apartment
            gives you access to premium amenities, modern design, and a
            convenient urban lifestyle.
          </p>

          <h2>Top Picks for Luxury Apartments in Houston</h2>

          <h3>1. 500 Crawford</h3>
          {IMG_500CRAWFORD && (
            <img
              src={IMG_500CRAWFORD}
              alt="500 Crawford Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_500CRAWFORD && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_500CRAWFORD}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located in Downtown Houston, 500 Crawford offers upscale apartments
            with designer finishes, a resort-style pool, rooftop deck, and easy
            access to Minute Maid Park and Discovery Green.
          </p>

          <h3>2. Hanover Montrose</h3>
          {IMG_HANOVERMONTROSE && (
            <img
              src={IMG_HANOVERMONTROSE}
              alt="Hanover Montrose Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_HANOVERMONTROSE && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_HANOVERMONTROSE}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Hanover Montrose is a luxury high-rise in the heart of Montrose with
            sweeping views, modern finishes, a rooftop pool, and walkable access
            to Houston’s best restaurants and nightlife.
          </p>

          <h3>3. Latitude Med Center</h3>
          {IMG_LATITUDEMEDCENTER && (
            <img
              src={IMG_LATITUDEMEDCENTER}
              alt="Latitude Med Center Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_LATITUDEMEDCENTER && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_LATITUDEMEDCENTER}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Latitude Med Center is a premier high-rise in Houston’s Medical
            Center with luxury amenities, concierge service, a sky lounge, and
            direct access to hospitals and museums.
          </p>

          <h2>How We Help You Find the Best Luxury Apartments</h2>
          <p>
            Our licensed Houston apartment locators have local expertise and
            insider access to move-in specials, rebates, and off-market
            listings. We’ll create a personalized list based on your needs —
            including luxury apartments with the best amenities and pricing.
          </p>

          <h2>Final Thoughts</h2>
          <p>
            Ready to tour the best luxury apartments in Houston? Contact us
            today to get a free, personalized list — and enjoy up to $200 cash
            rebate or free movers when you lease through us!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default BestLuxuryApartmentsHouston;
