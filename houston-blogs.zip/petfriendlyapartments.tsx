import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const PetFriendlyApartmentsHouston = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROPERTY_1 = ""; // e.g. "/images/Property1.jpg"
  const IMG_PROPERTY_2 = ""; // e.g. "/images/Property2.jpg"

  // Conditional video links
  const VIDEO_PROPERTY_1 = ""; // e.g. "https://youtube.com/..."
  const VIDEO_PROPERTY_2 = ""; // e.g. "https://youtube.com/..."

  const faqs = [
    {
      question: "Are there pet-friendly apartments in Houston?",
      answer:
        "Yes — most apartments in Houston are pet-friendly, though some may have breed or weight restrictions.",
    },
    {
      question: "Do pet-friendly apartments in Houston charge extra fees?",
      answer:
        "Most apartments charge a pet deposit and/or pet rent. Deposits typically range from $200–$500, and pet rent averages $15–$35/month.",
    },
    {
      question: "Which neighborhoods in Houston are best for pet owners?",
      answer:
        "Popular pet-friendly neighborhoods include The Heights, Midtown, Montrose, River Oaks, and areas near Memorial Park.",
    },
    {
      question: "Do luxury pet-friendly apartments offer extra amenities?",
      answer:
        "Yes — many luxury communities feature pet spas, dog parks, pet washing stations, and concierge pet services.",
    },
    {
      question: "Do you help renters with pets find apartments?",
      answer:
        "Yes — we specialize in helping pet owners find the best pet-friendly apartments in Houston!",
    },
  ];

  return (
    <BlogLayout
      title="Pet-Friendly Apartments in Houston (2025)"
      publishDate="2025-07-06T12:00:00"
      ctaType="newhome"
    keywords={[
      "pet friendly apartments Houston",
      "dog friendly apartments Houston",
      "cat friendly rentals Houston"
    ]}

      content={
        <>
          <p>
            Houston is one of the most pet-friendly cities in Texas — with
            thousands of apartment options welcoming pets of all shapes and
            sizes! Whether you're looking for on-site dog parks, pet spas, or
            just a great neighborhood for your furry friend, this guide covers
            the best pet-friendly areas, average rents, and a few top apartment
            picks.
          </p>

          <h2>Why Choose a Pet-Friendly Apartment in Houston?</h2>
          <ul>
            <li>
              Many communities feature on-site dog parks and pet amenities
            </li>
            <li>Access to Houston’s many parks and green spaces</li>
            <li>Year-round pet-friendly weather</li>
            <li>Abundance of pet-friendly restaurants, cafes, and events</li>
            <li>
              Specialized services like pet grooming, daycare, and concierge pet
              care
            </li>
          </ul>

          <h2>Top Pet-Friendly Neighborhoods in Houston</h2>
          <ul>
            <li>
              <strong>The Heights:</strong> Very walkable, with dog-friendly
              parks and cafes
            </li>
            <li>
              <strong>Midtown:</strong> Urban and vibrant, close to dog parks
              and trails
            </li>
            <li>
              <strong>Montrose:</strong> Artsy and pet-friendly with many
              boutique apartments
            </li>
            <li>
              <strong>River Oaks:</strong> Luxury apartments with on-site pet
              amenities
            </li>
            <li>
              <strong>Memorial Park / Washington Corridor:</strong> Great access
              to trails and outdoor spaces
            </li>
          </ul>

          <h2>Average Rents for Pet-Friendly Apartments</h2>
          <ul>
            <li>Studios: $1,200–$1,600+</li>
            <li>1-Bedroom: $1,400–$2,000+</li>
            <li>2-Bedroom: $1,800–$2,800+</li>
            <li>Luxury Pet-Friendly Penthouses: $4,000+</li>
          </ul>

          <h2>Top Pet-Friendly Apartment Picks in Houston</h2>

          {/* Property 1 */}
          <h3>1. The Essex House Apartments</h3>
          {IMG_PROPERTY_1 && (
            <img
              src={IMG_PROPERTY_1}
              alt="The Essex House Apartments Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located in the heart of Montrose, The Essex House offers spacious 1
            and 2-bedroom apartments with on-site dog park, pet washing station,
            and walkable access to pet-friendly cafes and parks.
          </p>

          {/* Property 2 */}
          <h3>2. The Residences at Memorial City</h3>
          {IMG_PROPERTY_2 && (
            <img
              src={IMG_PROPERTY_2}
              alt="The Residences at Memorial City Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            The Residences at Memorial City feature modern luxury apartments
            with a pet spa, on-site dog park, and easy access to the expansive
            trails of Memorial Park — perfect for active pet owners.
          </p>

          <h2>How We Help You Find Pet-Friendly Apartments</h2>
          <p>
            Our Houston apartment locators specialize in helping pet owners find
            the perfect home! We provide:
          </p>
          <ul>
            <li>Personalized lists of pet-friendly apartments</li>
            <li>Access to communities with dog parks, pet spas, and more</li>
            <li>Help navigating pet policies and fees</li>
            <li>
              Up to $200 cash rebate or 2 hours of free movers when you lease
              through us!
            </li>
          </ul>

          <h2>Ready to Find Your Pet-Friendly Apartment in Houston?</h2>
          <p>
            Contact us today for a free, personalized list of pet-friendly
            apartments in Houston — tailored to your budget, lifestyle, and pet
            needs!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default PetFriendlyApartmentsHouston;
