import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const AffordableApartmentsHouston = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROPERTY_1 = ""; // e.g. "/images/Property1.jpg"
  const IMG_PROPERTY_2 = ""; // e.g. "/images/Property2.jpg"

  // Conditional video links
  const VIDEO_PROPERTY_1 = ""; // e.g. "https://youtube.com/..."
  const VIDEO_PROPERTY_2 = ""; // e.g. "https://youtube.com/..."

  const faqs = [
    {
      question: "What are the most affordable neighborhoods in Houston?",
      answer:
        "Some of the most affordable neighborhoods include Alief, Greenspoint, Gulfton, Sharpstown, East End, and parts of North Houston.",
    },
    {
      question: "What is the average rent for affordable apartments in Houston?",
      answer:
        "Studios and 1-bedrooms can start around $1,000–$1,300/month. 2-bedrooms often start around $1,400–$1,800/month, depending on location and amenities.",
    },
    {
      question: "Can I find affordable apartments inside the Loop?",
      answer:
        "Yes — areas like East End, Near Northside, and Second Ward offer more affordable options inside the Loop.",
    },
    {
      question: "Do affordable apartments offer move-in specials?",
      answer:
        "Yes — many affordable apartments offer specials such as discounted rent, waived deposits, or free months.",
    },
    {
      question: "Do you help renters with bad credit find affordable apartments?",
      answer:
        "Yes — we specialize in helping renters with credit challenges find affordable apartments and second-chance friendly options.",
    },
  ];

  return (
    <BlogLayout
      title="Affordable Apartments in Houston (2025 Guide)"
      publishDate="2025-07-06T12:00:00"
      keywords={[
        "cheap apartments Houston",
        "budget rentals Houston",
        "affordable housing Houston",
      ]}
      content={
        <>
          <p>
            Searching for affordable apartments in Houston? Whether you're on a budget, a first-time renter, or simply want the best value, Houston offers a wide range of affordable apartments across the city. In this guide, we’ll highlight affordable neighborhoods, average rents, and showcase a few top affordable communities to get you started!
          </p>

          <h2>Why Look for Affordable Apartments in Houston?</h2>
          <ul>
            <li>Lower cost of living compared to many major US cities</li>
            <li>Diverse housing options across different neighborhoods</li>
            <li>Many properties offer move-in specials and discounts</li>
            <li>Access to public transit and major job centers</li>
            <li>Opportunities for second-chance renters</li>
          </ul>

          <h2>Top Neighborhoods for Affordable Apartments</h2>
          <ul>
            <li><strong>Alief:</strong> Known for affordability and diverse communities</li>
            <li><strong>Greenspoint:</strong> Budget-friendly apartments with frequent specials</li>
            <li><strong>Gulfton:</strong> Central location with lower-than-average rents</li>
            <li><strong>Sharpstown:</strong> Affordable with established community amenities</li>
            <li><strong>East End / Second Ward:</strong> Inside the Loop with budget options</li>
            <li><strong>Near Northside:</strong> Quick commute to Downtown with affordable rents</li>
          </ul>

          <h2>Average Rents for Affordable Apartments</h2>
          <ul>
            <li>Studios: $1,000–$1,300+</li>
            <li>1-Bedroom: $1,100–$1,500+</li>
            <li>2-Bedroom: $1,400–$1,800+</li>
            <li>3-Bedroom: $1,700–$2,300+</li>
          </ul>

          <h2>Top Affordable Apartment Picks in Houston</h2>

          {/* Property 1 */}
          <h3>1. The Ella Apartments</h3>
          {IMG_PROPERTY_1 && (
            <img
              src={IMG_PROPERTY_1}
              alt="The Ella Apartments Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located in North Houston, The Ella Apartments offer modern, budget-friendly 1 and 2-bedroom apartments with community amenities including a pool, fitness center, and gated access — all at an affordable price point.
          </p>

          {/* Property 2 */}
          <h3>2. The Daphne Apartments</h3>
          {IMG_PROPERTY_2 && (
            <img
              src={IMG_PROPERTY_2}
              alt="The Daphne Apartments Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            The Daphne offers stylish yet affordable apartments near the Gulfton area. Residents enjoy modern finishes, updated kitchens, and quick access to Southwest Freeway — perfect for commuters on a budget.
          </p>

          <h2>How We Help You Find Affordable Apartments</h2>
          <p>
            Our Houston apartment locators are experts at finding the best affordable apartments. We provide:
          </p>
          <ul>
            <li>Personalized lists of affordable apartments based on your budget</li>
            <li>Access to move-in specials and discounts</li>
            <li>Second-chance friendly apartment options</li>
            <li>Up to $200 cash rebate or 2 hours of free movers when you lease through us!</li>
          </ul>

          <h2>Ready to Find an Affordable Apartment in Houston?</h2>
          <p>
            Contact us today and we’ll create a personalized list of affordable apartments in Houston — matched to your lifestyle, budget, and move-in needs!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default AffordableApartmentsHouston;