import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsDowntownHouston = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROPERTY_1 = ""; // e.g. "/images/Property1.jpg"
  const IMG_PROPERTY_2 = ""; // e.g. "/images/Property2.jpg"

  // Conditional video links
  const VIDEO_PROPERTY_1 = ""; // e.g. "https://youtube.com/..."
  const VIDEO_PROPERTY_2 = ""; // e.g. "https://youtube.com/..."

  const faqs = [
    {
      question: "Is Downtown Houston a good place to live?",
      answer:
        "Yes — Downtown Houston offers a vibrant urban lifestyle, walkability, easy access to work, entertainment, and great luxury and mid-range apartment options.",
    },
    {
      question: "What is the average rent for apartments in Downtown Houston?",
      answer:
        "Studios typically start around $1,300–$1,600, 1-bedrooms $1,600–$2,200+, and 2-bedrooms $2,200–$3,500+, depending on the property.",
    },
    {
      question: "Are Downtown Houston apartments pet-friendly?",
      answer:
        "Yes — most Downtown apartments are very pet-friendly and offer amenities like pet spas and dog parks.",
    },
    {
      question: "Do Downtown Houston apartments offer move-in specials?",
      answer:
        "Yes — many Downtown properties offer move-in specials such as 4–8 weeks free, waived fees, or discounted parking.",
    },
    {
      question: "Do you offer rebates for Downtown Houston apartments?",
      answer:
        "Yes — lease through us and get up to $200 cash rebate or 2 hours of free movers!",
    },
  ];

  return (
    <BlogLayout
      title="Apartments Downtown Houston (2025)"
      publishDate="2025-07-06T12:00:00"
    keywords={[
      "luxury apartments downtown Houston",
      "apartments in downtown Houston",
        "downtown Houston apartments",
      "Houston apartments in downtown"
    ]}
      content={
        <>
          <p>
            Thinking about living in Downtown Houston? You're in the right
            place! Downtown offers one of the most exciting urban lifestyles in
            Texas — from world-class dining and entertainment to walkable access
            to major employers and public transit. In this guide, we’ll explore
            why so many renters choose Downtown, what to expect for pricing, and
            a few top apartment picks to get you started.
          </p>

          <h2>Why Live in Downtown Houston?</h2>
          <ul>
            <li>Walkable to offices, restaurants, bars, and parks</li>
            <li>Luxury and mid-range apartments with skyline views</li>
            <li>Major employers and headquarters located Downtown</li>
            <li>
              Close to Minute Maid Park, Toyota Center, and Theater District
            </li>
            <li>Access to METRORail and major freeways</li>
            <li>Vibrant nightlife and cultural scene</li>
          </ul>

          <h2>Average Rents for Apartments Downtown Houston</h2>
          <ul>
            <li>Studios: $1,300–$1,600+</li>
            <li>1-Bedroom: $1,600–$2,200+</li>
            <li>2-Bedroom: $2,200–$3,500+</li>
            <li>Luxury Penthouses: $4,000+</li>
          </ul>

          <h2>Top Apartment Picks in Downtown Houston</h2>

          {/* Property 1 */}
          <h3>1. 500 Crawford</h3>
          {IMG_PROPERTY_1 && (
            <img
              src={IMG_PROPERTY_1}
              alt="500 Crawford Downtown Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located in the heart of Downtown near Minute Maid Park, 500 Crawford
            offers upscale apartments with designer finishes, a resort-style
            pool, rooftop deck, and walkable access to dining, sports, and
            entertainment.
          </p>

          {/* Property 2 */}
          <h3>2. Market Square Tower</h3>
          {IMG_PROPERTY_2 && (
            <img
              src={IMG_PROPERTY_2}
              alt="Market Square Tower Downtown Houston"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROPERTY_2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROPERTY_2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Market Square Tower is one of Downtown Houston’s most iconic luxury
            high-rises — known for its glass-bottom rooftop pool, skyline views,
            and five-star amenities. Perfect for those seeking the ultimate
            luxury living experience.
          </p>

          <h2>How We Help You Find Apartments in Downtown Houston</h2>
          <p>
            Our Houston apartment locators specialize in helping renters find
            the best Downtown apartments! We provide:
          </p>
          <ul>
            <li>Personalized lists of Downtown apartments</li>
            <li>Access to move-in specials and rebates</li>
            <li>Luxury and second-chance friendly options</li>
            <li>
              Up to $200 cash rebate or 2 hours of free movers when you lease
              through us!
            </li>
          </ul>

          <h2>Ready to Find an Apartment in Downtown Houston?</h2>
          <p>
            Contact us today and we’ll create a free, personalized list of
            Downtown Houston apartments — tailored to your budget, lifestyle,
            and move-in date!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsDowntownHouston;
