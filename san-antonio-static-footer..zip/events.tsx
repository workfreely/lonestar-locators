// /src/san-antonio/events.tsx
import React from "react";
import BlogLayout from "../components/BlogLayout";

const SanAntonioEvents = () => {
  const faqs = [
    {
      question: "What are the biggest annual events in San Antonio?",
      answer:
        "Major annual events include Fiesta San Antonio, the Stock Show and Rodeo, holiday lights on the River Walk, King William Fair, and numerous cultural festivals throughout the year.",
    },
    {
      question: "Are there free events in San Antonio?",
      answer:
        "Yes, many events are free including the River Walk holiday lights, art walks, Market Square celebrations, and cultural community festivals.",
    },
    {
      question: "Does San Antonio have family friendly events?",
      answer:
        "Yes, many events are designed for families including the Stock Show and Rodeo, holiday parades, Market Square festivals, and seasonal concerts and exhibits.",
    },
    {
      question: "Does traffic increase during major events?",
      answer:
        "Traffic can increase near the River Walk, downtown, and major venues during large events. Arriving early or using rideshare can help avoid delays.",
    },
    {
      question: "When is the best time for events in San Antonio?",
      answer:
        "Spring for Fiesta and King William Fair, fall for outdoor festivals, winter for holiday events, and summer for concerts and river activities.",
    },
  ];

  return (
    <BlogLayout
      title="San Antonio Events - Best Events in San Antonio, Texas"
      publishDate={new Date().toISOString()}
      keywords={[
        "San Antonio events",
        "things to do in San Antonio",
        "San Antonio festivals",
        "San Antonio concerts",
        "San Antonio activities",
        "San Antonio family events",
      ]}
      address={{ addressLocality: "San Antonio", addressRegion: "Texas" }}
      content={
        <>
          {/* Intro */}
          <p style={{ marginBottom: "0.5rem" }}>
            <strong>
              Looking for the best events happening in San Antonio?
            </strong>{" "}
            The Alamo City hosts festivals, concerts, parades, cultural
            celebrations, and family events all year long.
          </p>
          <p style={{ marginBottom: "2.2rem", color: "#555" }}>
            Here is a chronological guide to the most popular annual events in
            San Antonio.
          </p>

          {/* JANUARY */}
          <div style={{ padding: ".1rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              New Year Eve Downtown Celebration
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 January One Downtown and River Walk</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              The city rings in the new year with outdoor concerts, food
              vendors, family activities, and a large fireworks show over
              downtown.
            </p>
            <a
              href="https://visitsanantonio.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Visitors Info
            </a>
          </div>

          {/* FEBRUARY TO MARCH */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              San Antonio Stock Show and Rodeo
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>
                📆 February through March Frost Bank Center and grounds
              </strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              One of the top rodeos in Texas with concerts, livestock shows,
              carnival rides, shopping, and daily family activities.
            </p>
            <a
              href="https://www.sarodeo.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* MARCH */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Contemporary Art Month CAM
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 March Citywide galleries and art venues</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A citywide celebration of contemporary art featuring exhibits,
              performances, installations, and artist showcases.
            </p>
            <a
              href="https://contemporaryartmonth.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* MARCH — ST PATRICKS */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              St Patricks River Parade and Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Mid March River Walk</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              The River Walk turns green for this celebration featuring live
              music, food vendors, a festival along the river, and festive boat
              floats.
            </p>
            <a
              href="https://www.thesanantonioriverwalk.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              River Walk Info
            </a>
          </div>

          {/* APRIL EVENTS — FIESTA */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Fiesta San Antonio
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Mid April through late April Citywide</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A historic multi week celebration with parades, concerts, food,
              cultural events, and citywide parties attracting millions of
              visitors.
            </p>
            <a
              href="https://fiestasanantonio.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* LATE APRIL — KING WILLIAM FAIR */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              King William Fair
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Late April King William Historic District</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              One of the most popular events during Fiesta featuring art
              vendors, food booths, live music, and a family fair in one of the
              city's oldest neighborhoods.
            </p>
            <a
              href="https://kingwilliamfair.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* SPRING AND YEAR ROUND — MARKET SQUARE */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Market Square Festivals and Celebrations
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>
                📆 Many weekends throughout the year Market Square
              </strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              A historic plaza hosting music events, cultural festivals, holiday
              markets, food celebrations, and family activities year round.
            </p>
            <a
              href="https://marketsquaresa.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* SUMMER — HEMISFAIR */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Hemisfair Summer Art and Music Events
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Summer weekends Hemisfair Downtown</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              Free outdoor concerts, art markets, cultural events, and family
              entertainment in one of the city's most popular public spaces.
            </p>
            <a
              href="https://hemisfair.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* FALL — JAZZ FESTIVALS */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Jazz San Antonio Live and Cultural Festivals
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Fall Civic Park and Downtown</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              Jazz festivals, cultural celebrations, and special performances
              featuring local and national talent in downtown San Antonio.
            </p>
            <a
              href="https://www.do210.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Local Calendar
            </a>
          </div>

          {/* NOVEMBER TO JANUARY — HOLIDAY LIGHTS */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Holiday Lights on the River Walk
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Late November through early January River Walk</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              Millions of lights decorate the River Walk creating one of the
              most beautiful free experiences of the holiday season.
            </p>
            <a
              href="https://www.sanantonioriverwalk.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* LATE NOVEMBER — HOLIDAY PARADE */}
          <div
            style={{
              padding: "1.5rem 0",
              borderBottom: "1px solid transparent",
            }}
          >
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Ford River Parade and Lighting Ceremony
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Late November River Walk</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              The official kickoff to the holiday season featuring illuminated
              floats, live performances, and the first lighting of the River
              Walk.
            </p>
            <a
              href="https://www.thesanantonioriverwalk.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Parade Details
            </a>
          </div>

          {/* Where events happen */}
          <h2 style={{ marginTop: "2rem" }}>Where Most Events Happen</h2>
          <p style={{ marginBottom: 0 }}>
            Most events take place around the River Walk, downtown, Market
            Square, Hemisfair, Civic Park, King William District, and major
            venues throughout the city.
          </p>
        </>
      }
      faqs={faqs}
    />
  );
};

export default SanAntonioEvents;
