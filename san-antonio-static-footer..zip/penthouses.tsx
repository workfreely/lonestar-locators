import React from "react";
import { Helmet } from "react-helmet";

const SanAntonioPenthouses = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>San Antonio Penthouses | Lone Star Locators</title>
        <meta
          name="description"
          content="Live above it all in a San Antonio penthouse. Discover luxury high-rise living with the best views, designer interiors, and move-in specials."
        />
      </Helmet>

      <h1>San Antonio Penthouses</h1>
      <p>
        Elevate your lifestyle with a stunning penthouse in San Antonio. These top-floor residences offer sweeping views of the city skyline, premium finishes, and unmatched privacy.
      </p>

      <p>
        Whether you're searching in Downtown, Alamo Heights, or The Pearl, Lone Star Locators will connect you with penthouses that feature rooftop terraces, high ceilings, and chef-style kitchens — plus cash rebates and move-in specials where available.
      </p>
    </div>
  );
};

export default SanAntonioPenthouses;