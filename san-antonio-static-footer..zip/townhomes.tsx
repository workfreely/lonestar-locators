import React from "react";
import { Helmet } from "react-helmet";

const SanAntonioTownhomes = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>San Antonio Townhomes | Lone Star Locators</title>
        <meta
          name="description"
          content="Explore the best townhomes for rent in San Antonio, TX. Get private garages, extra space, and move-in specials with Lone Star Locators."
        />
      </Helmet>

      <h1>San Antonio Townhomes</h1>
      <p>
        Searching for townhomes in San Antonio with the privacy of a home and the perks of luxury apartment living? We’ve got you covered.
        Many townhomes come with private garages, backyards, and spacious layouts that offer the perfect setup for working from home or raising a family.
      </p>

      <p>
        Our free locating service helps you find the best San Antonio townhome communities, including exclusive move-in specials and cash-back rebates.
      </p>
    </div>
  );
};

export default SanAntonioTownhomes;