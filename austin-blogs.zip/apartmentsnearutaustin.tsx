import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsNearUTAustin = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "What are the best areas to live near UT Austin?",
      answer:
        "Top areas include West Campus, North Campus, Hyde Park, East Austin, Downtown Austin, and Mueller District.",
    },
    {
      question: "How far are most apartments from campus?",
      answer:
        "Many apartments are within walking distance or a short bike/bus ride (5–15 minutes) from UT Austin.",
    },
    {
      question: "Are there affordable apartments near UT Austin?",
      answer:
        "Yes — we can help you find affordable options, especially in North Campus, East Austin, and select areas further north.",
    },
    {
      question: "Do apartments near UT Austin allow pets?",
      answer:
        "Many apartments near UT Austin are pet-friendly, but it varies by property — we help confirm pet policies.",
    },
    {
      question: "Can second-chance renters find apartments near UT Austin?",
      answer:
        "Yes — we work with second-chance friendly apartments near campus and throughout Central Austin.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments Near UT Austin"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "UT Austin apartments",
        "apartments near University of Texas",
        "West Campus Austin rentals",
      ]}
  
      content={
        <>
          <p>
            Whether you’re a student, graduate student, professor, or UT staff
            member, living near The University of Texas at Austin offers
            unbeatable convenience and a vibrant local lifestyle. In this guide,
            we’ll explore the best apartments near UT Austin and what to expect
            in each neighborhood.
          </p>

          <h2>Why Live Near UT Austin?</h2>
          <ul>
            <li>Walk or bike to campus — save time & money</li>
            <li>Vibrant student community and social scene</li>
            <li>Access to campus events, gyms, and libraries</li>
            <li>Walkable to coffee shops, restaurants, and bars</li>
            <li>Public transit and bike-friendly infrastructure</li>
            <li>Live near Downtown Austin entertainment</li>
          </ul>

          <h2>Best Areas to Live Near UT Austin</h2>
          <ul>
            <li>
              <strong>West Campus:</strong> The closest and most popular area
              for undergrads — walkable to UT.
            </li>
            <li>
              <strong>North Campus:</strong> Quieter and more residential —
              popular with grad students and staff.
            </li>
            <li>
              <strong>Hyde Park:</strong> Historic neighborhood with charming
              homes and boutique apartments.
            </li>
            <li>
              <strong>East Austin:</strong> Trendy and walkable — popular with
              grad students and young professionals.
            </li>
            <li>
              <strong>Downtown Austin:</strong> Luxury high-rises just south of
              campus — short bike/scooter ride.
            </li>
            <li>
              <strong>Mueller District:</strong> Modern apartments — about 10–15
              min drive or bus ride to UT.
            </li>
          </ul>

          <h2>Types of Apartments Near UT Austin</h2>
          <ul>
            <li>Student-oriented apartments with roommate floorplans</li>
            <li>Luxury high-rises with UT views (Downtown & West Campus)</li>
            <li>Affordable North Campus apartments for grad students</li>
            <li>Pet-friendly apartments with dog parks</li>
            <li>Second-chance friendly apartments near UT</li>
          </ul>

          <h2>Average Rents for Apartments Near UT Austin</h2>
          <ul>
            <li>Studios: $1,300–$1,700+</li>
            <li>1-Bedroom: $1,600–$2,200+</li>
            <li>2-Bedroom: $2,200–$3,200+</li>
            <li>3-Bedroom (great for roommates): $3,200–$4,200+</li>
          </ul>

          <h2>How We Help You Find Apartments Near UT Austin</h2>
          <p>
            Whether you’re an incoming student, grad student, or staff member,
            we help you:
          </p>
          <ul>
            <li>Find apartments within your preferred distance from UT</li>
            <li>Access move-in specials and discounts</li>
            <li>Locate second-chance friendly options</li>
            <li>Tour apartments virtually or in person</li>
            <li>Secure roommate-friendly leases if needed</li>
          </ul>

          <h2>Ready to Get Your Free List of Apartments Near UT Austin?</h2>
          <p>
            Moving to Austin for UT? Contact us today — we’ll send a free
            personalized list of apartments near UT Austin that fit your
            lifestyle and budget!
          </p>
          <p>Click below to get started!</p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsNearUTAustin;
