import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const BestLuxuryApartments = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_6G = "/images/residences-6g.jpg";
  const IMG_HANOVER = "";
  const IMG_700RIVER = "";

  // Conditional video links
  const VIDEO_6G = "https://www.youtube.com/watch?v=YOUR_VIDEO_ID";
  const VIDEO_HANOVER = "";
  const VIDEO_700RIVER = "";

  const faqs = [
    {
      question: "What are the best luxury apartments in Austin?",
      answer:
        "Residences at 6G, Hanover Republic Square, and 700 River are three of the top-rated luxury apartments in Austin for 2025.",
    },
    {
      question: "Do these apartments offer move-in specials?",
      answer:
        "Yes — many luxury communities offer move-in specials or incentives. Contact us to get the latest offers.",
    },
    {
      question: "Are these luxury apartments pet-friendly?",
      answer:
        "Yes — most luxury apartments in Austin are pet-friendly and offer amenities like pet spas and dog parks.",
    },
    {
      question: "Do you offer free locating services?",
      answer:
        "Yes — our apartment locating service is 100% free to renters. We’ll help you find the perfect luxury apartment and access exclusive deals.",
    },
    {
      question: "How do I schedule a tour?",
      answer:
        "Simply contact us through the Start Your Search form or reach out directly. We’ll schedule VIP tours for you.",
    },
  ];

  return (
    <BlogLayout
      title="Best Luxury Apartments in Austin (2025)"
      publishDate="2025-07-02T12:00:00"
    keywords={[
      "luxury apartments Austin",
      "high end rentals Austin",
      "Austin penthouse apartments",
    ]}

      content={
        <>
          <p>
            Searching for the best luxury apartments in Austin? You’re in the
            right place. In this updated guide, we’ve handpicked three of the
            absolute top luxury apartment communities in Austin — with stunning
            finishes, prime locations, and unbeatable amenities.
          </p>

          <h2>Why Live in a Luxury Apartment in Austin?</h2>
          <p>
            Austin offers a vibrant lifestyle, a booming tech scene, world-class
            dining, and plenty of outdoor activities. Renting a luxury apartment
            in Austin gives you access to gorgeous interiors, resort-style
            amenities, and walkable locations near the best the city has to
            offer.
          </p>

          <h2>Our Top Picks for Luxury Apartments in Austin</h2>

          <h3>1. Residences at 6G</h3>
          {IMG_6G && (
            <img
              src={IMG_6G}
              alt="Residences at 6G Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_6G && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_6G}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Residences at 6G is one of the most luxurious new communities in
            Austin, offering breathtaking views of Lady Bird Lake and downtown.
            With sleek modern finishes, spacious floorplans, and exclusive
            resident amenities, 6G sets a new standard for luxury living.
          </p>

          <h3>2. Hanover Republic Square</h3>
          {IMG_HANOVER && (
            <img
              src={IMG_HANOVER}
              alt="Hanover Republic Square Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_HANOVER && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_HANOVER}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Hanover Republic Square offers sophisticated high-rise living in the
            heart of downtown Austin. With floor-to-ceiling windows, top-tier
            appliances, and an incredible rooftop pool, this building is a
            favorite for professionals seeking both luxury and location.
          </p>

          <h3>3. 700 River</h3>
          {IMG_700RIVER && (
            <img
              src={IMG_700RIVER}
              alt="700 River Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_700RIVER && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_700RIVER}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            700 River delivers a unique blend of contemporary design and
            comfort, with unmatched river and skyline views. The community
            features a resident lounge, infinity pool, fitness studio, and
            designer interiors.
          </p>

          <h2>How to Find Your Perfect Luxury Apartment</h2>
          <p>
            As an apartment locating service, we have access to the latest
            pricing, move-in specials, and exclusive deals — including at the
            properties listed above. Our service is 100% free to you, and we can
            help you tour, apply, and even receive rebates or free movers.
          </p>

          <h2>Final Thoughts</h2>
          <p>
            Ready to tour these incredible luxury apartments in Austin? Contact
            us today for a personalized list and insider deals on top
            communities like Residences at 6G, Hanover Republic Square, 700
            River, and more!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px", fontWeight: "700" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default BestLuxuryApartments;
