import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsNearSouthCongress = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Where is South Congress located in Austin?",
      answer:
        "South Congress (SoCo) runs along South Congress Avenue, just south of Downtown Austin — from the river down to Ben White Blvd.",
    },
    {
      question: "Are there luxury apartments near South Congress?",
      answer:
        "Yes! Many luxury apartments are located within walking distance of SoCo’s shops, restaurants, and nightlife.",
    },
    {
      question: "Is SoCo a pet-friendly neighborhood?",
      answer:
        "Absolutely — South Congress is one of the most pet-friendly areas in Austin, with many dog-friendly patios and nearby parks.",
    },
    {
      question: "Are there second-chance apartments near SoCo?",
      answer:
        "Yes — we can help match second-chance renters with properties near SoCo that are flexible.",
    },
    {
      question: "Is parking available for apartments near SoCo?",
      answer:
        "Most apartments near SoCo include reserved parking or garage parking — though street parking can be competitive in some areas.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments Near South Congress (SoCo)"
      content={
        <>
          <p>
            South Congress — known as SoCo — is one of Austin’s most famous and
            beloved neighborhoods. Lined with boutique shops, live music venues,
            and iconic restaurants, SoCo offers a uniquely Austin vibe. If you
            want to live near the action, apartments near South Congress are an
            excellent choice!
          </p>

          <h2>Why Live Near South Congress?</h2>
          <p>Living near South Congress gives you:</p>
          <ul>
            <li>Walkable access to SoCo shops, bars, and restaurants</li>
            <li>Iconic Austin culture and live music</li>
            <li>Easy commute to Downtown Austin (just across the river)</li>
            <li>Quick access to Lady Bird Lake and hike-and-bike trail</li>
            <li>Pet-friendly neighborhood vibe</li>
          </ul>

          <h2>Top Areas to Live Near SoCo</h2>
          <ul>
            <li>
              <strong>South Congress Avenue itself:</strong> Walkable luxury and
              boutique apartments directly on or just off SoCo.
            </li>
            <li>
              <strong>Travis Heights:</strong> Beautiful historic neighborhood
              adjacent to SoCo — leafy streets and charming apartments.
            </li>
            <li>
              <strong>Bouldin Creek:</strong> Just west of SoCo — artsy vibe,
              walkable to both Downtown and South Congress.
            </li>
            <li>
              <strong>South First Street:</strong> Another great walkable
              district just blocks from SoCo.
            </li>
            <li>
              <strong>South Lamar (SoLa):</strong> A short drive or bike ride
              away with excellent modern apartment options.
            </li>
          </ul>

          <h2>Types of Apartments Near SoCo</h2>
          <ul>
            <li>Luxury mid-rise apartments with walkability</li>
            <li>Boutique apartment communities</li>
            <li>Historic apartment conversions in Travis Heights</li>
            <li>Pet-friendly apartments with dog parks</li>
            <li>Second-chance friendly options nearby</li>
          </ul>

          <h2>Average Rents Near South Congress</h2>
          <ul>
            <li>Studios: $1,700–$2,000+</li>
            <li>1-Bedroom: $1,900–$2,500+</li>
            <li>2-Bedroom: $2,700–$3,800+</li>
            <li>Luxury penthouses: $4,500+</li>
          </ul>

          <h2>How We Help Renters Find Apartments Near SoCo</h2>
          <p>
            SoCo apartments lease up FAST — and knowing where to look makes all
            the difference. We help clients:
          </p>
          <ul>
            <li>Find the best walkable apartments near SoCo</li>
            <li>Access move-in specials and incentives</li>
            <li>Identify pet-friendly and second-chance properties</li>
            <li>Tour top options quickly before they lease up</li>
          </ul>

          <h2>
            Ready to Get Your Free List of Apartments Near South Congress?
          </h2>
          <p>
            South Congress is one of Austin’s hottest rental markets. If you’re
            ready to live near SoCo, contact us today! We’ll create a
            personalized list based on your budget, timeline, and preferences.
          </p>
          <p>Click below to get started!</p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsNearSouthCongress;
