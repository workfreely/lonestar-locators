import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsInDeepEllumDallas = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is Deep Ellum a good place to live in Dallas?",
      answer:
        "Yes — Deep Ellum is a vibrant and eclectic neighborhood known for its music venues, art scene, trendy restaurants, and nightlife. It’s ideal for those seeking a creative and urban lifestyle.",
    },
    {
      question: "How much does it cost to rent in Deep Ellum?",
      answer:
        "1-bedroom apartments typically start around $1,500–$1,800, with luxury units ranging $2,200+ depending on building and amenities.",
    },
    {
      question: "Is Deep Ellum walkable?",
      answer:
        "Yes — Deep Ellum is very walkable, with most apartments located within blocks of dining, nightlife, and entertainment.",
    },
    {
      question: "Are there luxury apartments in Deep Ellum?",
      answer:
        "Yes — Deep Ellum has several newer luxury apartment buildings with rooftop pools, skyline views, and modern amenities.",
    },
    {
      question: "Can you help me find specials in Deep Ellum?",
      answer:
        "Absolutely — we track the latest move-in specials and rebates for Deep Ellum apartments. Contact us for a personalized list!",
    },
  ];

  return (
    <BlogLayout
      title="Apartments in Deep Ellum Dallas (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "Deep Ellum apartments",
        "lofts in Deep Ellum Dallas",
        "apartments near music venues Dallas",
      ]}
      content={
        <>
          <p>
            Deep Ellum is one of Dallas’ most exciting neighborhoods — known for
            its rich history, music venues, street art, and thriving nightlife.
            If you’re looking for an apartment in Deep Ellum, this guide will
            help you explore the best options!
          </p>

          <h2>Why Live in Deep Ellum?</h2>
          <ul>
            <li>Walkable to bars, restaurants, and live music venues</li>
            <li>Vibrant street art and creative culture</li>
            <li>Trendy lofts and modern luxury apartments</li>
            <li>Easy access to Downtown Dallas and major highways</li>
            <li>Pet-friendly communities</li>
            <li>Active social scene and community events</li>
          </ul>

          <h2>Top Apartments in Deep Ellum Dallas</h2>

          <h3>1. The Case Building</h3>
          <img
            src="/images/the-case-building.jpg"
            alt="The Case Building Deep Ellum Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            The Case Building offers industrial-chic loft-style apartments with
            floor-to-ceiling windows, modern kitchens, and a rooftop lounge.
          </p>

          <h3>2. The Epic</h3>
          <img
            src="/images/the-epic.jpg"
            alt="The Epic Deep Ellum Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            A premier luxury high-rise offering breathtaking city views, a
            resort-style pool, and direct access to Deep Ellum’s entertainment
            district.
          </p>

          <h3>3. Novel Deep Ellum</h3>
          <img
            src="/images/novel-deep-ellum.jpg"
            alt="Novel Deep Ellum Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Stylish and modern apartments with high-end finishes, co-working
            spaces, and proximity to all the best that Deep Ellum has to offer.
          </p>

          <h2>How We Can Help You Find the Best Deep Ellum Apartments</h2>
          <ul>
            <li>We track the latest move-in specials and best deals</li>
            <li>
              We’ll send you a personalized list based on your budget &
              preferences
            </li>
            <li>We know which properties are the most pet-friendly</li>
            <li>We can schedule tours or provide virtual tours</li>
            <li>Our service is 100% free — no obligation</li>
          </ul>

          <h2>Ready to Find Your Deep Ellum Apartment?</h2>
          <p>
            Contact us today for a free personalized list of the best apartments
            in Deep Ellum — with current specials and exclusive rebates. Click
            below to get started!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsInDeepEllumDallas;
