import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const AffordableApartmentsUnder1200Dallas = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROP1 = ""; // Add image URL if desired
  const IMG_PROP2 = "";
  const IMG_PROP3 = "";

  // Conditional video links
  const VIDEO_PROP1 = "";
  const VIDEO_PROP2 = "";
  const VIDEO_PROP3 = "";

  const faqs = [
    {
      question: "Can I still find apartments under $1,200 in Dallas?",
      answer:
        "Yes — there are still many good apartments under $1,200, especially in East Dallas, North Dallas, Lake Highlands, Oak Cliff, and areas just outside Downtown.",
    },
    {
      question: "Do affordable apartments in Dallas offer move-in specials?",
      answer:
        "Yes — many affordable apartments offer great specials like 1 month free, discounted rents, waived deposits, or free parking.",
    },
    {
      question: "Are second-chance apartments available under $1,200?",
      answer:
        "Yes — we have second-chance friendly options under $1,200 in our private locator database. Just contact us for a personalized list.",
    },
    {
      question: "What’s the average rent for a 1-bedroom under $1,200?",
      answer:
        "You can typically find 1-bedrooms from $1,000–$1,200 in good areas of Dallas — and sometimes 2-bedrooms with move-in specials.",
    },
    {
      question: "How can I get a list of apartments under $1,200?",
      answer:
        "Contact us! We’ll send you a free personalized list of apartments under $1,200 in Dallas based on your move-in date, budget, and preferences.",
    },
  ];

  return (
    <BlogLayout
      title="Affordable Apartments Under $1,200 in Dallas (2025)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "affordable apartments Dallas",
        "apartments under $1200 Dallas",
        "cheap rentals Dallas",
      ]}
      content={
        <>
          <p>
            Searching for an apartment in Dallas under $1,200? You're in the
            right place! While rents in Dallas have gone up, there are still
            many affordable apartments under $1,200 if you know where to look —
            and we do.
          </p>

          <h2>Why Choose Apartments Under $1,200?</h2>
          <p>
            Sticking to a smart budget doesn’t mean sacrificing quality.
            Neighborhoods like East Dallas, Lake Highlands, North Dallas, and
            parts of Oak Cliff still offer beautiful apartments at affordable
            prices — many with upgraded features, pools, and fitness centers.
          </p>

          <h2>Our Top Picks for Affordable Apartments Under $1,200</h2>

          <h3>1. East Dallas Apartment</h3>
          {IMG_PROP1 && (
            <img
              src={IMG_PROP1}
              alt="East Dallas Affordable Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            East Dallas remains one of the best areas to find affordable
            apartments — with tree-lined streets, walkable coffee shops, and
            quick access to Downtown.
          </p>

          <h3>2. Lake Highlands Apartment</h3>
          {IMG_PROP2 && (
            <img
              src={IMG_PROP2}
              alt="Lake Highlands Affordable Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Lake Highlands offers newer affordable apartments with pools and
            modern amenities — a popular choice for renters wanting more space
            at a great value.
          </p>

          <h3>3. North Dallas Apartment</h3>
          {IMG_PROP3 && (
            <img
              src={IMG_PROP3}
              alt="North Dallas Affordable Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP3 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP3}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            North Dallas has an abundance of affordable apartment options —
            perfect for renters seeking easy freeway access and proximity to
            shopping and entertainment.
          </p>

          <h2>How We Help You Find the Best Deals</h2>
          <p>
            As a local apartment locator, we have an up-to-date list of the best
            affordable apartments under $1,200 — including those offering
            specials, rebates, and second-chance options. We’ll create a
            personalized list for you — saving you hours of research and helping
            you avoid properties that don’t fit your needs.
          </p>

          <h2>Ready to Get Your Free List?</h2>
          <p>
            Contact us today and we’ll send a free, no-obligation list of the
            best apartments under $1,200 in Dallas — matched to your budget and
            move-in timeline!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px", color: "#000", fontWeight: "bold" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default AffordableApartmentsUnder1200Dallas;
