import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsInDallasArtsDistrict = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is the Dallas Arts District a good place to live?",
      answer:
        "Yes — the Dallas Arts District is an upscale, walkable neighborhood with luxury high-rises, cultural attractions, and close proximity to Downtown and Uptown.",
    },
    {
      question: "How much does it cost to rent in the Arts District?",
      answer:
        "Luxury 1-bedroom apartments typically start around $2,000–$2,800+, with penthouse units exceeding $4,000 per month.",
    },
    {
      question: "Is the Arts District walkable?",
      answer:
        "Yes — it is one of the most walkable neighborhoods in Dallas, with museums, performance venues, restaurants, and parks all nearby.",
    },
    {
      question: "Are apartments in the Arts District pet-friendly?",
      answer:
        "Many luxury apartments in the Arts District are pet-friendly and offer pet spas, dog parks, and nearby trails.",
    },
    {
      question: "Can you help me find specials in the Arts District?",
      answer:
        "Yes — we track move-in specials and can provide you with a free personalized list of luxury apartments in the Dallas Arts District.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments in Dallas Arts District (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "Dallas Arts District apartments",
        "apartments near Dallas Museum of Art",
        "luxury rentals downtown Dallas",
      ]}
  
      content={
        <>
          <p>
            The Dallas Arts District is one of the city’s most sophisticated and
            walkable neighborhoods — home to world-class museums, performance
            venues, and luxury living. If you’re looking for an upscale
            apartment in the Dallas Arts District, this guide will help you
            explore your options!
          </p>

          <h2>Why Live in the Dallas Arts District?</h2>
          <ul>
            <li>Luxury high-rises with skyline views</li>
            <li>Walkability to museums, theaters, and performance halls</li>
            <li>Close to Downtown, Uptown, and Klyde Warren Park</li>
            <li>Pet-friendly communities with upscale amenities</li>
            <li>
              Proximity to Dallas’ top restaurants and cultural attractions
            </li>
            <li>Popular with professionals, executives, and creatives</li>
          </ul>

          <h2>Top Apartments in Dallas Arts District</h2>

          <h3>1. Atelier Apartments</h3>
          <img
            src="/images/atelier-apartments.jpg"
            alt="Atelier Apartments Dallas Arts District"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            One of Dallas’ newest and most luxurious high-rises — with stunning
            views, modern finishes, and world-class amenities.
          </p>

          <h3>2. Hall Arts Residences</h3>
          <img
            src="/images/hall-arts-residences.jpg"
            alt="Hall Arts Residences Dallas"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Ultra-luxury condominiums and apartments in the heart of the Dallas
            Arts District — offering unmatched elegance and privacy.
          </p>

          <h3>3. AMLI Fountain Place</h3>
          <img
            src="/images/amli-fountain-place.jpg"
            alt="AMLI Fountain Place Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Iconic glass tower offering luxury apartments with panoramic views
            and resort-style amenities.
          </p>

          <h2>How We Help You Find the Best Arts District Apartments</h2>
          <ul>
            <li>We track the latest luxury specials and penthouse offers</li>
            <li>
              We know which buildings are most pet-friendly and amenity-rich
            </li>
            <li>
              We match you with apartments based on your lifestyle & budget
            </li>
            <li>We save you time & money — our service is 100% free!</li>
          </ul>

          <h2>Ready to Tour Dallas Arts District Apartments?</h2>
          <p>
            Want to find your perfect luxury apartment in the Dallas Arts
            District? Contact us today for a free personalized list — with the
            latest specials and exclusive rebates. Click below to get started!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsInDallasArtsDistrict;
