import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsInDallasMedicalDistrict = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is the Dallas Medical District a good place to live?",
      answer:
        "Yes — the Dallas Medical District is a very convenient place to live for healthcare workers, med students, residents, and professionals who want to be close to work and Downtown Dallas.",
    },
    {
      question: "How much does it cost to rent in the Medical District?",
      answer:
        "Apartments in the Dallas Medical District typically range from $1,300–$1,900 for 1-bedrooms, with luxury options going above $2,200.",
    },
    {
      question: "Is the Medical District area walkable?",
      answer:
        "Parts of the Medical District are walkable — especially newer apartment communities designed for professionals and students working in the area.",
    },
    {
      question: "Are Medical District apartments pet-friendly?",
      answer:
        "Many apartments in the Medical District are pet-friendly and offer dog parks, pet amenities, and proximity to walking trails.",
    },
    {
      question: "Can you help me find specials near the Medical District?",
      answer:
        "Yes — we track move-in specials and can provide you with a free personalized list of Medical District apartments with current offers.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments in Dallas Medical District (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
    keywords={[
      "Dallas Medical District apartments",
      "apartments near Parkland Hospital",
      "UT Southwestern rentals",
    ]}

      content={
        <>
          <p>
            Looking for an apartment near the Dallas Medical District? Whether
            you’re a healthcare professional, med student, or staff member, this
            guide will help you find the best apartments in this growing area!
          </p>

          <h2>Why Live in the Dallas Medical District?</h2>
          <ul>
            <li>Convenient location for medical workers and students</li>
            <li>
              Close to Parkland Hospital, UT Southwestern, Children’s Medical
              Center, and more
            </li>
            <li>Short commute to Downtown and Uptown Dallas</li>
            <li>Pet-friendly apartment options available</li>
            <li>Modern communities with excellent amenities</li>
            <li>Walkability and proximity to DART stations</li>
          </ul>

          <h2>Top Apartments in Dallas Medical District</h2>

          <h3>1. The Southwestern</h3>
          <img
            src="/images/the-southwestern.jpg"
            alt="The Southwestern Dallas Medical District apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Modern, upscale apartments close to UT Southwestern — ideal for
            medical professionals and grad students.
          </p>

          <h3>2. Inwood Station</h3>
          <img
            src="/images/inwood-station.jpg"
            alt="Inwood Station Dallas Medical District apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Luxury apartments with easy access to Parkland, UT Southwestern, and
            public transportation — with excellent amenities.
          </p>

          <h3>3. The Dunhill Medical District</h3>
          <img
            src="/images/the-dunhill.jpg"
            alt="The Dunhill Dallas Medical District apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Stylish apartments designed for professionals working in the Medical
            District — offering convenience and value.
          </p>

          <h2>How We Help You Find the Best Medical District Apartments</h2>
          <ul>
            <li>We track move-in specials, discounts, and rebates</li>
            <li>
              We know which communities cater to healthcare workers and students
            </li>
            <li>
              We can match you to apartments based on your schedule and budget
            </li>
            <li>We save you time & money — our service is 100% free!</li>
          </ul>

          <h2>Ready to Tour Dallas Medical District Apartments?</h2>
          <p>
            Want to find your perfect apartment near the Dallas Medical
            District? Contact us today for a free personalized list — with the
            latest specials and exclusive rebates. Click below to get started!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsInDallasMedicalDistrict;
