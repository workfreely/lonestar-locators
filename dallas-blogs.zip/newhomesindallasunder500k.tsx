import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";
import BuyNewHomeExitIntentPopup from "../../components/BuyNewHomeExitIntentPopup";
import NewHomeFooter from "../../components/NewHomeFooter";
import { Helmet } from "react-helmet";

const NewHomesInDallasUnder500k = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const toggleAccordion = (idx: number) =>
    setActiveIndex(activeIndex === idx ? null : idx);

  const IMG_BLURRED =
    "https://res.cloudinary.com/dxtiguwzm/image/upload/v1760740971/new-construction-homes-list-san-_antonio-austin-dallas-houston_cvp0yz.png";

  const faqs = [
    {
      question: "What types of homes are available under $500K in Dallas?",
      answer:
        "In this price range, you'll often find 4–6 bedroom homes with upgraded features like granite counters, smart-home packages, and premium flooring.",
    },
    {
      question: "Can I get more incentives at this level?",
      answer:
        "Yes — builders often offer better incentives at $450K–$500K, including tax credits, upgrade packages, and rate buydowns.",
    },
    {
      question:
        "Which neighborhoods offer Dallas new construction under $500K?",
      answer:
        "Suburbs like Frisco, McKinney, Rockwall, and Carrollton regularly have new builds in this range, often in master-planned communities.",
    },
    {
      question: "Are there energy-efficient options?",
      answer:
        "Definitely — these homes typically include efficient HVAC, insulation, LED lighting, and sometimes solar-ready packages.",
    },
    {
      question: "How do I get started?",
      answer:
        "Click “Start Your Search” below to tell us what you're looking for — we’ll send a personalized list of Dallas new homes under $500K.",
    },
  ];

  return (
    <BlogLayout
      title="New Homes in Dallas Under $500K | 2025 Premium New Construction"
      publishDate="2025-07-02T12:00:00"
      ctaType="newhome"
      keywords={[
        "new homes under 500k Dallas",
        "Dallas new construction homes",
        "move-in ready homes Dallas",
      ]}
      content={
        <>
          <Helmet>
            <title>
              New Homes in Dallas Under $500K | 2025 Premium New Construction
            </title>
            <meta
              name="description"
              content="Explore premium new homes in Dallas under $500K. Discover bigger floor plans, builder upgrades, tax incentives & smart‑home features."
            />
            <meta
              name="keywords"
              content="new homes in Dallas under 500k, premium new construction Dallas, Dallas new homes 500k, builder upgrades Dallas, energy efficient new homes"
            />
            <script type="application/ld+json">
              {`
              {
                "@context": "https://schema.org",
                "@type": "Article",
                "headline": "New Homes in Dallas Under $500K | 2025 Premium New Construction",
                "description": "Discover spacious premium homes in Dallas under $500K with premium finishes, smart-home tech, and builder incentives. Get your personalized list today!",
                "author": {
                  "@type": "Organization",
                  "name": "Lone Star Locators"
                },
                "publisher": {
                  "@type": "Organization",
                  "name": "Lone Star Locators",
                  "logo": {
                    "@type": "ImageObject",
                    "url": "https://res.cloudinary.com/dxtiguwzm/image/upload/v1748223464/lone-star-locators-white-logo-footer_dyrwka.png"
                  }
                },
                "datePublished": "2025-06-10",
                "mainEntityOfPage": {
                  "@type": "WebPage",
                  "@id": "https://yourdomain.com/dallas/new-homes-in-dallas-under-500k"
                }
              }
              `}
            </script>
          </Helmet>

          <p>
            Looking to upgrade your home this year? With a budget under $500K,
            you can access premium new construction in top Dallas suburbs,
            featuring spacious layouts, modern finishes, and smart‑home
            upgrades.
          </p>

          <h2>What to Expect at This Price</h2>
          <ul className="checklist">
            <li>
              ✅ Large 4–6 bedroom homes (2,500+ sq ft) with multi-car garages
            </li>
            <li>
              ✅ High-end finishes: granite/quartz countertops, tile, stainless
              appliances
            </li>
            <li>
              ✅ Smart-home features and energy-efficiency upgrades included
            </li>
          </ul>

          <h2>Top Areas Under $500K</h2>
          <ul className="checklist">
            <li>
              ✅ <strong>Frisco & McKinney:</strong> Rapid growth, excellent
              schools, easy access to Dallas
            </li>
            <li>
              ✅ <strong>Rockwall & Heath:</strong> Lakeside living with upscale
              floor plans
            </li>
            <li>
              ✅ <strong>Carrollton & Plano:</strong> Proximity to employment
              hubs with newer communities
            </li>
          </ul>

          <h2>How We Help You Get the Best Deals</h2>
          <ul className="checklist">
            <li>
              ✅ We curate premium listings under $500K tailored to your
              preferences
            </li>
            <li>
              ✅ Exclusive builder incentives on smart-home and energy upgrades
            </li>
            <li>
              ✅ Assistance with financing, tax, and first-time buyer programs
            </li>
            <li>✅ Zero cost to you — builders cover our fees</li>
          </ul>

          <h2>Preview of Our Premium Deals</h2>
          {IMG_BLURRED && (
            <img
              src={IMG_BLURRED}
              alt="Dallas New Homes List Preview"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
                border: "1px solid #ddd",
              }}
            />
          )}

          <p
            style={{
              backgroundColor: "#e6f4ea",
              padding: "12px",
              borderRadius: "6px",
              fontWeight: "bold",
            }}
          >
            <span>
              Click{" "}
              <span style={{ color: "#007a38", fontWeight: "bold" }}>
                (Start Your Search)
              </span>{" "}
              below to tell us what you're looking for — we’ll send a
              personalized list of Dallas new homes under $500K!
            </span>
          </p>

          <h2>Next Steps</h2>
          <p>
            Let’s help you find your dream home with premium features and value.
            Start now before prices rise even higher!
          </p>

          <h2 style={{ marginTop: "50px", fontWeight: "700" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((f, i) => (
              <div key={i} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(i)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {f.question}
                </div>
                {activeIndex === i && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {f.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};
// <NewHomeFooter citySlug="austin" /> // TODO: Move into return block later
<BuyNewHomeExitIntentPopup />;
export default NewHomesInDallasUnder500k;
