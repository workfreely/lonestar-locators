import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsInOakLawnDallas = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is Oak Lawn a good neighborhood to live in Dallas?",
      answer:
        "Yes — Oak Lawn is a very popular Dallas neighborhood known for its vibrant nightlife, diversity, dining, and proximity to Uptown and Downtown.",
    },
    {
      question: "How much does it cost to rent in Oak Lawn?",
      answer:
        "1-bedroom apartments typically range from $1,600–$2,200, with luxury options exceeding $2,500 depending on views and amenities.",
    },
    {
      question: "Is Oak Lawn walkable?",
      answer:
        "Oak Lawn is one of the most walkable neighborhoods in Dallas — you can easily access restaurants, bars, cafes, and shops.",
    },
    {
      question: "Are Oak Lawn apartments pet-friendly?",
      answer:
        "Yes — most Oak Lawn apartments are pet-friendly and many offer dog parks, pet washing stations, and nearby green spaces.",
    },
    {
      question: "Can you help me find specials in Oak Lawn?",
      answer:
        "Yes — we monitor move-in specials and can provide you with a free personalized list of Oak Lawn apartments with the best deals.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments in Oak Lawn Dallas (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "Oak Lawn apartments Dallas",
        "apartments near Uptown Dallas",
        "Cedar Springs rentals",
      ]}
      content={
        <>
          <p>
            Oak Lawn is one of Dallas’ most vibrant and diverse neighborhoods —
            with great dining, nightlife, and a highly walkable vibe. If you’re
            looking for an apartment in Oak Lawn, this guide will help you
            explore the best options!
          </p>

          <h2>Why Live in Oak Lawn?</h2>
          <ul>
            <li>Highly walkable — close to restaurants, bars, and cafes</li>
            <li>Very LGBTQ+ friendly and inclusive community</li>
            <li>Short commute to Downtown and Uptown</li>
            <li>Luxury and mid-rise apartment options</li>
            <li>Pet-friendly communities</li>
            <li>Vibrant nightlife and social scene</li>
          </ul>

          <h2>Top Apartments in Oak Lawn Dallas</h2>

          <h3>1. The Shelby</h3>
          <img
            src="/images/the-shelby.jpg"
            alt="The Shelby Oak Lawn Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Stylish boutique apartments with modern interiors and easy
            walkability to Oak Lawn’s best restaurants and nightlife.
          </p>

          <h3>2. The Maple District Lofts</h3>
          <img
            src="/images/maple-district-lofts.jpg"
            alt="Maple District Lofts Oak Lawn Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Industrial-inspired lofts with open floor plans, concrete floors,
            and a walkable location near the Medical District and Oak Lawn.
          </p>

          <h3>3. Bell Katy Trail</h3>
          <img
            src="/images/bell-katy-trail.jpg"
            alt="Bell Katy Trail Oak Lawn Dallas apartment"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Upscale apartments located steps from the Katy Trail — offering
            resort-style amenities and walkability to Oak Lawn & Uptown.
          </p>

          <h2>How We Help You Find the Best Oak Lawn Apartments</h2>
          <ul>
            <li>We track the latest Oak Lawn specials & rebates</li>
            <li>We know the newest luxury and boutique communities</li>
            <li>We match you to apartments based on your needs & budget</li>
            <li>We know which communities are pet-friendly</li>
            <li>Our service is 100% free — we save you time & money!</li>
          </ul>

          <h2>Ready to Tour Oak Lawn Dallas Apartments?</h2>
          <p>
            Want to find your perfect apartment in Oak Lawn? Contact us today
            and we’ll send you a free personalized list — with current specials
            and exclusive rebates. Click below to get started!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsInOakLawnDallas;
