import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";
import BuyNewHomeExitIntentPopup from "../../components/BuyNewHomeExitIntentPopup";
import NewHomeFooter from "../../components/NewHomeFooter";
import { Helmet } from "react-helmet";

const NewHomesInDallasUnder400k = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const toggleAccordion = (idx: number) =>
    setActiveIndex(activeIndex === idx ? null : idx);

  const IMG_BLURRED =
    "https://res.cloudinary.com/dxtiguwzm/image/upload/v1760740971/new-construction-homes-list-san-_antonio-austin-dallas-houston_cvp0yz.png";

  const faqs = [
    {
      question: "What kind of new homes can I find in Dallas under $400K?",
      answer:
        "You’ll typically find 3–5 bedroom homes with 2,000+ sq ft, modern finishes, and builder incentives in suburbs and emerging neighborhoods.",
    },
    {
      question: "Are there builder incentives in this price range?",
      answer:
        "Yes, many builders offer closing cost assistance, rate buydowns, and free upgrades. We’ll help you uncover the best available deals.",
    },
    {
      question: "Can I buy with an FHA or VA loan?",
      answer:
        "Absolutely. Most new home communities in Dallas accept FHA and VA financing. Some even offer special military or first-responder programs.",
    },
    {
      question: "Where are these homes located?",
      answer:
        "Think suburbs like Mesquite, Forney, Little Elm, and Red Oak. These areas are growing quickly and offer great schools, space, and value.",
    },
    {
      question: "How do I get started?",
      answer:
        "Click “Start Your Search” below to tell us what you're looking for — we’ll send you a personalized list of Dallas new homes under $400K.",
    },
  ];

  return (
    <BlogLayout
      title="New Homes in Dallas Under $400K | 2025 Affordable New Construction"
      publishDate="2025-07-02T12:00:00"
      ctaType="newhome"
      keywords={[
        "new homes under 400k Dallas",
        "Dallas TX new homes",
        "new construction homes Dallas",
        "homes near Dallas under 400k",
      ]}
      content={
        <>
          <Helmet>
            <title>
              New Homes in Dallas Under $400K | 2025 Affordable New Construction
            </title>
            <meta
              name="description"
              content="Looking for new homes in Dallas under $400K? Explore affordable new construction in DFW suburbs with builder incentives, FHA/VA options, and first-time buyer perks."
            />
            <meta
              name="keywords"
              content="new homes in Dallas under 400k, Dallas new construction homes, affordable homes DFW, FHA VA new homes Dallas, builder incentives Dallas"
            />
            <script type="application/ld+json">
              {`
              {
                "@context": "https://schema.org",
                "@type": "Article",
                "headline": "New Homes in Dallas Under $400K | 2025 Affordable New Construction",
                "description": "Discover new construction homes in Dallas under $400K. Learn about builder incentives, FHA/VA financing, and how to get a personalized list today.",
                "author": {
                  "@type": "Organization",
                  "name": "Lone Star Locators"
                },
                "publisher": {
                  "@type": "Organization",
                  "name": "Lone Star Locators",
                  "logo": {
                    "@type": "ImageObject",
                    "url": "https://res.cloudinary.com/dxtiguwzm/image/upload/v1748223464/lone-star-locators-white-logo-footer_dyrwka.png"
                  }
                },
                "datePublished": "2025-06-10",
                "mainEntityOfPage": {
                  "@type": "WebPage",
                  "@id": "https://yourdomain.com/dallas/new-homes-in-dallas-under-400k"
                }
              }
              `}
            </script>
          </Helmet>

          <p>
            If your budget is just under $400K, you’re in a prime position to
            secure a spacious, modern home in a desirable Dallas suburb. These
            price points open the door to better finishes, more square footage,
            and valuable builder perks.
          </p>

          <h2>What You Can Expect Under $400K</h2>
          <ul className="checklist">
            <li>✅ 3–5 bedroom floor plans with 2-car garages</li>
            <li>✅ New builds in planned communities with amenities</li>
            <li>
              ✅ Energy-efficient features, warranties, and smart home tech
            </li>
          </ul>

          <h2>Best Places to Look in DFW</h2>
          <ul className="checklist">
            <li>
              ✅ <strong>Forney & Mesquite:</strong> Rapidly growing,
              family-oriented, with new schools and shopping
            </li>
            <li>
              ✅ <strong>Red Oak & Waxahachie:</strong> South of Dallas with
              spacious lots and newer builders
            </li>
            <li>
              ✅ <strong>Little Elm & Aubrey:</strong> Near Denton County with
              access to Frisco & Prosper
            </li>
          </ul>

          <h2>How We Help You Find the Best Fit</h2>
          <ul className="checklist">
            <li>✅ Custom list of homes under $400K that meet your goals</li>
            <li>✅ Insider builder promotions before they hit public sites</li>
            <li>✅ Help navigating pre-approval, FHA/VA loans, and programs</li>
            <li>✅ No added fees — we’re paid by the builder, not by you</li>
          </ul>

          <h2>See a Preview of Our Exclusive List</h2>
          {IMG_BLURRED && (
            <img
              src={IMG_BLURRED}
              alt="Dallas New Homes List Preview"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
                border: "1px solid #ddd",
              }}
            />
          )}

          <p
            style={{
              backgroundColor: "#e6f4ea",
              padding: "12px",
              borderRadius: "6px",
              fontWeight: "bold",
            }}
          >
            <span style={{ color: "#007a38", fontWeight: "bold" }}>
              Click{" "}
              <span style={{ color: "#007a38", fontWeight: "bold" }}>
                (Start Your Search)
              </span>{" "}
              below to tell us what you're looking for —{" "}
              <span style={{ fontWeight: "bold", color: "#000" }}>
                we’ll send a personalized list of Dallas new homes under $400K!
              </span>
            </span>
          </p>

          <h2>Next Steps</h2>
          <p>
            We’ll help you unlock new construction deals in DFW that you won’t
            find on Zillow. Let’s find your dream home before pricing climbs
            further.
          </p>

          <h2 style={{ marginTop: "50px", fontWeight: "700" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((f, i) => (
              <div key={i} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(i)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {f.question}
                </div>
                {activeIndex === i && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {f.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};
// <NewHomeFooter citySlug="austin" /> // TODO: Move into return block later
<BuyNewHomeExitIntentPopup />;
export default NewHomesInDallasUnder400k;
