import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const PetFriendlyApartmentsDallas = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_PROP1 = "";
  const IMG_PROP2 = "";
  const IMG_PROP3 = "";

  // Conditional video links
  const VIDEO_PROP1 = "";
  const VIDEO_PROP2 = "";
  const VIDEO_PROP3 = "";

  const faqs = [
    {
      question: "Are there pet-friendly apartments in Dallas?",
      answer:
        "Yes! The majority of apartments in Dallas are pet-friendly — and many offer dog parks, pet spas, and pet-friendly events.",
    },
    {
      question: "Do pet-friendly apartments charge pet rent or deposits?",
      answer:
        "Yes — most Dallas apartments charge a pet deposit ($200–$400), a one-time fee, and/or monthly pet rent ($15–$35 per pet).",
    },
    {
      question: "Can I find apartments with no breed restrictions?",
      answer:
        "Yes — we maintain a private list of apartments in Dallas with no breed restrictions. Contact us for a personalized list.",
    },
    {
      question: "Do pet-friendly apartments in Dallas allow large dogs?",
      answer:
        "Yes — many apartments allow large dogs (50–100 lbs), though policies vary by property.",
    },
    {
      question: "How do I get my ESA letter for an apartment in Dallas?",
      answer:
        "You can request an ESA letter from a licensed therapist or doctor. If you need a referral to a reputable provider, contact us.",
    },
  ];

  return (
    <BlogLayout
      title="Pet-Friendly Apartments in Dallas (2025)"
      publishDate="2025-07-02T12:00:00"
    keywords={[
      "pet friendly apartments Dallas",
      "dog friendly rentals Dallas",
      "cat friendly apartments Dallas",
    ]}

      content={
        <>
          <p>
            Dallas is one of the most pet-friendly cities in Texas — and whether
            you have a small dog, a large dog, a cat, or an ESA, there are
            hundreds of pet-friendly apartments across the city.
          </p>

          <h2>Why Choose Pet-Friendly Apartments in Dallas?</h2>
          <p>
            Dallas has an amazing pet culture — with dog parks, pet-friendly
            patios, groomers, pet spas, and pet-focused community events. The
            right apartment can make life with your furry friend even better!
          </p>

          <h2>Our Top Picks for Pet-Friendly Apartments in Dallas</h2>

          <h3>1. Uptown Dallas Apartment</h3>
          {IMG_PROP1 && (
            <img
              src={IMG_PROP1}
              alt="Uptown Dallas Pet-Friendly Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP1 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP1}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Uptown Dallas offers some of the best pet-friendly apartments — with
            dog parks on-site, pet washing stations, and easy walkability to
            parks and patios.
          </p>

          <h3>2. Knox-Henderson Apartment</h3>
          {IMG_PROP2 && (
            <img
              src={IMG_PROP2}
              alt="Knox-Henderson Pet-Friendly Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP2 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP2}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Knox-Henderson is one of the most pet-welcoming neighborhoods in
            Dallas — with pet-friendly cafes and trails nearby.
          </p>

          <h3>3. East Dallas Apartment</h3>
          {IMG_PROP3 && (
            <img
              src={IMG_PROP3}
              alt="East Dallas Pet-Friendly Apartment"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PROP3 && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PROP3}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            East Dallas has excellent options for pet lovers — with nearby
            trails, green space, and affordable apartments with pet perks.
          </p>

          <h2>How We Help Dallas Pet Owners</h2>
          <p>We can match you with apartments that:</p>
          <ul style={{ paddingLeft: "20px", lineHeight: "1.8" }}>
            <li>✅ Allow large dogs</li>
            <li>✅ Have no breed restrictions</li>
            <li>✅ Include dog parks & pet spas</li>
            <li>✅ Are ESA-friendly</li>
            <li>✅ Have nearby walking trails & parks</li>
          </ul>

          <h2>Ready to Get Your Pet-Friendly Apartment List?</h2>
          <p>
            Contact us today and we’ll send a free list of the most pet-friendly
            apartments in Dallas — personalized to your pet and your lifestyle!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px", color: "#000", fontWeight: "bold" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default PetFriendlyApartmentsDallas;
