import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";
import ExclusiveSecondChanceList from "../../components/ExclusiveSecondChanceList";

const HowToRentWithBadCredit = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Can I rent an apartment in Dallas with bad credit?",
      answer:
        "Yes — many apartments in Dallas will work with bad credit, depending on the severity and age of your credit issues. A locator can help match you with the right properties.",
    },
    {
      question: "Do I need a cosigner if I have bad credit?",
      answer:
        "Not always. Some properties may approve you with additional deposit or income verification instead of a cosigner.",
    },
    {
      question: "Do luxury apartments in Dallas work with bad credit?",
      answer:
        "Some do! We track which luxury and mid-range properties offer second chance leasing options.",
    },
    {
      question:
        "How recent can a broken lease or eviction be to still qualify?",
      answer:
        "Generally, the older the better — many properties prefer issues that are 2+ years old, but we know some options for newer issues as well.",
    },
    {
      question: "Is your locator service free?",
      answer:
        "Yes — our service is always free to you. We’re paid by the apartment community when you lease.",
    },
  ];

  return (
    <BlogLayout
      title="How to Rent an Apartment in Dallas with Bad Credit (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "bad credit apartments Dallas",
        "second chance rentals Dallas",
        "how to rent with poor credit Dallas",
      ]}
      content={
        <>
          <p>
            Have bad credit, a broken lease, or an eviction on your record?
            Don’t stress — you still have options! In this guide, we’ll show you
            how to rent an apartment in Dallas with bad credit — and how our
            free locator service can help.
          </p>

          <h2>How Does Bad Credit Impact Apartment Approval?</h2>
          <p>
            Most Dallas apartments will run a credit and background check during
            the application process. Common credit challenges include:
          </p>
          <ul>
            <li>Low credit score (under 600)</li>
            <li>Late payments or collections</li>
            <li>Broken lease</li>
            <li>Eviction filing</li>
            <li>High debt-to-income ratio</li>
          </ul>

          <h2>Can You Still Qualify?</h2>
          <p>
            YES — many apartments in Dallas will work with bad credit. The key
            is knowing which properties offer second chance leasing. Some
            options include:
          </p>
          <ul>
            <li>Luxury apartments with flexible approval criteria</li>
            <li>Mid-range communities with second chance programs</li>
            <li>
              Townhomes and smaller communities that evaluate income first
            </li>
          </ul>

          <h2>How We Help</h2>
          <ul>
            <li>
              We maintain a private database of properties that work with bad
              credit
            </li>
            <li>
              We know which communities are open to broken leases and older
              evictions
            </li>
            <li>
              We can match you with options based on your credit profile and
              move-in date
            </li>
            <li>Our service is 100% free to you — no obligation</li>
          </ul>

          {/* 🚀 Exclusive Second Chance List component inserted here */}
          <ExclusiveSecondChanceList city="Dallas" />

          <h2>Why You Should Use a Locator vs. Searching Alone</h2>
          <ul>
            <li>Online listings often don’t show credit policies</li>
            <li>
              Properties change policies frequently — we stay updated weekly
            </li>
            <li>We can save you hours of wasted time and application fees</li>
            <li>
              We can advise if a cosigner or deposit will help in your situation
            </li>
          </ul>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default HowToRentWithBadCredit;
