import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsNearSMUDallas = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is it expensive to rent near SMU?",
      answer:
        "Apartments near SMU range widely — from affordable options starting around $1,200–$1,500 for older properties, to luxury apartments at $2,000+ for new developments.",
    },
    {
      question: "Are apartments near SMU pet-friendly?",
      answer:
        "Many apartments near SMU are pet-friendly and offer dog parks, pet washing stations, and easy access to green spaces.",
    },
    {
      question: "How close are these apartments to campus?",
      answer:
        "There are apartments within walking distance of SMU, as well as options just a short drive or bike ride away.",
    },
    {
      question: "Are there move-in specials for SMU apartments?",
      answer:
        "Yes — we track move-in specials and rebates for apartments near SMU and can send you an updated list of current deals.",
    },
    {
      question: "Do you help graduate students and faculty?",
      answer:
        "Yes — we assist SMU students, grad students, professors, and staff with finding the best apartments near campus.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments Near SMU Dallas (2025 Guide)"
      publishDate="2025-07-02T12:00:00"
      keywords={[
        "SMU apartments Dallas",
        "apartments near Southern Methodist University",
        "University Park rentals Dallas",
      ]}
      content={
        <>
          <p>
            Looking for an apartment near Southern Methodist University (SMU) in
            Dallas? Whether you’re an undergraduate, grad student, professor, or
            staff member, this guide will help you find the best apartments near
            campus!
          </p>

          <h2>Why Live Near SMU?</h2>
          <ul>
            <li>Convenient access to SMU campus and facilities</li>
            <li>Walkable neighborhoods like University Park & Highland Park</li>
            <li>Proximity to Mockingbird Station for shopping & dining</li>
            <li>Short commutes to Uptown & Downtown Dallas</li>
            <li>Pet-friendly communities available</li>
            <li>Options for students, grad students, and professionals</li>
          </ul>

          <h2>Top Apartments Near SMU Dallas</h2>

          <h3>1. The Shelby</h3>
          <img
            src="/images/the-shelby.jpg"
            alt="The Shelby apartments near SMU Dallas"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Boutique-style apartments located close to SMU and Mockingbird
            Station — ideal for students and professionals.
          </p>

          <h3>2. Mockingbird Flats</h3>
          <img
            src="/images/mockingbird-flats.jpg"
            alt="Mockingbird Flats apartments near SMU Dallas"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            Modern apartments with a walkable location — perfect for SMU
            students and staff looking for convenience and style.
          </p>

          <h3>3. The Village Dallas</h3>
          <img
            src="/images/the-village-dallas.jpg"
            alt="The Village Dallas apartments near SMU"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
            }}
          />
          <p>
            A large community with a wide range of options — great for grad
            students or faculty seeking more space and amenities.
          </p>

          <h2>How We Help You Find the Best Apartments Near SMU</h2>
          <ul>
            <li>We track move-in specials, discounts, and rebates</li>
            <li>We know which communities are walkable and pet-friendly</li>
            <li>
              We can match you to apartments based on your budget & lifestyle
            </li>
            <li>We save you time & money — our service is 100% free!</li>
          </ul>

          <h2>Ready to Tour Apartments Near SMU Dallas?</h2>
          <p>
            Want to find your perfect apartment near SMU? Contact us today for a
            free personalized list — with the latest specials and exclusive
            rebates. Click below to get started!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsNearSMUDallas;
