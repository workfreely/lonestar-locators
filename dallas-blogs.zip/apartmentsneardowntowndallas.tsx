import React, { useState } from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsNearDowntownDallas = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  // Conditional image links
  const IMG_ATELIER = ""; // You can add image later
  const IMG_THEVICTOR = ""; // You can add image later
  const IMG_AMLI = ""; // You can add image later

  // Conditional video links
  const VIDEO_ATELIER = ""; // You can add video link later
  const VIDEO_THEVICTOR = ""; // You can add video link later
  const VIDEO_AMLI = ""; // You can add video link later

  const faqs = [
    {
      question: "Is Downtown Dallas a good place to live?",
      answer:
        "Yes — Downtown Dallas offers a vibrant urban lifestyle with luxury apartments, walkable entertainment, and proximity to major employers.",
    },
    {
      question: "Are there pet-friendly apartments near Downtown Dallas?",
      answer:
        "Absolutely! Many Downtown Dallas apartments offer pet-friendly amenities such as dog parks, pet spas, and nearby green spaces.",
    },
    {
      question: "Can second-chance renters find apartments near Downtown Dallas?",
      answer:
        "Yes — we can match second-chance renters with flexible properties in the Downtown area.",
    },
    {
      question: "What’s the average rent for apartments near Downtown Dallas?",
      answer:
        "Studios typically start around $1,200+, 1-bedroom units around $1,500–$2,200+, and 2-bedroom apartments around $2,300–$3,500+.",
    },
    {
      question: "How is the commute from Downtown Dallas to other neighborhoods?",
      answer:
        "Excellent — Downtown Dallas offers quick access to Uptown, Deep Ellum, Victory Park, and major highways.",
    },
  ];

  return (
    <BlogLayout
      title="Apartments Near Downtown Dallas"
      publishDate="2025-07-02T12:00:00"
    keywords={[
      "downtown Dallas apartments",
      "apartments near Reunion Tower",
      "Dallas city center rentals",
    ]}

      content={
        <>
          <p>
            Want to live in the heart of Dallas? Downtown Dallas offers luxury high-rise apartments, incredible skyline views, and walkable access to dining, entertainment, and major employers. If you’re looking for modern living in one of the city’s most dynamic neighborhoods, apartments near Downtown Dallas are an excellent choice!
          </p>

          <h2>Why Live Near Downtown Dallas?</h2>
          <ul>
            <li>Luxury high-rise apartments with skyline views</li>
            <li>Walkable to Klyde Warren Park, AT&T Discovery District, and Deep Ellum</li>
            <li>Top-rated restaurants, bars, and entertainment venues</li>
            <li>Short commute to major employers and corporate HQs</li>
            <li>Pet-friendly and active lifestyle community</li>
            <li>Convenient access to public transit and major highways</li>
          </ul>

          <h2>Featured Apartments Near Downtown Dallas</h2>

          <h3>1. Atelier Apartments</h3>
          {IMG_ATELIER && (
            <img
              src={IMG_ATELIER}
              alt="Atelier Apartments Downtown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_ATELIER && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_ATELIER}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Atelier Apartments is one of Downtown Dallas’s premier luxury high-rises — offering stunning architecture, modern interiors, and breathtaking views of the city skyline. Amenities include a rooftop pool, fitness studio, concierge services, and more.
          </p>

          <h3>2. The Victor</h3>
          {IMG_THEVICTOR && (
            <img
              src={IMG_THEVICTOR}
              alt="The Victor Downtown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_THEVICTOR && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_THEVICTOR}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            The Victor is a brand-new luxury high-rise located steps from Victory Park and American Airlines Center. Residents enjoy ultra-modern floorplans, floor-to-ceiling windows, and top-tier amenities.
          </p>

          <h3>3. AMLI Fountain Place</h3>
          {IMG_AMLI && (
            <img
              src={IMG_AMLI}
              alt="AMLI Fountain Place Downtown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_AMLI && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_AMLI}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            AMLI Fountain Place is an architecturally striking tower offering luxurious residences, resort-style amenities, and a walkable Downtown Dallas location. It’s a favorite for professionals who want upscale living with easy access to the Arts District and more.
          </p>

          <h2>Looking for More Options?</h2>
          <p>
            We maintain a private, updated list of luxury and second-chance friendly apartments near Downtown Dallas — including hidden specials and move-in deals not published online.
          </p>
          <p>
            Contact us today to get your personalized list and insider deals!
          </p>

          {/* Accordion FAQ Section */}
          <h2 style={{ marginTop: "50px" }}>Frequently Asked Questions (FAQ)</h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, index) => (
              <div key={index} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(index)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === index && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default ApartmentsNearDowntownDallas;