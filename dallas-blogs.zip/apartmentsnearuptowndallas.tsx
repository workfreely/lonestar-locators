import React from "react";
import BlogLayout from "../../components/BlogLayout";

const ApartmentsNearUptownDallas = () => {
  // Conditional image links
  const IMG_PARKDISTRICT = "";
  const IMG_GABLES = "";
  const IMG_ASENT = "";

  // Conditional video links
  const VIDEO_PARKDISTRICT = "";
  const VIDEO_GABLES = "";
  const VIDEO_ASENT = "";

  return (
    <BlogLayout
      title="Apartments Near Uptown Dallas (2025)"
      publishDate="2025-07-02T12:00:00"
    keywords={[
      "Uptown Dallas apartments",
      "luxury apartments Uptown Dallas",
      "West Village rentals",
    ]}

      content={
        <>
          <p>
            Want to live in one of Dallas’s hottest, most walkable
            neighborhoods? Uptown Dallas is the place to be — with luxury
            apartments, top-rated restaurants, and an unbeatable social scene.
          </p>

          <h2>Why Live in Uptown Dallas?</h2>
          <ul>
            <li>
              ✔️ Walk to bars, shops, and entertainment on McKinney Avenue
            </li>
            <li>✔️ Access to Katy Trail for outdoor fitness</li>
            <li>✔️ High-end apartment communities with stunning amenities</li>
            <li>✔️ Quick commute to Downtown Dallas & major employers</li>
            <li>✔️ Vibrant lifestyle for young professionals & couples</li>
          </ul>

          <h2>Top Apartments Near Uptown Dallas</h2>

          <h3>1. Park District Residences</h3>
          {IMG_PARKDISTRICT && (
            <img
              src={IMG_PARKDISTRICT}
              alt="Park District Residences Uptown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_PARKDISTRICT && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_PARKDISTRICT}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Park District Residences offer sleek, modern units with
            floor-to-ceiling windows, panoramic city views, and 5-star amenities
            — all steps from Klyde Warren Park. Availability here moves FAST —
            contact us for current specials.
          </p>

          <h3>2. Gables McKinney Ave</h3>
          {IMG_GABLES && (
            <img
              src={IMG_GABLES}
              alt="Gables McKinney Ave Uptown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_GABLES && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_GABLES}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Located right on the trolley line, Gables McKinney Ave offers
            spacious layouts, modern kitchens, and an unbeatable Uptown
            location. Specials change monthly — inquire today!
          </p>

          <h3>3. Ascent Uptown</h3>
          {IMG_ASENT && (
            <img
              src={IMG_ASENT}
              alt="Ascent Uptown Dallas"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          {VIDEO_ASENT && (
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <a
                href={VIDEO_ASENT}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 20px",
                  backgroundColor: "#B22222",
                  color: "#fff",
                  borderRadius: "5px",
                  textDecoration: "none",
                  fontWeight: "600",
                  fontSize: "16px",
                }}
              >
                ▶️ Watch Video Tour
              </a>
            </div>
          )}
          <p>
            Ascent Uptown features ultra-modern apartments with designer
            finishes, rooftop pool, and walkability to the best spots in Uptown
            Dallas.
          </p>

          <h2>How We Can Help</h2>
          <p>
            Our team has insider access to Uptown Dallas pricing, specials, and
            limited-availability units. We’ll create a personalized list of
            apartments based on your budget, move date, and lifestyle.
          </p>

          <h2>Final Thoughts</h2>
          <p>
            Apartments near Uptown Dallas lease quickly — don’t miss out! Click
            below to start your search and receive your free personalized list
            today.
          </p>
        </>
      }
    />
  );
};

export default ApartmentsNearUptownDallas;
