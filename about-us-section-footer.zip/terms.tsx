import React from "react";

const Terms = () => {
  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Terms and Conditions</h1>
      <p>By using Lone Star Locators, you agree to the following terms:</p>
      <h2>Use of Service</h2>
      <p>
        Our website helps renters connect with apartment communities. You agree
        not to misuse the information or tools provided.
      </p>
      <h2>Rebates & Offers</h2>
      <p>
        Rebate offers are subject to qualification and must follow all outlined
        instructions. We are not liable for denied rebates due to application
        errors or omissions.
      </p>
      <h2>Third-Party Links</h2>
      <p>
        We are not responsible for the content or policies of external sites we
        link to.
      </p>
      <h2>Changes</h2>
      <p>
        We may update these terms at any time. Continued use constitutes
        acceptance.
      </p>
    </div>
  );
};

export default Terms;
