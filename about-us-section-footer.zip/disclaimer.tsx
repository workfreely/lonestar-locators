import React from "react";

const Disclaimer = () => {
  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Disclaimer</h1>
      <p>
        Pricing, availability, concessions, and lease terms are subject to
        change at any time without notice. Photos and virtual tours may
        represent model units and may differ from actual available apartments.
      </p>
      <p>
        Information provided on this site is believed to be accurate, but is not
        guaranteed and should be independently verified. Square footage and
        amenities may vary by unit.
      </p>
      <p>
        Users are encouraged to confirm details directly with the property
        before leasing. Lone Star Locators is not responsible for errors,
        omissions, or changes made by apartment communities.
      </p>
    </div>
  );
};

export default Disclaimer;
