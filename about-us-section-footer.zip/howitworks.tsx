import React, { useState } from "react";
import { Helmet } from "react-helmet";

const HowItWorks = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Is your apartment locating service really free?",
      answer:
        "Yes, our service is completely free to you. Our brokerage is credited by the apartment community when you list us on your application. You’re going to apply anyway, so why not get expert help, access to the best apartment specials and additional savings? Our clients can get a cash rebate or free movers at no cost.",
    },
    {
      question: "How do I qualify for the cash rebate or free movers?",
      answer:
        "Tell us which property you want to tour, list Jay Morris with AptAmigo on your application and report your lease once approved!",
    },
    {
      question: "What happens after I apply?",
      answer:
        "Let us know once you’ve been approved so we can confirm with the apartment and unlock your reward!",
    },
    {
      question: "What if I already toured or applied without you?",
      answer:
        "Most properties don’t allow changes once you’ve toured or submitted an application. To qualify for rewards like a cash rebate or free movers, make sure to list us on your guest card and application from the very beginning.",
    },
    {
      question: "Can you help me find an apartment with bad credit?",
      answer:
        "Yes! We help renters with bad credit find apartments across Austin, Dallas, Houston, and San Antonio. We also work with second chance properties that may accept broken leases, evictions, or background issues.",
    },
  ];

  return (
    <div
      className="how-it-works"
      style={{
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
        maxWidth: "1200px",
        margin: "0 auto",
      }}
    >
      <Helmet>
        <title>
          How It Works | Free Apartment Locating | Lone Star Locators{" "}
        </title>
      </Helmet>

      <h1
        style={{
          fontSize: "2.5rem",
          marginBottom: "2rem",
          textAlign: "center",
        }}
      >
        How It Works
      </h1>

      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "flex-start",
          gap: "15rem",
        }}
        className="how-it-works-columns"
      >
        {/* Left Column */}
        <div style={{ flex: "1.5", minWidth: "300px" }}>
          <div style={{ lineHeight: "1.6", fontSize: "1.1rem" }}>
            <h2>Step 1: Fill Out the Form</h2>
            <p>
              Tell us what you're looking for and we’ll send you a custom list
              with your best options.
            </p>
            <div style={{ textAlign: "center", margin: "16px 0" }}>
              <a href="/start-your-search" className="start-your-search-btn">
                Start Your Search
              </a>
            </div>

            <h2 style={{ marginTop: "2rem" }}>
              Step 2: Get a Personalized Apartment List
            </h2>
            <p>
              We’ll send a personalized list of your best options based on your
              budget, move-in date, and preferences.
            </p>
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1758820133/luxury-apartment-locator-list-austin-dallas-houston-san-antonio_cfbc0q.png"
              alt="Apartment list preview"
              style={{
                width: "100%",
                maxWidth: "500px",
                margin: "10px 0 30px",
                borderRadius: "8px",
                display: "block",
              }}
            />

            <h2>Step 3: Tour & Apply</h2>
            <p>
              We’ll help schedule your tours with a dedicated team of
              specialists and once you’ve found the perfect home, just apply to
              your favorite property!
            </p>

            <h2 style={{ marginTop: "2rem" }}>
              Step 4: List Us on Your Application
            </h2>
            <p>
              List <strong>"Jay Morris with AptAmigo"</strong> under{" "}
              <strong>“How did you hear about us”</strong> when applying. This
              qualifies you for a cash rebate or free movers!
            </p>
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1750015063/how-apartment-locating-works-select-realtor-locator_qm12ei.jpg"
              alt="Referral field"
              style={{
                width: "100%",
                maxWidth: "400px",
                margin: "10px 0",
                borderRadius: "8px",
                display: "block",
              }}
            />

            <h2 style={{ marginTop: "2rem" }}>
              Step 5: Move In & Get Rewarded
            </h2>
            <p>
              Once you're approved and moved in, send us your lease. You’ll get
              up to $200 or 2 hours of free movers (over $300 in value)!
            </p>

            <hr style={{ margin: "2rem 0" }} />
            <h2 style={{ fontSize: "1.5rem" }}>
              Frequently Asked Questions (FAQs)
            </h2>
            <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
              {faqs.map((faq, index) => (
                <div key={index} style={{ marginBottom: "15px" }}>
                  <div
                    onClick={() => toggleAccordion(index)}
                    style={{
                      cursor: "pointer",
                      backgroundColor: "#f1f1f1",
                      padding: "12px 18px",
                      borderRadius: "5px",
                      fontWeight: "600",
                      color: "#004aad",
                      fontSize: "1.05rem", // ✅ Set to match answer
                      lineHeight: "1.6", // ✅ Match line height
                      fontFamily: "'Inter', sans-serif",
                    }}
                  >
                    {faq.question}
                  </div>

                  {activeIndex === index && (
                    <div
                      style={{
                        backgroundColor: "#fafafa",
                        padding: "12px 18px",
                        border: "1px solid #ddd",
                        borderTop: "none",
                        borderRadius: "0 0 5px 5px",
                        marginTop: "-5px",
                        color: "#555",
                        fontSize: "1.05rem", // ✅ Same as question
                        lineHeight: "1.6",
                        fontFamily: "'Inter', sans-serif",
                      }}
                    >
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Video + Testimonials */}
        <div
          style={{
            flex: "1",
            minWidth: "300px",
            alignSelf: "flex-start",
            paddingTop: "2rem", // ← Adjust this to match alignment
          }}
          className="how-it-works-right"
        >
          <iframe
            width="100%"
            height="500"
            src="https://www.youtube.com/embed/YOUR_VIDEO_ID"
            title="How It Works - Lone Star Locators"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            style={{
              aspectRatio: "9 / 16",
              marginBottom: "2.5rem",
            }}
          ></iframe>

          <h2
            style={{
              fontSize: "1.8rem",
              marginBottom: "1rem",
              color: "#333",
              textAlign: "center",
            }}
          >
            Client Testimonials
          </h2>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "1.5rem",
            }}
          >
            {/* Card 1 */}
            <div
              style={{
                backgroundColor: "#fff",
                borderRadius: "10px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                padding: "1rem",
              }}
            >
              <p style={{ color: "#444" }}>“Yes, it got approved!”</p>
              <div style={{ fontWeight: 600, marginTop: "0.5rem" }}>
                Ashley T. – San Antonio, TX
              </div>
              <div style={{ color: "#f5a623", fontSize: "2.1rem" }}>★★★★★</div>
            </div>

            {/* Card 2 */}
            <div
              style={{
                backgroundColor: "#fff",
                borderRadius: "10px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                padding: "1rem",
              }}
            >
              <p style={{ color: "#444" }}>“Thank you again. God bless you.”</p>
              <div style={{ fontWeight: 600, marginTop: "0.5rem" }}>
                Greg W.– Dallas, TX
              </div>
              <div style={{ color: "#f5a623", fontSize: "2.1rem" }}>★★★★★</div>
            </div>

            {/* Card 3 */}
            <div
              style={{
                backgroundColor: "#fff",
                borderRadius: "10px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                padding: "1rem",
              }}
            >
              <p style={{ color: "#444" }}>
                “Hello brother, I just wanted to let you know the ladies called
                me and told me I was approved!!! Just wanted to say thank you
                from the bottom of my heart for helping me out man. Honestly, it
                means a lot.”
              </p>
              <div style={{ fontWeight: 600, marginTop: "0.5rem" }}>
                Joe M.– San Antonio, TX
              </div>
              <div style={{ color: "#f5a623", fontSize: "2.1rem" }}>★★★★★</div>
            </div>

            {/* Card 4 */}
            <div
              style={{
                backgroundColor: "#fff",
                borderRadius: "10px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                padding: "1rem",
              }}
            >
              <p style={{ color: "#444" }}>
                “I appreciate you so very much and am beyond grateful for God
                connecting us. I was really stressed leaving Cali without having
                a home here, but I trusted.”
              </p>
              <div style={{ fontWeight: 600, marginTop: "0.5rem" }}>
                Stephanie S. – San Antonio, TX
              </div>
              <div style={{ color: "#f5a623", fontSize: "2.1rem" }}>★★★★★</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
