import React from "react";

const Privacy = () => {
  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Privacy Policy</h1>
      <p>
        At Lone Star Locators, we take your privacy seriously. This Privacy
        Policy explains how we collect, use, and protect your personal
        information.
      </p>
      <h2>What We Collect</h2>
      <p>
        We may collect personal data such as your name, phone number, email
        address, and preferred apartment search criteria when you fill out a
        form or request information.
      </p>
      <h2>How We Use It</h2>
      <p>
        Your information is only used to help match you with apartment listings,
        share updates, or contact you with your consent. We never sell your data
        to third parties.
      </p>
      <h2>Cookies</h2>
      <p>
        Our website may use cookies to improve your experience and track
        analytics. You can disable cookies through your browser settings.
      </p>
      <h2>Contact</h2>
      <p>
        If you have any questions, contact us at support@lonestarlocators.com.
      </p>
    </div>
  );
};

export default Privacy;
