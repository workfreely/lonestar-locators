import React, { useEffect } from "react";
import BlogLayout from "./components/BlogLayout";
import AISchema from "./components/AISchema";
import JayBotWidget from "./components/JayBotWidget";

const AIApartmentLocator: React.FC = () => {
  const title =
    "AI Apartment Locator | 24/7 Apartment Search Powered by Lone Star Locators";
  const publishDate = "2025-11-06";
  const keywords = [
    "AI apartment locator",
    "Texas apartment locator",
    "Austin apartment locator",
    "Dallas apartment locator",
    "Houston apartment locator",
    "San Antonio apartment locator",
    "AI apartment finder",
    "luxury apartments Texas",
    "AI real estate assistant",
    "free apartment locating service",
    "Lone Star Locators",
    "AI apartment search Texas",
  ];

  const faqs = [
    {
      question: "What is the AI Apartment Locator?",
      answer:
        "The AI Apartment Locator is a 24/7 assistant created by <strong>Jay Morris</strong> and <strong>Lone Star Locators</strong> to help renters quickly find verified apartments across Texas. It combines smart technology with Jay’s local market expertise for a faster, more personal experience.",
    },
    {
      question: "Is this a real person or an AI?",
      answer:
        "You’re getting the best of both. The assistant helps you get started anytime, while <strong>Jay Morris</strong> personally hand selects and reviews each property to ensure accuracy, availability, and exclusive specials before you tour.",
    },
    {
      question: "Which cities are covered?",
      answer:
        "The AI Apartment Locator covers <strong>Austin, Dallas, Houston, and San Antonio</strong>. Each city includes a locally verified database of luxury apartments, second chance listings, and properties with move in specials or rebates.",
    },
    {
      question: "Can this help if I have bad credit or a broken lease?",
      answer:
        "Yes. Jay can match you with <strong>second chance and flexible approval apartments</strong> that work with a variety of credit situations including broken leases and background. You’ll get personalized options that fit your budget and move in goals.",
    },
    {
      question: "Do I still get a rebate or free movers?",
      answer:
        "Yes. All clients who start with the AI Apartment Locator qualify for <strong>cash rebates up to $200</strong> or <strong>free movers</strong> when they list <strong>Lone Star Locators</strong> or <strong>Jay Morris</strong> as their locator or agent on their application.",
    },
    {
      question: "Is this service really free?",
      answer:
        "Yes. It’s 100% free for renters. Apartment communities credit real estate brokerages and licensed agents like <strong>Jay Morris</strong>, so you never pay anything out of pocket.",
    },
    {
      question: "How do I get started?",
      answer:
        "You can start right now by chatting with the assistant or requesting your free personalized apartment list. Share a few details about your move and you’ll receive verified options reviewed by Jay within 24 hours.",
    },
  ];

  // ✅ Load JayBot chat + voice widget
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://vapi.ai/widget.js";
    script.async = true;

    script.onload = () => {
      if (window.vapi) {
        window.vapi.init({
          apiKey: "YOUR_PUBLIC_KEY", // Replace with your public key
          assistantId: "YOUR_ASSISTANT_ID", // Replace with your assistant ID
          position: "bottom-right",
          theme: {
            brandColor: "#004aad",
            backgroundColor: "#ffffff",
          },
        });
      }
    };

    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const content = (
    <>
      <p>
        The <strong>AI Apartment Locator Assistant</strong> by Lone Star
        Locators makes your apartment search faster, easier, and more reliable.
        Available 24 hours a day, it helps you get started on your search
        anytime while keeping the personal touch that makes all the difference.
      </p>

      <p>
        Whether you’re moving to{" "}
        <strong>Austin, Dallas, Houston, or San Antonio</strong>, you’ll receive
        personalized results backed by local market insight from{" "}
        <strong>Jay Morris</strong>, a licensed Texas real estate agent.
      </p>

      <p>
        Finding the right place can be overwhelming, especially if you’re
        relocating from another city or state. That’s why Jay built a system
        that combines technology and personal expertise to make the process
        effortless and accurate.
      </p>

      <p>
        The assistant helps you start the search instantly, but{" "}
        <strong>
          Jay Morris personally hand selects and reviews each property
        </strong>{" "}
        to ensure accuracy, availability, and exclusive specials before you
        tour. Having toured hundreds of properties himself, Jay can share
        insights most websites can’t. For example, how quiet a community is, if
        management is responsive, requirements, whether units include a washer
        and dryer, or if there’s an H-E-B just down the street — and sometimes
        he can even negotiate on your behalf.
      </p>

      <p>
        Over the years, Jay has helped hundreds of people relocate across Texas,
        from local renters in San Antonio to new residents moving from
        California, Florida, New York, and beyond. His goal is to save you time,
        remove the stress, and help you find a home that truly fits your
        lifestyle.
      </p>

      {/* ✅ Chatbot / Voice Assistant Section */}
      <div style={{ margin: "2.5rem 0" }}>
        <h2
          style={{
            fontSize: "1.8rem",
            fontWeight: 700,
            color: "#111",
            marginBottom: "1rem",
          }}
        >
          Chat or Talk with My Assistant 24/7
        </h2>
        <p
          style={{
            fontSize: "1.05rem",
            lineHeight: "1.7",
            color: "#444",
            marginBottom: "1.5rem",
            maxWidth: "800px",
          }}
        >
          You can chat or talk with my assistant right here on this page any
          time of day. Get matched with apartments instantly, ask questions
          about neighborhoods or specials, and receive verified options reviewed
          by me before you tour.
        </p>
        {/* ✅ Reuse same working widget as the homepage */}
        <JayBotWidget />
      </div>

      <h2>Why Renters Choose the AI Apartment Locator</h2>
      <ul>
        <li>24/7 availability to help you start your search anytime</li>
        <li>
          Locally verified data for Austin, Dallas, Houston, and San Antonio
        </li>
        <li>Hand selected and personally reviewed listings by Jay Morris</li>
        <li>
          Exclusive access to move in specials, cash rebates, or free movers
        </li>
        <li>Accurate listings updated daily with no duplicates</li>
      </ul>

      <p>
        This isn’t your ordinary apartment search. It’s a concierge style
        experience that blends advanced technology with trusted local guidance,
        helping you move with confidence and peace of mind.
      </p>

      <p>
        Start your free apartment search today and let’s find your perfect place
        together.
      </p>
    </>
  );

  return (
    <>
      <AISchema city="Texas" />
      <BlogLayout
        title={title}
        content={content}
        publishDate={publishDate}
        keywords={keywords}
        faqs={faqs}
        ctaType="apartment"
        schemaType="Service"
        address={{
          addressLocality: "San Antonio",
          addressRegion: "TX",
        }}
      />
    </>
  );
};

export default AIApartmentLocator;
