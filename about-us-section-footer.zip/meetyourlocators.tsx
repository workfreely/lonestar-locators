import React from "react";
import { Helmet } from "react-helmet";

const MeetYourLocators = () => {
  return (
    <div
      style={{
        maxWidth: "1200px",
        margin: "0 auto",
        padding: "3rem 1.5rem",
        fontFamily: "'Inter', sans-serif",
        color: "#333",
        lineHeight: "1.7",
      }}
    >
      <Helmet>
        {/* 🔹 SEO Meta Tags */}
        <title>
          Meet Jay Morris | Licensed Apartment Locator & Real Estate Agent in
          San Antonio, Austin, Dallas & Houston | Lone Star Locators
        </title>
        <meta
          name="description"
          content="Meet Jay Morris — your licensed apartment locator and real estate agent serving San Antonio, Austin, Dallas & Houston. Helping renters find luxury apartments, townhomes, penthouses & second chance apartments with exclusive specials and rebates."
        />
        <meta
          name="keywords"
          content="Jay Morris, Lone Star Locators, apartment locator San Antonio, apartment locator Austin, apartment locator Dallas, apartment locator Houston, licensed real estate agent Texas, free apartment locating service, second chance apartments, luxury apartments Texas"
        />
        <link
          rel="canonical"
          href="https://www.lonestarlocators.app/meet-your-locators"
        />

        {/* ... (all your schema blocks stay unchanged) ... */}
      </Helmet>

      {/* 🔹 Content Starts */}
      <h1
        style={{
          textAlign: "center",
          fontSize: "2.5rem",
          fontWeight: 800,
          marginBottom: "2.5rem",
        }}
      >
        Meet Your Locator
      </h1>

      {/* Jay Morris Section */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "2.5rem",
          alignItems: "flex-start",
          marginBottom: "2rem",
        }}
      >
        <div style={{ flex: "0 0 220px", textAlign: "center" }}>
          <img
            src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1748014964/jay-morris-free-apartment-locator-san-antonio-texas_pgf7fs.png"
            alt="Jay Morris, Licensed Apartment Locator and Real Estate Agent in Texas"
            style={{
              borderRadius: "100%",
              width: "200px",
              height: "200px",
              objectFit: "cover",
              boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            }}
          />
        </div>

        <div style={{ flex: 1, minWidth: "300px", fontSize: "1.1rem" }}>
          <h2
            style={{
              fontSize: "1.9rem",
              fontWeight: 700,
              marginBottom: "1rem",
              color: "#111",
            }}
          >
            Jay Morris | Licensed Apartment Locator & Real Estate Agent
          </h2>

          <p style={{ marginBottom: "1.5rem" }}>
            <strong>
              Hey I’m Jay! Your licensed real estate agent and free apartment
              locator serving San Antonio, Austin, Dallas and Houston.
            </strong>{" "}
            I’ve helped hundreds of renters secure luxury studios, apartments,
            townhomes and penthouses including second chance apartments with
            move in specials.
          </p>

          <p style={{ marginBottom: "1.5rem" }}>
            <strong>This is NOT your ordinary apartment search.</strong> I have
            access to a local database that’s updated daily and far more
            accurate than what you’ll find online. I work directly with
            communities and unlock deals before they hit the market.
          </p>

          <p style={{ marginBottom: "1.5rem" }}>
            Whether you're looking for a downtown high rise, suburban townhome,
            or flexible second chance options, I’ll match you with the best
            communities for your lifestyle.
          </p>

          <p style={{ marginBottom: "1.5rem" }}>
            <strong>My service is 100% free</strong> — unlock move-in specials,
            free movers, and cash rebates you won’t find online.
          </p>
        </div>
      </div>

      {/* ⭐ Instagram Reels Section */}
      <div style={{ textAlign: "center", marginBottom: "1.5rem" }}>
        {/* Responsive Header */}
        <h2
          className="ig-header-container"
          style={{
            fontSize: "1.8rem",
            fontWeight: 800,
            marginBottom: "2.2rem",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            gap: "0.4rem",
          }}
        >
          <div
            className="ig-header-line"
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: "0.5rem",
              flexWrap: "wrap",
            }}
          >
            <img
              src="https://cdn-icons-png.flaticon.com/512/174/174855.png"
              alt="Instagram icon"
              style={{
                width: "32px", // larger
                height: "32px",
                filter: "grayscale(100%) brightness(0.3)",
                opacity: 0.5, // subtle gray look
              }}
            />

            <span>Follow Me on Instagram:</span>
          </div>

          <a
            href="https://instagram.com/LoneStarLocators"
            target="_blank"
            rel="noopener noreferrer"
            className="ig-username"
            style={{
              color: "#004aad",
              fontWeight: 700,
              textDecoration: "none",
              fontSize: "1.4rem",
            }}
          >
            @LoneStarLocators
          </a>
        </h2>

        {/* Reels Grid */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "1.8rem",
            marginTop: "1.2rem",
          }}
        >
          {[
            {
              url: "https://www.instagram.com/reel/DGwXTOER4wK/",
              thumbnail:
                "https://res.cloudinary.com/dxtiguwzm/image/upload/v1765038608/penthouse-jay-morris-apartment-locator_xyjmuy.png",
            },
            {
              url: "https://www.instagram.com/reel/DCko_ZxxMIb/",
              thumbnail:
                "https://res.cloudinary.com/dxtiguwzm/image/upload/v1765038608/townhomes-for-rent-jay-morris-apartment-locator_i6g3wb.png",
            },
            {
              url: "https://www.instagram.com/reel/DCSiC4nRSMf/",
              thumbnail:
                "https://res.cloudinary.com/dxtiguwzm/image/upload/v1765038608/luxury-penthouse-san-antonio-jay-morris-apartment-locator_gltlsf.png",
            },
            {
              url: "https://www.instagram.com/reel/DOIFAmBDSlp/",
              thumbnail:
                "https://res.cloudinary.com/dxtiguwzm/image/upload/v1765341498/san-antonio-townhomes-apartment-locator_a5tkbd.png",
            },
          ].map((post, i) => (
            <a
              key={i}
              href={post.url}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                width: "100%",
                maxWidth: "260px",
                height: "430px",
                borderRadius: "14px",
                overflow: "hidden",
                display: "block",
                boxShadow: "0 6px 16px rgba(0,0,0,0.12)",
                transition: "all 0.3s ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "scale(1.04)";
                e.currentTarget.style.boxShadow =
                  "0 12px 24px rgba(0,0,0,0.18)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "scale(1)";
                e.currentTarget.style.boxShadow = "0 6px 16px rgba(0,0,0,0.12)";
              }}
            >
              <img
                src={post.thumbnail}
                alt={`Instagram reel thumbnail ${i + 1}`}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                }}
              />
            </a>
          ))}
        </div>
      </div>

      {/* ✅ Testimonials Section */}
      <div
        style={{
          maxWidth: "1000px",
          margin: "0 auto",
          padding: "2rem 1rem 4rem",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "2rem",
            fontWeight: 800,
            marginBottom: "2rem",
            color: "#111",
          }}
        >
          What Clients Are Saying
        </h2>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.5rem",
          }}
        >
          {[
            {
              name: "Haley T.",
              location: "San Antonio, TX",
              text: "Jay I just want to tell you that we moved in today the movers were absolutely wonderful! I could not have asked for better help. Thank you thank you thank you!",
            },
            {
              name: "Angelica M.",
              location: "San Antonio, TX",
              text: "I appreciate you so much and am beyond grateful for God connecting us. I was really stressed leaving Cali without having a home here but I trusted.",
            },
            {
              name: "Crystal R.",
              location: "San Antonio, TX",
              text: "Yes it got approved! Thank you again God bless you.",
            },
          ].map((review, i) => (
            <div
              key={i}
              style={{
                backgroundColor: "#fff",
                borderRadius: "12px",
                boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                padding: "0.8rem 1.3rem 1.2rem",
                lineHeight: "1.6",
                transition: "all 0.3s ease",
                cursor: "default",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                height: "90%",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "scale(1.03)";
                e.currentTarget.style.boxShadow = "0 8px 18px rgba(0,0,0,0.15)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "scale(1)";
                e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
              }}
            >
              <p
                style={{
                  color: "#444",
                  fontSize: "1.05rem",
                  marginBottom: "0.4rem",
                  lineHeight: "1.55",
                }}
              >
                {review.text}
              </p>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  borderTop: "1px solid #eee",
                  paddingTop: "0.4rem",
                  flexWrap: "wrap",
                  rowGap: "0.3rem",
                }}
              >
                <div
                  style={{
                    fontWeight: 700,
                    color: "#111",
                    fontSize: "1rem",
                  }}
                >
                  {review.name} · {review.location}
                </div>
                <div
                  style={{
                    color: "#f5a623",
                    fontSize: "2rem",
                    letterSpacing: "1.5px",
                    flexShrink: 0,
                  }}
                >
                  ★★★★★
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MeetYourLocators;
