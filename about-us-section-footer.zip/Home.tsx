import { Helmet } from "react-helmet";
import { Link, useNavigate } from "react-router-dom";
import "./citycards.css";
import { FaMapMarkerAlt } from "react-icons/fa";
import { TypeAnimation } from "react-type-animation";
import FeaturedProperties from "./components/FeaturedProperties"; // ✅ Correct path
import JayBotWidget from "./components/JayBotWidget";

const Home = () => {
  const navigate = useNavigate();

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#333" }}>
      <Helmet>
        <title>Find Your Perfect Apartment in Texas | Lone Star Locators</title>
        <meta
          name="description"
          content="Explore luxury apartments, townhomes and penthouses in Texas cities with move-in specials. Get free movers or up to $200 cash rebate when you lease through us."
        />

        {/* ✅ Organization Schema */}
        <script type="application/ld+json">
          {`
          {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Lone Star Locators",
            "url": "https://www.lonestarlocators.app",
            "logo": "https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937030/lone-star-locators-logo.png",
            "description": "Lone Star Locators is a free apartment locating service helping renters find luxury apartments, townhomes, penthouses, and second chance apartments across Texas.",
            "address": {
              "@type": "PostalAddress",
              "addressLocality": "San Antonio",
              "addressRegion": "TX",
              "addressCountry": "US"
            },
            "contactPoint": {
              "@type": "ContactPoint",
              "contactType": "customer service",
              "areaServed": ["San Antonio TX", "Austin TX", "Dallas TX", "Houston TX"],
              "availableLanguage": ["English", "Spanish"]
            },
            "sameAs": [
              "https://www.instagram.com/realestatepro_tx",
              "https://www.facebook.com/lonestarlocators",
              "https://www.tiktok.com/@lonestarlocators"
            ]
          }
          `}
        </script>

        {/* ✅ ItemList Schema (Cities) */}
        <script type="application/ld+json">
          {`
          {
            "@context": "https://schema.org",
            "@type": "ItemList",
            "name": "Cities We Serve",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "item": { "@type": "Place", "name": "Austin, TX" } },
              { "@type": "ListItem", "position": 2, "item": { "@type": "Place", "name": "Dallas, TX" } },
              { "@type": "ListItem", "position": 3, "item": { "@type": "Place", "name": "Houston, TX" } },
              { "@type": "ListItem", "position": 4, "item": { "@type": "Place", "name": "San Antonio, TX" } }
            ]
          }
          `}
        </script>

        {/* ✅ Breadcrumb Schema */}
        <script type="application/ld+json">
          {`
          {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.lonestarlocators.app" },
              { "@type": "ListItem", "position": 2, "name": "Apartments in Texas", "item": "https://www.lonestarlocators.app" }
            ]
          }
          `}
        </script>

        {/* ✅ AI-Enhanced Apartment Locating Schema */}
        <script type="application/ld+json">
          {`
{
  "@context": "https://schema.org",
  "@type": "Service",
  "serviceType": "AI-Powered Apartment Locating",
  "provider": {
    "@type": "Organization",
    "name": "Lone Star Locators",
    "url": "https://www.lonestarlocators.app",
    "logo": "https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937030/lone-star-locators-logo.png",
    "description": "Lone Star Locators combines real-world expertise with AI-powered search technology to help renters find their perfect apartment 24/7 across Texas.",
    "brand": {
      "@type": "Brand",
      "name": "JayBot AI Assistant",
      "description": "JayBot is my AI-powered assistant — trained with my local market data and years of experience helping renters and buyers find the perfect apartment. JayBot provides instant, data-driven recommendations and connects users directly with Jay for personalized follow-up.",
      "url": "https://www.lonestarlocators.app",
      "sameAs": [
        "https://www.instagram.com/realestatepro_tx",
        "https://www.facebook.com/lonestarlocators",
        "https://www.tiktok.com/@lonestarlocators"
      ]
    }
  },
  "areaServed": [
    { "@type": "City", "name": "Austin, TX" },
    { "@type": "City", "name": "Dallas, TX" },
    { "@type": "City", "name": "Houston, TX" },
    { "@type": "City", "name": "San Antonio, TX" }
  ],
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD",
    "description": "100% free apartment locating service with optional cash rebate or free movers."
  },
  "potentialAction": {
    "@type": "InteractAction",
    "name": "Chat with JayBot",
    "target": "https://www.lonestarlocators.app",
    "actionPlatform": [
      "https://vapi.ai",
      "https://www.lonestarlocators.app"
    ],
    "description": "Talk to JayBot — your local apartment locator expert powered by AI, available 24/7."
  },
  "keywords": [
    "Texas Apartment Locator",
    "AI Apartment Search",
    "Free Apartment Locating Service",
    "Luxury Apartments Texas",
    "Townhomes in Texas",
    "Penthouses in Texas",
    "Austin Apartment Locator",
    "Austin Apartment Finder",
    "Dallas Apartment Locator",
    "Dallas Apartment Finder",
    "Houston Apartment Locator",
    "Houston Apartment Finder",
    "San Antonio Apartment Locator",
    "San Antonio Apartment Finder",
    "Apartment Deals in Texas",
    "Move-in Specials Texas Apartments",
    "Second Chance Apartments Texas",
    "JayBot AI Apartment Assistant",
    "Lone Star Locators",
    "Jay Morris Apartment Locator"
  ]
}
`}
        </script>
      </Helmet>
      {/* ✅ Hero Section */}
      <header style={{ textAlign: "center", padding: "1.5rem 1rem 1.25rem" }}>
        <h1
          style={{ fontSize: "2.8rem", fontWeight: 800, marginBottom: "1rem" }}
        >
          Find Your Perfect Apartment in Texas
        </h1>
        <p
          style={{
            fontSize: "1.25rem",
            maxWidth: "900px",
            margin: "0 auto",
            lineHeight: "1.6",
          }}
        >
          Select a city to get access to luxury apartments, townhomes and
          penthouses with move-in specials. <strong>Get free movers</strong> or{" "}
          <strong>up to $200 cash rebate</strong> when you lease through us.{" "}
          <strong>Our service is 100% free!</strong>
        </p>
      </header>
      {/* Row 1: Austin + Dallas */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "1.5rem",
          padding: "1rem",
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        {/* Austin */}
        <Link
          to="/austin"
          style={{ textDecoration: "none", color: "white", flex: "1 1 300px" }}
        >
          <div
            className="city-card"
            style={{
              position: "relative",
              borderRadius: "10px",
              overflow: "hidden",
            }}
          >
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937030/lone-star-locators-austin-texas-free-apartment-locating_ew5tvq.jpg"
              alt="Austin Apartments - Free Apartment Locator in Austin, TX"
              style={{
                width: "100%",
                height: "250px",
                objectFit: "cover",
                filter: "brightness(65%)",
              }}
            />
            <h2
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                fontSize: "2rem",
                fontWeight: "bold",
                zIndex: 2,
                display: "flex",
                alignItems: "center",
                gap: "8px",
                whiteSpace: "nowrap",
              }}
            >
              <FaMapMarkerAlt color="white" size={22} />
              Austin
            </h2>
          </div>
        </Link>

        {/* Dallas */}
        <Link
          to="/dallas"
          style={{ textDecoration: "none", color: "white", flex: "1 1 300px" }}
        >
          <div
            className="city-card"
            style={{
              position: "relative",
              borderRadius: "10px",
              overflow: "hidden",
            }}
          >
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937029/lone-star-locators-dallas-texas-free-apartment-locating_cdr8z9.jpg"
              alt="Dallas Apartments - Free Apartment Locator in Dallas, TX"
              style={{
                width: "100%",
                height: "250px",
                objectFit: "cover",
                filter: "brightness(65%)",
              }}
            />
            <h2
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                fontSize: "2rem",
                fontWeight: "bold",
                zIndex: 2,
                display: "flex",
                alignItems: "center",
                gap: "8px",
                whiteSpace: "nowrap",
              }}
            >
              <FaMapMarkerAlt color="white" size={22} />
              Dallas
            </h2>
          </div>
        </Link>
      </div>
      {/* Row 2: Houston + San Antonio */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "1.5rem",
          padding: "1rem",
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        {/* Houston */}
        <Link
          to="/houston"
          style={{ textDecoration: "none", color: "white", flex: "1 1 300px" }}
        >
          <div
            className="city-card"
            style={{
              position: "relative",
              borderRadius: "10px",
              overflow: "hidden",
            }}
          >
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937029/lone-star-locators-houston-texas-free-apartment-locating_j63kfq.jpg"
              alt="Houston Apartments - Free Apartment Locator in Houston, TX"
              style={{
                width: "100%",
                height: "250px",
                objectFit: "cover",
                filter: "brightness(65%)",
              }}
            />
            <h2
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                fontSize: "2rem",
                fontWeight: "bold",
                zIndex: 2,
                display: "flex",
                alignItems: "center",
                gap: "8px",
                whiteSpace: "nowrap",
              }}
            >
              <FaMapMarkerAlt color="white" size={22} />
              Houston
            </h2>
          </div>
        </Link>

        {/* San Antonio */}
        <Link
          to="/sanantonio"
          style={{ textDecoration: "none", color: "white", flex: "1 1 300px" }}
        >
          <div
            className="city-card"
            style={{
              position: "relative",
              borderRadius: "10px",
              overflow: "hidden",
            }}
          >
            <img
              src="https://res.cloudinary.com/dxtiguwzm/image/upload/v1747937030/lone-star-locators-san-antonio-texas-free-apartment-locating_trgkaj.jpg"
              alt="San Antonio Apartments - Free Apartment Locator in San Antonio, TX"
              style={{
                width: "100%",
                height: "250px",
                objectFit: "cover",
                filter: "brightness(65%)",
              }}
            />
            <h2
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                fontSize: "2rem",
                fontWeight: "bold",
                zIndex: 2,
                display: "flex",
                alignItems: "center",
                gap: "8px",
                whiteSpace: "nowrap",
              }}
            >
              <FaMapMarkerAlt color="white" size={22} />
              San Antonio
            </h2>
          </div>
        </Link>
      </div>
      {/* ✅ AI-Style Search */}
      <div
        id="search-section"
        className="home-section"
        style={{
          textAlign: "center",
        }}
        itemScope
        itemType="https://schema.org/SearchAction"
      >
        {/* 🔥 MOBILE-ONLY REDUCE TOP SPACE */}
        <style>
          {`
      @media (max-width: 768px) {
        #search-section {
          padding-top: 0.25rem !important; /* tighten top space on mobile */
        }
      }
    `}
        </style>

        <meta
          itemProp="target"
          content="https://www.lonestarlocators.app/start-your-search?q={search_term_string}"
        />
        <meta
          itemProp="query-input"
          content="required name=search_term_string"
        />
        <style>
          {`
    /* MOBILE ONLY — break the phrase into 2 lines */
    @media (max-width: 768px) {
      #search-title {
        display: block;
        line-height: 1.2;
        text-align: center;
      }
      #search-title .break {
        display: block;
      }
    }
  `}
        </style>

        <h2
          id="search-title"
          style={{
            fontSize: "2.2rem",
            fontWeight: 800,
            marginBottom: "2rem",
            color: "#111",
          }}
        >
          What Are You <span className="break"></span> Searching For?
        </h2>

        <div
          style={{
            maxWidth: "850px",
            margin: "0 auto",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "1.5rem",
          }}
        >
          <div
            style={{
              width: "100%",
              backgroundColor: "#fff",
              border: "1px solid #ddd",
              borderRadius: "45px",
              padding: "1rem 3rem",
              boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
              fontSize: "1.8rem",
              fontWeight: 700,
              textAlign: "center",
              color: "#111",
            }}
          >
            <TypeAnimation
              sequence={[
                "2 bed luxury townhome in Austin",
                2500,
                "1 bed high rise apartment in Dallas",
                2500,
                "pet friendly apartment in Houston",
                2500,
                "modern townhome near the Pearl San Antonio",
                2500,
              ]}
              speed={45}
              repeat={Infinity}
              deletionSpeed={55}
            />
          </div>

          <button
            onClick={() => navigate("/start-your-search")}
            style={{
              backgroundColor: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: "40px",
              padding: "1rem 3rem",
              fontSize: "1.3rem",
              fontWeight: 600,
              cursor: "pointer",
              transition: "0.3s ease",
              boxShadow: "0 4px 14px rgba(0,0,0,0.1)",
            }}
            onMouseEnter={(e) =>
              (e.currentTarget.style.backgroundColor = "#218838")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.backgroundColor = "#28a745")
            }
          >
            Start Your Search
          </button>
        </div>
      </div>
      {/* ✅ Testimonials */}
      <div
        style={{
          maxWidth: "1200px",
          margin: "1.5rem auto",
          padding: "1rem 1rem",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "2rem",
            fontWeight: 800,
            marginBottom: "2rem",
          }}
        >
          What Clients Are Saying
        </h2>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
            gap: "1.5rem",
          }}
        >
          {[
            {
              name: "Ashley V.",
              location: "San Antonio, TX",
              text: "Hi Jay, you're the best! Yes, all is coming along beautifully. I ended up switching units because the view in one of the 2/2 got me 😍",
            },
            {
              name: "Tiffany P.",
              location: "San Antonio, TX",
              text: "Yes sir, we just submitted our application. Thank you very much for your help, we got it approved!",
            },
            {
              name: "Jerry T.",
              location: "Austin, TX",
              text: "Hey, they ended up approving me with a half month deposit, which is great! I'm getting it all squared away!",
            },
            {
              name: "Eric S.",
              location: "Houston, TX",
              text: "Thank you bro! Appreciate you! I really prayed for this man. I was boutta be homeless. I’m feeling beyond blessed. Thanks again for pointing me in the right direction.",
            },
          ].map((review, i) => (
            <div
              key={i}
              className="testimonial-card"
              style={{
                display: "flex",
                flexDirection: "column",
                height: "80%",
                boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
                borderRadius: "8px",
                padding: "1rem",
                backgroundColor: "#fafafa",
              }}
            >
              <div
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "1.05rem",
                  lineHeight: "1.6",
                  color: "#444",
                  fontWeight: 400,
                }}
              >
                {review.text}
              </div>
              <div style={{ marginTop: "auto" }}>
                <div
                  style={{
                    fontWeight: "bold",
                    marginTop: "1rem",
                    marginBottom: "0.3rem",
                  }}
                >
                  {review.name} · {review.location}
                </div>
                <div style={{ color: "#f5a623", fontSize: "2.1rem" }}>
                  ★★★★★
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* ✅ Featured Properties Section */}

      <FeaturedProperties />
      <JayBotWidget />
    </div>
  );
};

export default Home;
