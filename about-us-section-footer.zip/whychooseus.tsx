import React from "react";

const WhyChooseUs = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Why Choose Us</h1>

      <p>
        At Lone Star Locators, we specialize in helping renters find the best
        apartments, townhomes, and penthouses in Austin, Dallas, Houston, and
        San Antonio — while unlocking exclusive move-in specials and up to $200
        in rebates.
      </p>

      <h2>We Make Apartment Hunting Easy</h2>
      <p>
        Our team does the heavy lifting by curating listings based on your
        budget, lifestyle, and move date. You’ll get hand-picked luxury
        apartments and gated communities that match your exact criteria.
      </p>

      <h2>Save Money With Cash Rebates & Free Movers</h2>
      <p>
        When you lease through us and write our name on your application, you
        can qualify for a cash rebate or 2 hours of free moving assistance —
        just our way of saying thanks.
      </p>

      <h2>Local Experts, Personalized Support</h2>
      <p>
        We live and work in Texas, so we know which properties offer the best
        specials, upgrades, and availability. You’re not just searching — you’re
        getting expert guidance every step of the way.
      </p>

      <h2>Thousands of Happy Renters</h2>
      <p>
        From students to professionals and families, we’ve helped thousands of
        people find a place they love while saving money in the process. Now
        it’s your turn.
      </p>

      <p style={{ marginTop: "2rem" }}>
        Ready to start your apartment search?{" "}
        <strong>Let Lone Star Locators be your guide.</strong>
      </p>
    </div>
  );
};

export default WhyChooseUs;
