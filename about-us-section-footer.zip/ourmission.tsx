import React from "react";

const OurMission = () => {
  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Our Mission</h1>
      <p>
        At Lone Star Locators, our mission is simple: to help renters find the
        perfect place to call home while saving time and money.
      </p>
      <p>
        We believe apartment hunting should be stress-free, transparent, and
        even rewarding. That’s why we offer curated listings, personalized
        support, and up to $200 cash back just for using our service.
      </p>
      <p>
        Whether you're relocating, upgrading, or downsizing — we’re here to
        guide you every step of the way.
      </p>
    </div>
  );
};

export default OurMission;
