import React, { useState, useEffect } from "react";
import Papa from "papaparse"; // keep until Supabase replaces CSV
import "../styles/apartmentlistings.css";
import SchemaItemList from "../components/SchemaItemList";
import AISchema from "../components/AISchema";
import ListingCard from "../components/ListingCard";
import { createClient } from "@supabase/supabase-js";

// =======================================================
// 🧩 SUPABASE CONFIG — works in CodeSandbox + Vercel
// =======================================================

// ✅ TEMPORARY for CodeSandbox (use this active version)
const supabaseUrl = "https://ukkxisleiprdpptaaxcs.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVra3hpc2xlaXByZHBwdGFheGNzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4NTA3MTgsImV4cCI6MjA3NDQyNjcxOH0.2toax3wY19COqPtJh64qpRcvYNlnFIndI_27og8jp-4";

// ✅ FUTURE for Vercel / Local (comment out until deployment)
// const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
// const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// =======================================================
// 🏙️ MOCK LISTING (keep until Supabase table connects)
// =======================================================

const defaultImage =
  "https://res.cloudinary.com/dxtiguwzm/image/upload/v1748277676/photos-coming-soon-lone-star-locators_be1dyx.jpg";

const ApartmentListings = () => {
  // ✅ Supabase state + fetch
  const [listings, setListings] = useState<any[]>([]);

  useEffect(() => {
    const fetchListings = async () => {
      const { data, error } = await supabase
        .from("austin_listings") // 👈 table name for this city
        .select("*");

      if (error) {
        console.error("Error fetching listings:", error);
      } else {
        console.log("✅ Listings fetched:", data);
        setListings(data || []);
      }
    };

    fetchListings();
  }, []);

  const allNeighborhoods = [
    "Downtown Austin",
    "South Congress (SoCo)",
    "South Lamar",
    "East Austin",
    "Zilker",
    "Mueller",
    "Domain",
    "Barton Creek",
    "Westlake",
    "Riverside",
    "North Loop",
  ];

  const [filters, setFilters] = useState({
    beds: "",
    baths: "",
    price: "",
    propertyType: "",
    neighborhoods: [] as string[],
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;

    if (
      type === "checkbox" &&
      e.target instanceof HTMLInputElement &&
      name === "neighborhoods"
    ) {
      const { checked } = e.target;
      const updated = checked
        ? [...filters.neighborhoods, value]
        : filters.neighborhoods.filter((n) => n !== value);
      setFilters({ ...filters, neighborhoods: updated });
    } else {
      setFilters({ ...filters, [name]: value });
    }
  };

  const priceRanges: { [key: string]: [number, number] } = {
    "under-1000": [0, 999],
    "1000-1100": [1000, 1100],
    "1100-1200": [1100, 1200],
    "1200-1300": [1200, 1300],
    "1300-1400": [1300, 1400],
    "1400-1500": [1400, 1500],
    "1500-1600": [1500, 1600],
    "1600-1700": [1600, 1700],
    "1700-1800": [1700, 1800],
    "1800-1900": [1800, 1900],
    "1900-2000": [1900, 2000],
    "2000+": [2001, Infinity],
  };

  const filteredListings = listings.filter((listing) => {
    const { beds, baths, price, propertyType, neighborhoods } = filters;

    const matchBeds =
      !beds || listing.beds?.toLowerCase().includes(beds.toLowerCase());
    const matchBaths =
      !baths || listing.baths?.toLowerCase().includes(baths.toLowerCase());
    const matchNeighborhoods =
      neighborhoods.length === 0 ||
      neighborhoods.includes("All of Austin") ||
      neighborhoods.includes(listing.neighborhood);
    const matchPrice =
      !price ||
      (priceRanges[price] &&
        listing.priceValue >= priceRanges[price][0] &&
        listing.priceValue <= priceRanges[price][1]);
    const matchPropertyType =
      !propertyType ||
      (listing.propertyType &&
        listing.propertyType.toLowerCase() === propertyType.toLowerCase());

    return (
      matchBeds &&
      matchBaths &&
      matchNeighborhoods &&
      matchPrice &&
      matchPropertyType
    );
  });

  return (
    <div style={{ padding: "2rem", fontFamily: "'Inter', sans-serif" }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "1.5rem", color: "#222" }}>
        Apartments in Austin, Texas
      </h1>

      <SchemaItemList city="Austin" listings={listings} />
      <AISchema city="Austin" listings={listings} />

      <div
        className="search-bar"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1rem",
          marginBottom: "2.5rem",
          padding: "1.75rem",
          backgroundColor: "#f9f9f9", // ✅ soft gray is back
          border: "1px solid rgba(0,0,0,0.08)", // ✅ clean definition
          borderRadius: "12px",
          boxShadow: "0 6px 18px rgba(0,0,0,0.06)", // ✅ modern depth
        }}
      >
        {/* Property Type, Beds, Baths, Price dropdowns (keep your working code) */}

        {/* ✅ Neighborhoods */}
        <div style={{ flexBasis: "100%", marginTop: "1rem" }}>
          <label
            style={{
              fontWeight: "bold",
              display: "block",
              marginBottom: "0.5rem",
            }}
          >
            Neighborhoods
          </label>

          <div style={{ display: "flex", gap: "1rem", marginBottom: "0.5rem" }}>
            <button
              type="button"
              onClick={() =>
                setFilters({
                  ...filters,
                  neighborhoods: ["All of Austin", ...allNeighborhoods],
                })
              }
            >
              Select All
            </button>
            <button
              type="button"
              onClick={() => setFilters({ ...filters, neighborhoods: [] })}
            >
              Deselect All
            </button>
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
            <label>
              <input
                type="checkbox"
                name="neighborhoods"
                value="All of Austin"
                checked={filters.neighborhoods.includes("All of Austin")}
                onChange={(e) => {
                  const { checked } = e.target;
                  if (checked) {
                    setFilters({
                      ...filters,
                      neighborhoods: ["All of Austin", ...allNeighborhoods],
                    });
                  } else {
                    setFilters({ ...filters, neighborhoods: [] });
                  }
                }}
              />
              All of Austin
            </label>

            {allNeighborhoods.map((neighborhood) => (
              <label key={neighborhood}>
                <input
                  type="checkbox"
                  name="neighborhoods"
                  value={neighborhood}
                  checked={
                    filters.neighborhoods.includes("All of Austin") ||
                    filters.neighborhoods.includes(neighborhood)
                  }
                  onChange={handleChange}
                />
                {neighborhood}
              </label>
            ))}
          </div>
        </div>
      </div>

      {filteredListings.length === 0 && (
        <p
          style={{
            marginTop: "1rem",
            fontSize: "1rem",
            color: "#555",
            textAlign: "center",
          }}
        >
          No listings available right now. Contact me for a free list of the
          latest options!
        </p>
      )}

      {/* ✅ Listings using ListingCard */}
      <div className="card-grid">
        {filteredListings.map((listing, index) => (
          <ListingCard
            key={index}
            listing={listing}
            defaultImage={defaultImage}
          />
        ))}
      </div>
    </div>
  );
};

export default ApartmentListings;
