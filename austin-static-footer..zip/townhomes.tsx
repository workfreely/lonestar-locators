import React, { useState } from "react";
import BlogLayout from "../components/BlogLayout";

const AustinTownhomes = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const IMG_WESTERLY = "/images/westerly-360.jpg";
  const IMG_AMLI = "/images/amli-south-shore.jpg";
  const IMG_BOULEVARD = "/images/boulevard-town-lake.jpg";
  const BLURRED_LIST =
    "https://res.cloudinary.com/dxtiguwzm/image/upload/v1750015063/how-apartment-locating-works-select-realtor-locator_qm12ei.jpg";

  const faqs = [
    {
      question: "Are townhomes available for rent in Austin?",
      answer:
        "Absolutely — with communities like Westerly 360, AMLI South Shore, and The Boulevard at Town Lake, you can find luxury townhomes for rent in Austin’s most desirable neighborhoods.",
    },
    {
      question: "Can I find cheap or affordable townhomes in Austin?",
      answer:
        "Yes — while many new townhomes are luxury, you can still find affordable options near North and East Austin, and we track the best pricing for budget-conscious renters.",
    },
    {
      question: "Do any townhomes in Austin offer yards or outdoor space?",
      answer:
        "Many of our listings include features like private yards, patios, and green courtyard areas — perfect for pets, families, or outdoor living.",
    },
    {
      question: "Is it difficult to rent a 3-bedroom townhome in Austin?",
      answer:
        "There are some 3-bedroom townhomes in North Austin and South Shore that match growing household needs — and we're here to help you find an available one.",
    },
  ];

  return (
    <BlogLayout
      title="Austin Townhomes for Rent & Sale (2025)"
      content={
        <>
          <p>
            Searching for *Austin townhomes for rent* or sale? Whether you're
            looking for *luxury townhomes for rent Austin*, **cheap townhomes
            for rent Austin**, or *townhomes with yard*, this guide will walk
            you through the best options — including new communities in North,
            South, and East Austin. We include each property's style, amenities,
            and location to help simplify your search in 2025.
          </p>

          <h2>Why Choose a Townhome in Austin?</h2>
          <p>
            Townhomes in Austin offer a hybrid lifestyle — more space, privacy,
            and character than an apartment, but without the maintenance and
            yard work of a single-family home. They often include features like
            private garages, fenced yards, multi-level layouts, and dedicated
            outdoor space — making them especially appealing for families,
            roommates, and anyone looking to upgrade beyond apartment living.
          </p>

          <h2>Top Austin Townhome Communities to Know</h2>

          <h3>1. Westerly 360</h3>
          {IMG_WESTERLY && (
            <img
              src={IMG_WESTERLY}
              alt="Westerly 360 Austin Townhomes"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            Nestled in North Austin near the Domain, Westerly 360 offers sleek
            townhome-style residences with modern finishes, rooftop terraces,
            and private garages. It's ideal for those seeking walkability,
            tech-friendly amenities, and easy access to Austin’s shopping and
            Central business district.
          </p>

          <h3>2. AMLI South Shore</h3>
          {IMG_AMLI && (
            <img
              src={IMG_AMLI}
              alt="AMLI South Shore Townhomes Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            Located on Lake Austin Boulevard, AMLI South Shore blends urban
            luxury with waterfront living. You’ll find spacious floorplans,
            private balconies, and access to greenbelt trails. It's a great
            option for renters who want nature and convenience in South Austin.
          </p>

          <h3>3. The Boulevard at Town Lake</h3>
          {IMG_BOULEVARD && (
            <img
              src={IMG_BOULEVARD}
              alt="Boulevard at Town Lake Austin Townhomes"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            Just a stone's throw from Downtown and Zilker Park, The Boulevard at
            Town Lake offers townhomes with rooftop views, private patios, and
            secure parking. Ideal for renters who want everything — Parks,
            nightlife, and skyline living.
          </p>

          <h2>Preview: Curated Townhome Listings for Austin</h2>
          <p>
            We curate a private, constantly-updated list of the best Austin
            townhomes for rent — including *cheap townhomes for rent Austin* and
            *3 bedroom townhomes for rent Austin* — tailored to your budget and
            lifestyle.
          </p>
          <img
            src={BLURRED_LIST}
            alt="Curated Austin Townhome List"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
              border: "1px solid #ddd",
            }}
          />
          <p style={{ fontStyle: "italic", color: "#666" }}>
            This is a preview of our curated list. Contact us to receive your
            personalized match.
          </p>

          <h2>Townhome Features That Matter Most</h2>
          <div style={{ lineHeight: "1.8" }}>
            <div>✅ Private garage and direct entrance</div>
            <div>✅ Private or fenced yard space</div>
            <div>✅ Multi-level layouts ideal for roommates or families</div>
            <div>✅ Rooftop or balcony outdoor living</div>
            <div>✅ Proximity to work hubs, trails, and green spaces</div>
          </div>

          <h2>Ready to Tour Your Next Austin Townhome?</h2>
          <p>
            Whether you're interested in *townhomes south Austin for rent* or
            *townhomes for rent north Austin*, we’ll match you with the right
            places — even 3-bedroom or yard-equipped listings. Our locator
            service is fast, free, and tailored to what you need.
          </p>
          <p>
            Click below to start your customized search and secure your next
            home.
          </p>

          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, idx) => (
              <div key={idx} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(idx)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === idx && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
      faqs={[]} // Not necessary—faqs passed in content above
    />
  );
};

export default AustinTownhomes;
