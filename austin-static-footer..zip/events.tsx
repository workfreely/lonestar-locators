// /src/austin/events.tsx
import React from "react";
import BlogLayout from "../components/BlogLayout";

const AustinEvents = () => {
  const faqs = [
    {
      question: "What are the biggest annual events in Austin?",
      answer:
        "Austin hosts major annual events including South by Southwest, Austin City Limits Music Festival, Pecan Street Festival, Trail of Lights, and the Austin Rodeo. These events attract large crowds and offer entertainment, food, music, and activities for all ages.",
    },
    {
      question: "Are Austin events family friendly?",
      answer:
        "Many Austin events are family friendly including Trail of Lights, Pecan Street Festival, Austin Rodeo, and numerous markets, outdoor concerts, and community celebrations.",
    },
    {
      question: "Do events cause higher traffic in Austin?",
      answer:
        "During large events like SXSW and ACL, traffic can increase near Downtown Austin and Zilker Park. Planning ahead or using rideshare helps avoid delays.",
    },
    {
      question: "Where do most Austin events happen?",
      answer:
        "Most Austin events take place around Zilker Park, Downtown Austin, the Red River District, and the Congress Avenue area.",
    },
    {
      question: "When is the best time to attend events in Austin?",
      answer:
        "Spring and fall are peak seasons because of cooler weather and major festivals. Winter features holiday events and summer offers outdoor concerts and weekend activities.",
    },
  ];

  return (
    <BlogLayout
      title="Austin Events - Best Events in Austin, Texas"
      publishDate={new Date().toISOString()}
      keywords={[
        "Austin events",
        "things to do in Austin",
        "Austin festivals",
        "Austin concerts",
        "Austin activities",
        "Austin neighborhoods",
      ]}
      address={{ addressLocality: "Austin", addressRegion: "Texas" }}
      content={
        <>
          <p style={{ display: "none" }}></p>

          {/* ---- INTRO ---- */}
          <p style={{ marginBottom: "0.5rem" }}>
            <strong>Looking for the best events happening in Austin?</strong>{" "}
            From festivals and concerts to holiday celebrations and local
            traditions, the city offers something exciting in every season.
          </p>

          <p style={{ marginBottom: "2.2rem", color: "#555" }}>
            Below are some of Austin’s most popular annual events that locals
            and newcomers look forward to each year.
          </p>

          {/* --- EVENT 1 --- */}
          <div style={{ padding: ".10rem", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              South by Southwest
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 March 7 to March 15, 2025 — Downtown Austin</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              SXSW brings together music, film, technology, and culture for a
              full week of concerts, screenings, conferences, and interactive
              showcases across downtown.
            </p>
            <a
              href="https://www.sxsw.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 2 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Austin City Limits Music Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 First two weekends of October — Zilker Park</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              ACL is a two-weekend outdoor festival featuring major headliners,
              local artists, Austin food vendors, and an energetic festival
              atmosphere at Zilker Park.
            </p>
            <a
              href="https://www.aclfestival.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 3 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Pecan Street Festival
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 Spring & Fall — Historic Sixth Street</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              One of Austin’s largest art and craft festivals featuring hundreds
              of vendors, food booths, live music, and family activities across
              several downtown blocks.
            </p>
            <a
              href="https://www.pecanstreetfestival.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 4 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Austin Rodeo
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 March 2025 — Travis County Expo Center</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              The Austin Rodeo brings classic Texas rodeo competition to the
              city with concerts, livestock shows, rides, and family
              attractions.
            </p>
            <a
              href="https://rodeoaustin.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          {/* --- EVENT 5 --- */}
          <div style={{ padding: "1.5rem 0", borderBottom: "1px solid #eee" }}>
            <h3
              style={{
                fontSize: "1.55rem",
                marginBottom: "0.35rem",
                fontWeight: 700,
              }}
            >
              Trail of Lights
            </h3>
            <p style={{ margin: "0.25rem 0" }}>
              <strong>📆 December — Zilker Park</strong>
            </p>
            <p style={{ margin: "0.6rem 0" }}>
              Trail of Lights transforms Zilker Park into a glowing holiday
              attraction with themed displays, tunnels of lights, food vendors,
              and entertainment for all ages.
            </p>
            <a
              href="https://austintrailoflights.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Website
            </a>
          </div>

          <h2 style={{ marginTop: "2rem" }}>Where Most Events Happen</h2>
          <p style={{ marginBottom: 0 }}>
            Many popular events take place around Zilker Park, Downtown Austin,
            the Red River District, and the Congress Avenue area. These hubs
            host concerts, parades, markets, and holiday celebrations
            year-round.
          </p>
        </>
      }
      faqs={faqs}
    />
  );
};

export default AustinEvents;
