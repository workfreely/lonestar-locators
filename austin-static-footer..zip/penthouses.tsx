import React, { useState } from "react";
import BlogLayout from "../components/BlogLayout";

const AustinPenthouses = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) =>
    setActiveIndex(activeIndex === index ? null : index);

  const IMG_THOMPSON = "/images/sienna-at-thompson.jpg";
  const IMG_ATLAS = "/images/atlas-eastside.jpg";
  const IMG_BROADSTONE = "/images/broadstone-north-atx.jpg";
  const BLURRED_LIST =
    "https://res.cloudinary.com/dxtiguwzm/image/upload/v1758820133/luxury-apartment-locator-list-austin-dallas-houston-san-antonio_cfbc0q.png";

  const faqs = [
    {
      question: "What is the average rent for a penthouse in Austin?",
      answer:
        "Penthouses typically rent between $3,500 and $5,500 depending on size, view, and community amenities.",
    },
    {
      question: "Are penthouses pet‑friendly?",
      answer:
        "Yes — most modern penthouse buildings in Austin welcome pets, and many offer rooftop dog areas or pet washing stations.",
    },
    {
      question: "Do penthouses include private outdoor spaces?",
      answer:
        "Many have spacious terraces or balconies—some even have private rooftop access with great views.",
    },
    {
      question: "Can I schedule a private tour?",
      answer:
        "Absolutely. We can arrange VIP tours—just let us know your preferred buildings and timeline.",
    },
  ];

  return (
    <BlogLayout
      title="Austin Penthouses Guide & Map (2025)"
      content={
        <>
          <p>
            Looking for the ultimate luxury experience in Austin living?
            Penthouse units offer skyline views, ultra-modern finishes, and
            privacy—all in prime downtown or Eastside locations. Here's your
            comprehensive guide to the best penthouses in Austin.
          </p>

          <h2>Top Penthouses in Austin Today</h2>

          <h3>1. Sienna at The Thompson</h3>
          {IMG_THOMPSON && (
            <img
              src={IMG_THOMPSON}
              alt="Sienna at The Thompson Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            Located in the vibrant Rainey Street district and right inside the
            Thompson Hotel, Sienna offers stunning skyline views,
            floor-to-ceiling windows, and access to top-tier amenities including
            rooftop pool, private lounge, and 24/7 concierge.
          </p>

          <h3>2. Atlas Eastside</h3>
          {IMG_ATLAS && (
            <img
              src={IMG_ATLAS}
              alt="Atlas Eastside Austin"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            A modern East Austin penthouse with sleek industrial finishes and
            panoramic 360-degree terraces. Walkable to East Sixth Street’s bars
            and art galleries. Resident perks include rooftop garden, coworking
            lounge, and fitness center.
          </p>

          <h3>3. Broadstone North ATX</h3>
          {IMG_BROADSTONE && (
            <img
              src={IMG_BROADSTONE}
              alt="Broadstone North ATX"
              style={{
                width: "100%",
                marginBottom: "20px",
                borderRadius: "8px",
              }}
            />
          )}
          <p>
            Positioned north of downtown with skyline views and resort-style
            amenities like rooftop pool, dog park, and fireside lounges.
            Spacious penthouse layouts with high ceilings, gourmet kitchens, and
            private terraces.
          </p>

          <h2>Preview Our Curated Austin Penthouses List</h2>
          <p>
            We maintain a private list of current penthouses, including units
            not visible on public platforms.
          </p>
          <img
            src={BLURRED_LIST}
            alt="Curated Penthouses List Austin"
            style={{
              width: "100%",
              marginBottom: "20px",
              borderRadius: "8px",
              border: "1px solid #ddd",
            }}
          />
          <p style={{ fontStyle: "italic", color: "#666" }}>
            This is a sample of our curated penthouses. Click below to get your
            personalized list!
          </p>

          <h2>Why Work With Us?</h2>
          <div style={{ lineHeight: "1.8" }}>
            <div>✅ VIP penthouse tours arranged for you</div>
            <div>
              ✅ Negotiation with condos for custom finishes or upgrades
            </div>
            <div>✅ Access to pre‑lease or off‑market units</div>
            <div>✅ No fee locating service + move‑in perks included</div>
          </div>

          <h2>Ready to Tour Your Next Penthouse?</h2>
          <p>
            Let us find and schedule penthouse tours that match your style,
            budget, and move-in date.
          </p>
          <p>
            Click below to get started—our service is 100% free and exclusively
            tailored for penthouse renters in Austin.
          </p>

          <h2 style={{ marginTop: "50px" }}>
            Frequently Asked Questions (FAQ)
          </h2>
          <div style={{ borderTop: "1px solid #ddd", paddingTop: "15px" }}>
            {faqs.map((faq, idx) => (
              <div key={idx} style={{ marginBottom: "15px" }}>
                <div
                  onClick={() => toggleAccordion(idx)}
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#f1f1f1",
                    padding: "10px 15px",
                    borderRadius: "5px",
                    fontWeight: "600",
                    color: "#004aad",
                  }}
                >
                  {faq.question}
                </div>
                {activeIndex === idx && (
                  <div
                    style={{
                      backgroundColor: "#fafafa",
                      padding: "10px 15px",
                      border: "1px solid #ddd",
                      borderTop: "none",
                      borderRadius: "0 0 5px 5px",
                      marginTop: "-5px",
                      color: "#555",
                    }}
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      }
    />
  );
};

export default AustinPenthouses;
