import React from "react";
import { Helmet } from "react-helmet";

const AustinFirstTimeRenters = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Helmet>
        <title>First-Time Renters in Austin | Lone Star Locators</title>
        <meta
          name="description"
          content="Renting for the first time in Austin, TX? Get expert guidance, flexible leasing options, and helpful tips from our local team."
        />
      </Helmet>

      <h1>First-Time Renters in Austin</h1>
      <p>
        Renting for the first time? Our Austin experts will walk you through
        every step — from choosing the right area to signing your lease with
        confidence.
      </p>
    </div>
  );
};

export default AustinFirstTimeRenters;
