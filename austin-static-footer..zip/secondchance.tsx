import React from "react";

const SecondChanceApartmentsAustin = () => {
  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "2rem auto",
        padding: "2rem",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <h1>Second Chance Apartments in Austin, TX</h1>

      <p>
        Looking for an apartment in Austin but worried about bad credit, a
        broken lease, or past background issues? We specialize in helping
        renters get a second chance at housing. Whether you’ve faced financial
        hardship or need a co-signer, Lone Star Locators is here to help.
      </p>

      <h2>We Work With Renters Who Have:</h2>
      <ul>
        <li>Low or bad credit scores</li>
        <li>Broken leases or prior evictions</li>
        <li>Past criminal history (case-by-case)</li>
        <li>Need for a co-signer or income flexibility</li>
      </ul>

      <h2>How It Works</h2>
      <ul>
        <li>We match you with flexible apartment communities in Austin</li>
        <li>
          You’ll receive guidance on documents, approvals, and move-in steps
        </li>
        <li>Use our free service and qualify for a rebate or free movers</li>
      </ul>

      <p style={{ marginTop: "2rem" }}>
        Don’t let your rental history hold you back. Contact Lone Star Locators
        today and we’ll help you find a second chance apartment in Austin that
        fits your situation.
      </p>
    </div>
  );
};

export default SecondChanceApartmentsAustin;
