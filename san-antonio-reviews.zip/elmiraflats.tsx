import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const ElmiraFlats: React.FC = () => {
  return (
    <ReviewLayout
      title="Elmira Flats Review — The Good, Bad & Ugly"
      propertyName="Elmira Flats"
      image="https://res.cloudinary.com/dxtiguwzm/image/upload/v1748014964/elmira-flats-apartments-san-antonio.jpg"
      customIntro="Elmira Flats offers clean, modern one bedroom living in one of the most walkable pockets of San Antonio. It is the sister property to St. Mary’s Flats and sits minutes from the Pearl District, the River Walk, and some of the city’s best restaurants and nightlife. This community is ideal for anyone who wants boutique style living without the high price tag of newer luxury developments."
      good={[
        "Free covered garage parking for all residents",
        "Residents receive a $500 amenity credit at move in with options like pool day passes at The Thompson Hotel, dog grooming, a Sikesercise gym membership, or a $500 Visa gift card",
        "Modern one bedroom layouts with clean finishes and efficient floor plans",
        "Prime location minutes from the Pearl District, River Walk, and major employers",
        "Quiet, low density living with only one bedroom homes which creates a more private feel",
      ]}
      bad={[
        "No pool, fitness center, or large shared amenities found in bigger mid rise communities",
        "On site staffing is limited because leasing is handled through St. Mary’s Flats",
      ]}
      ugly={[
        "Only one bedroom floor plans are available which may not work for roommates or families",
        "Guest parking can be limited during busy evening and weekend hours",
      ]}
      customOutro="Elmira Flats is a great option if you want modern interiors, garage parking, and an unbeatable location near the Pearl without paying luxury mid rise pricing. The $500 resident benefit credit is a perk that you rarely see at this price point. If you want something clean, simple, and in the heart of the city, Elmira Flats is definitely worth touring."
      keywords={[
        "Elmira Flats Review",
        "Elmira Flats Apartments",
        "Elmira Flats San Antonio",
        "Apartments near The Pearl San Antonio",
        "San Antonio Apartment Locator",
        "Downtown San Antonio Apartments",
      ]}
      neighborhood="Downtown San Antonio"
      address={{
        streetAddress: "1811 N St Marys St",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78212",
        addressCountry: "US",
      }}
      rent="$1,199+"
      bedrooms="1 Bed"
      agentVideo="https://www.youtube.com/embed/ysz5S6PUM-U"
    />
  );
};

export default ElmiraFlats;
