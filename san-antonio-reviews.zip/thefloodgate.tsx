// /src/sanantonio/reviews/thefloodgate.tsx

import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const TheFloodgate: React.FC = () => {
  return (
    <ReviewLayout
      title="The Floodgate Review – The Good, Bad & Ugly"
      propertyName="The Floodgate"
      image="https://res.cloudinary.com/dxtiguwzm/image/upload/v1733366000/the-floodgate-san-antonio.jpg"
      customIntro="The Floodgate is a boutique luxury high rise right on the River Walk. It has a modern architectural look, floor to ceiling windows, and only 63 residences which gives it a more private and exclusive feel compared to larger downtown communities. The amenity deck sits on the 4th level, and the automated parking garage is one of the most unique features in all of San Antonio residential living."
      good={[
        "17-story luxury high-rise with floor to ceiling windows in many units",
        "Boutique community with only 63 residences for a more private feel",
        "Fully automated parking garage that parks and retrieves your vehicle",
        "4th level amenity deck with indoor lounge, outdoor terrace, spa style pool, private dining room, and fitness center",
        "Direct River Walk location near Commerce Street with walkability to dining, hotels, and downtown employers",
      ]}
      bad={[
        "1 bedroom homes typically start in the low $2000 range",
        "Fitness center is smaller and more compact than large resort style gyms in suburban communities",
        "Limited availability due to small number of units and unique floor plans",
      ]}
      ugly={[
        "Floodgate features a spa-style pool on its 4th-level amenity deck instead of a large resort-style pool.",
        "Being directly on the River Walk may mean busier weekend nights with tourist and restaurant traffic",
      ]}
      customOutro="This is easily one of my favorite high rise properties in all of San Antonio. The architecture alone makes it stand out from anything else on the River Walk. The LED kitchen lighting, the modern finishes, and the wall to wall windows give it a true luxury high rise feel. The automated parking garage is also a major flex. You pull in, the system parks your car, and you head straight up to your residence or the amenity deck. If you are looking for a sleek, modern, boutique high rise with stunning river views, The Floodgate is absolutely one to tour."
      keywords={[
        "The Floodgate Review",
        "The Floodgate",
        "Floodgate San Antonio",
        "Floodgate Apartments Review",
        "San Antonio High Rise Apartments",
        "Luxury Apartments Downtown San Antonio",
      ]}
      neighborhood="Downtown San Antonio"
      address={{
        streetAddress: "139 E Commerce St",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78205",
        addressCountry: "US",
      }}
      rent="2000+"
      bedrooms="1 to 3 Beds"
      agentVideo="" // optional
    />
  );
};

export default TheFloodgate;
