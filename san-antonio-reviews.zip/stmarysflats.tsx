// /src/sanantonio/reviews/st-marys-flats.tsx
import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const StMarysFlats: React.FC = () => {
  return (
    <ReviewLayout
      title="St. Mary’s Flats Review – The Good, Bad & Ugly"
      propertyName="St. Mary’s Flats"
      image="https://res.cloudinary.com/dxtiguwzm/image/upload/v1748015122/st-marys-apartments-san-antonio.jpg"
      customIntro="St. Mary’s Flats offers boutique one bedroom living in one of San Antonio’s most walkable cultural districts. With private garage parking, modern interiors, and direct access to the River Walk, the property delivers an upscale but simple lifestyle. Residents also receive exclusive move in perks not offered anywhere else along the Pearl corridor."
      good={[
        "Prime location near the Pearl District, downtown, and the River Walk with outstanding walkability to dining and nightlife.",
        "Free resident garage parking which is rare for this area and a major value.",
        "Boutique style community with elevator access and modern one bedroom layouts.",
        "Residents can select a premium perk at move in such as Thompson Hotel pool credits, dog grooming credits, a gym membership, or a $500 Visa gift card.",
      ]}
      bad={[
        "No pool, no fitness center, and no large amenities compared to mid rise or luxury properties.",
        "Guest parking can be limited during busy downtown weekends and special events.",
      ]}
      ugly={[
        "Only one bedroom floor plans are available which is not ideal for roommates or larger households.",
        "Availability is limited because the community is smaller and units lease quickly.",
      ]}
      customOutro="What I love about St. Mary’s Flats is the location and simplicity. You are steps from some of the best restaurants, coffee shops, and entertainment in the city, yet the building still feels quiet and private once you are home. The free garage parking and move in perk options also add real value that most downtown buildings do not offer."
      keywords={[
        "St. Mary’s Flats Review",
        "St. Mary’s Flats San Antonio",
        "St. Mary’s Apartments",
        "Apartments near the Pearl San Antonio",
        "Downtown San Antonio Apartments",
        "San Antonio Apartment Locator",
      ]}
      neighborhood="Near the Pearl"
      address={{
        streetAddress: "1606 N St Marys St",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78215",
        addressCountry: "US",
      }}
      rent="1195+"
      bedrooms="1 Bed"
      agentVideo=""
    />
  );
};

export default StMarysFlats;
