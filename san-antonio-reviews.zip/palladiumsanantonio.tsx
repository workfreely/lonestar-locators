import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const PalladiumSanAntonio: React.FC = () => {
  return (
    <ReviewLayout
      title="Palladium San Antonio Review – The Good, Bad & Ugly"
      propertyName="Palladium San Antonio"
      image="https://www.palladiumsanantonio.com/wp-content/uploads/2024/03/hero.jpg"
      customIntro="Palladium San Antonio is a brand-new luxury and affordable apartment community located on the west side of San Antonio near Lackland Air Force Base. This community is designed to provide modern finishes, spacious floor plans, and a growing list of amenities while remaining income-restricted for qualifying residents."
      good={[
        "1, 2, and 3-bed apartments with granite countertops, wood-style flooring, and 9-foot ceilings",
        "Oversized closets and 42-inch cabinetry for extra storage",
        "Basketball court, dog park, trails and kids playground",
        "Full-size washer and dryer included in every home",
        "Currently pre-leasing for February 2026",
      ]}
      bad={[
        "This community offers both market-rate and income-restricted homes, so not everyone will qualify for the lowest advertised pricing and household income limits apply.",
      ]}
      ugly={[
        "Because the community is brand new, several amenities are still under construction including the basketball court, dog park, trails, tot lot, and playground, but these exciting additions are actively in progress and will significantly enhance the community once completed",
      ]}
      customOutro={[
        "Palladium San Antonio is an exciting new option for renters who want modern living near Lackland Air Force Base at a more affordable price point. The finishes feel upscale for an income-restricted community and the layouts are spacious and functional.",

        "Katie and the entire leasing team have been extremely helpful in answering questions for future residents and keeping applicants updated throughout the pre-leasing process.",

        "If you qualify for the income limits and are comfortable moving into a brand-new community as amenities continue to come online, Palladium San Antonio offers strong long-term value and a great west San Antonio location.",
      ]}
      keywords={[
        "Palladium San Antonio Review",
        "Affordable Apartments Near Lackland AFB",
        "Income Restricted Apartments San Antonio",
        "West San Antonio Apartments",
        "New Apartments Near Lackland",
        "Military Friendly Apartments San Antonio",
        "Lackland Air Force Base Apartments",
      ]}
      neighborhood="West San Antonio"
      address={{
        streetAddress: "4750 West Military Drive",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78242",
        addressCountry: "US",
      }}
      rent="$500+"
      bedrooms="1–3 Bedrooms"
      agentVideo=""
    />
  );
};

export default PalladiumSanAntonio;
