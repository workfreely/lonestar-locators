import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const OasisStoneOak: React.FC = () => {
  return (
    <ReviewLayout
      title="Oasis at Stone Oak Review – The Good, Bad & Ugly"
      propertyName="Oasis at Stone Oak"
      image="https://www.oasisstoneoak.com/assets/images/gallery/1.jpg"
      customIntro="Oasis at Stone Oak delivers brandnew townhome living in one of the most desirable areas of far north San Antonio. With private garages, modern finishes, and a resort style pool, this community gives you a luxury feel with the privacy and comfort of a townhome layout. It is ideal for anyone who wants new construction, stylish interiors, and a well connected Stone Oak location."
      good={[
        "Newest townhomes in the Stone Oak area with modern luxury finishes",
        "Private garages and fenced yards for added privacy",
        "Quartz countertops, wood style flooring, and wine fridge in select homes",
        "Multiple floor plans with spacious layouts to choose from",
      ]}
      bad={[
        "Yards have gravel instead of grass or concrete which may not fit every preference",
        "Some residents have reported occasional insects due to surrounding natural areas",
      ]}
      ugly={[
        "Pricing can feel high for some renters but you are getting a brandnew luxury townhome in Stone Oak",
      ]}
      customOutro="What I love about Oasis at Stone Oak is the combination of location, luxury, and livability. The resort style pool is a standout, and the variety of layouts gives you options that truly feel like a private home. I also like that selected homes allow you to enter directly into the second floor from the garage which makes bringing in groceries or avoiding stairs incredibly convenient. The office team, including leasing agents Abcde and Ricardo, are always helpful whenever I visit or call. If you want the newest luxury townhome in Stone Oak, this is the one."
      keywords={[
        "Oasis at Stone Oak Review",
        "Oasis at Stone Oak Townhomes",
        "Stone Oak Townhomes",
        "Luxury Townhomes San Antonio",
        "San Antonio Apartment Locator",
      ]}
      neighborhood="Stone Oak"
      address={{
        streetAddress: "23609 Canyon Golf Rd.",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78260",
        addressCountry: "US",
      }}
      rent="$1,800+"
      bedrooms="1–3 Bed Townhomes"
      agentVideo="https://www.youtube.com/embed/ysz5S6PUM-U"
    />
  );
};

export default OasisStoneOak;
