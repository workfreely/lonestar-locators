import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const CollectionBoerne: React.FC = () => {
  return (
    <ReviewLayout
      title="Collection at Boerne Review – The Good, Bad & Ugly"
      propertyName="Collection at Boerne"
      image="https://www.collectionboerne.com/assets/images/gallery/1.jpg"
      customIntro="Collection at Boerne offers luxury townhome living in one of the most desirable Hill Country areas. You get a peaceful residential setting with modern interiors, private grass yards, front porches, and spacious layouts. It is ideal for anyone who wants the feel of a private home with the amenities of a premium community."
      good={[
        "Brand new luxury townhomes with high quality finishes throughout",
        "Provate Grass yards and front porches that create a true home like feel",
        "Spacious layouts with natural light and open concept living spaces",
        "Resort style pool, fitness center, and community lounge areas",
        "Private garages and driveways equipped with EV charging in select homes",
      ]}
      bad={[
        "Some layouts share one wall but there are no neighbors above or below which maintains privacy",
        "Availability can be tight for the most popular floor plans because new units lease quickly",
      ]}
      ugly={[
        "Pricing sits on the higher end for Boerne but reflects the luxury finishes and amenities",
        "The commute into San Antonio may feel longer for those working near downtown",
      ]}
      customOutro="What I love about Collection at Boerne is the peaceful setting paired with upscale finishes inside every home. The grass yards, townhome layouts, and front porches create a residential feel you do not get in traditional apartments. The interiors are bright, modern, and thoughtfully designed, and the resort style pool and fitness center make everyday living feel elevated. The entire community feels clean, quiet, and welcoming which is perfect for anyone who wants more privacy and comfort."
      keywords={[
        "Collection at Boerne Review",
        "Collection at Boerne Townhomes",
        "Boerne Luxury Townhomes",
        "Townhomes with Yards Boerne",
        "Pet Friendly Townhomes Boerne",
        "San Antonio Apartment Locator",
      ]}
      neighborhood="Boerne"
      address={{
        streetAddress: "1680 River Road, Unit 100", // placeholder until you confirm exact Boerne address
        addressLocality: "Boerne",
        addressRegion: "TX",
        postalCode: "78006",
        addressCountry: "US",
      }}
      rent="$1,600+"
      bedrooms="1–3 Bed Townhomes"
      agentVideo=""
    />
  );
};

export default CollectionBoerne;
