import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const LosCielosBrooks: React.FC = () => {
  return (
    <ReviewLayout
      title="Los Cielos at Brooks Review – The Good, Bad & Ugly"
      propertyName="Los Cielos at Brooks"
      image="https://loscielosatbrooks.com/assets/images/cache/LosCielos_HighRes-2-34d49204a0b913d14ffedd9abcf45e7b.jpg"
      customIntro="Los Cielos at Brooks offers spacious single family style rental homes in the growing Brooks community. With large private yards, attached garages, and a true neighborhood feel, this community is ideal for families, pet owners, and anyone wanting more privacy and comfort than a typical apartment can offer."
      good={[
        "Beautiful single family style homes that feel more like a true residence than an apartment",
        "Private grass yards that are much larger than what you find in most rental communities",
        "Many homes include attached garages for added convenience and security",
        "Resort style amenities including a pool, pickleball courts, pet park, clubhouse, and outdoor lounge areas",
        "Located inside the Brooks community with restaurants, parks, and walking trails only minutes away",
      ]}
      bad={[
        "Some reduced rate units require a max term lease at 14-months in order to lock in that pricing",
        "Availability can be limited due to high demand especially for larger floor plans",
      ]}
      ugly={[
        "Pricing may run higher than standard apartment options since these are full sized rental homes but they usually offer strong specials that help lower the overall cost",
      ]}
      customOutro="Los Cielos at Brooks is an absolutely stunning rental home community inside the Brooks neighborhood commonly known as Brooks City Base. Charles and Martha along with the entire staff are welcoming, professional, and always willing to help which creates a smooth and stress free resident experience. The community is clean, peaceful, and family friendly. It is also only about five minutes away from one of my favorite spots, Daves Hot Chicken. If you are looking for a rental home community with a large grass yard and a real home feeling this one is for you!"
      keywords={[
        "Los Cielos at Brooks Review",
        "Los Cielos at Brooks Rental Homes",
        "Brooks City Base Rentals",
        "San Antonio Homes for Rent",
        "Pet Friendly Rental Homes San Antonio",
        "San Antonio Apartment Locator",
      ]}
      neighborhood="Brooks City Base"
      address={{
        streetAddress: "7722 Calle Coyote",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78235",
        addressCountry: "US",
      }}
      rent="$1,800+"
      bedrooms="2–4 Bed Homes"
      agentVideo=""
    />
  );
};

export default LosCielosBrooks;
