import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const InfinityAtTheRim: React.FC = () => {
  return (
    <ReviewLayout
      title="Infinity at the Rim Review – The Good, Bad & Ugly"
      propertyName="Infinity at the Rim"
      image="https://www.infinityattherim.com/wp-content/uploads/hero-home.jpg"
      customIntro="Infinity at the Rim is a luxury apartment and townhome community located near The Rim and La Cantera in Northwest San Antonio. With resort-inspired amenities, rooftop views, and upscale interiors, it offers a high-energy lifestyle in one of the most desirable entertainment districts in the city."
      good={[
        "Resort-style infinity pool with scenic views overlooking San Antonio",
        "Rooftop terrace with incredible skyline and sunset views",
        "Hardwood-style flooring paired with quartz countertops",
        "Fully equipped fitness center that even includes a punching bag",
        "Apartments and rare 2-bed townhomes available",
      ]}
      bad={[
        "Some residents have complained about upkeep and maintenance response times in the past",
      ]}
      ugly={[
        "There have been reports of theft at the property, however the community recently changed management so it is worth monitoring improvements under the new team",
      ]}
      customOutro={[
        "One of my favorite things about Infinity at the Rim is how close you are to restaurants, shopping, and nonstop entertainment. The overall feel of this community honestly reminds me of a Las Vegas hotel, especially during the summer when everyone is hanging poolside.",

        "The elevators and garage parking add a lot of everyday convenience, and the infinity pool offers stunning views of La Cantera while the rooftop lounge gives you an even higher panoramic view. They also have a golf simulator and game room which adds to the social and entertainment vibe of the property.",

        "Pricing is very competitive for being located in both the La Cantera and The Rim areas, which surprises a lot of people. Not many renters realize they even offer two-bedroom townhomes, which are extremely hard to find in this part of San Antonio.",
      ]}
      keywords={[
        "Infinity at the Rim Review",
        "Infinity at the Rim Apartments",
        "La Cantera Apartments",
        "The Rim Apartments San Antonio",
        "Luxury Apartments Near La Cantera",
        "Rooftop Pool Apartments San Antonio",
        "San Antonio Apartment Locator",
        "La Cantera Townhomes",
        "The Rim Townhomes",
      ]}
      neighborhood="The Rim / La Cantera"
      address={{
        streetAddress: "18130 Talavera Ridge",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78257",
        addressCountry: "US",
      }}
      rent="$1,400+"
      bedrooms="Studio–2 Bedroom Apartments & Townhomes"
      agentVideo=""
    />
  );
};

export default InfinityAtTheRim;
