import React from "react";
import ReviewLayout from "../../components/ReviewLayout";

const Main300: React.FC = () => {
  return (
    <ReviewLayout
      title="300 Main – The Good, Bad & Ugly"
      propertyName="300 Main"
      image="https://res.cloudinary.com/dxtiguwzm/image/upload/v1748015122/300-main-apartments-san-antonio.jpg"
      customIntro="300 Main is one of downtown San Antonio’s premier luxury high rises, offering panoramic skyline views, sleek modern interiors, and an unforgettable resort style amenity deck. The open concept layouts and floor to ceiling windows make every home feel bright and elevated, and the onsite coworking and sky level lounges give it a true big city residential feel."
      good={[
        "32-story high-rise tower with incredible elevated skyline views",
        "Open concept layouts with floor-to-ceiling windows that bring in amazing natural light",
        "Resort style pool with private cabanas and luxury lounge seating overlooking downtown",
        "Sky veranda with cabanas and outdoor dining that feels like a rooftop oasis",
        "Sky deck with lounge seating and a firepit for stunning sunset views",
      ]}
      bad={[
        "You may hear occasional downtown traffic or sirens, but noise inside the apartments is minimal and far quieter than you would expect for a high rise in this part of the city",
      ]}
      ugly={[
        "Pricing for a 1-bedroom sits on the higher end for its square footage but the location and luxury amenities justify the premium",
      ]}
      customOutro="What I love about 300 Main is the elevated lifestyle that starts the moment you walk in. The penthouse layouts are incredible with massive skyline views. The floor-to-ceiling windows give you that true downtown luxury feel. The resort-style pool, sky deck, and indoor outdoor fitness center make this one of the most complete amenity packages in the city. For anyone who wants high-end finishes, hotel level amenities, and the best city views in San Antonio, 300 Main is a 5-star choice!"
      keywords={[
        "300 Main Review",
        "300 Main Apartments",
        "300 Main San Antonio",
        "300 Main High Rise",
        "Luxury High Rise San Antonio",
        "Downtown San Antonio Apartments",
        "San Antonio Apartment Locator",
      ]}
      neighborhood="Downtown San Antonio"
      address={{
        streetAddress: "300 N Main Ave",
        addressLocality: "San Antonio",
        addressRegion: "TX",
        postalCode: "78205",
        addressCountry: "US",
      }}
      rent="$1,689+"
      bedrooms="1–2 Beds"
      agentVideo=""
    />
  );
};

export default Main300;
